# CareMap Toronto — Refactoring Plan

## Current State Analysis
- Full working MVP with 6 pages, 10 mock doctors, AI chat, emergency logic
- Color scheme: Teal (#0D9488) + Coral (#F97316) — too colorful for medical
- Registration: 11-field complex form with zod validation
- Confirmation: 4-step timeline with reference numbers, feedback, share CTAs
- Homepage: 8 categories, How It Works, Trust Signals, Emergency Banner

## Target State (per user requirements)

### Color Palette Change
| Token | Old | New |
|-------|-----|-----|
| Primary | Teal #0D9488 | Medical Blue #2563EB |
| CTA Accent | Coral #F97316 | Blue #3B82F6 |
| Background | Stone #FAFAF9 | White #FFFFFF |
| Surface | White | Light blue-gray #F8FAFC |
| Emergency | Red #DC2626 | Keep |
| Text | Slate | Slate (keep) |

### Homepage Changes
- Reduce categories from 8 → 3 (Family Doctor, Dentist, Mental Health)
- Search bar: "What are you feeling?" 
- Add "Location: Toronto" preset indicator
- Remove: How It Works section, Trust Signals section, Emergency Banner (keep overlay logic)
- Keep: AI Assistant (simplify styling), hero section
- Cleaner, more whitespace, Apple-like

### AI Assistant Changes
- Keep functionality, restyle to blue theme
- Simpler responses
- Keep emergency trigger logic

### Results Page Changes
- Restyle cards with blue accents
- Keep: filters, sort, map view, doctor cards
- Simplify card design

### Profile Page Changes
- Restyle with blue theme
- Keep: doctor info, reviews, availability, similar doctors
- Simplify where possible

### Registration Page — MAJOR SIMPLIFICATION
- Remove: 11 fields, zod validation, react-hook-form, step indicator
- New fields: Name, Email, Phone, Optional note
- Simple HTML form, no complex validation library
- One page, no steps

### Confirmation Page — MAJOR SIMPLIFICATION  
- Remove: timeline, reference number, quick actions, feedback, share
- New: Simple "Request sent. Clinic will contact you." with checkmark icon
- One button: "Back to Home"

### Filters Page Changes
- Restyle with blue theme
- Keep functionality

## Execution Plan

### Phase 1: Global Styles + Data (1 agent)
- Update tailwind.config.js (swap teal → blue)
- Update index.css (new background colors)
- Update index.html (possibly update fav/theme color)

### Phase 2: Homepage Rewrite (1 agent)
- Rewrite Home.tsx with new design
- 3 categories only
- Simplified layout
- Blue theme

### Phase 3: Register + Confirm Rewrite (1 agent)
- Strip Register.tsx to 4 fields
- Strip Confirm.tsx to simple success message
- Blue theme

### Phase 4: Results + Profile + Filters Style Update (1 agent)
- Update Results.tsx colors
- Update Profile.tsx colors  
- Update Filters.tsx colors
- Update Navbar/Footer/Layout colors

### Phase 5: Build + Deploy
