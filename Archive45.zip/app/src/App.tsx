import { Routes, Route, useLocation } from 'react-router'
import { lazy, Suspense } from 'react'
import CareMapApp from './CareMapApp'

const About = lazy(() => import('./pages/About'))
const Privacy = lazy(() => import('./pages/Privacy'))
const Terms = lazy(() => import('./pages/Terms'))
const Contact = lazy(() => import('./pages/Contact'))

function PremiumHome() {
  return <CareMapApp />
}

function AppWrapper() {
  const location = useLocation()
  const isContentPage = ['/about', '/privacy', '/terms', '/contact'].includes(location.pathname)

  if (isContentPage) {
    return (
      <Suspense fallback={<div className="flex h-[100dvh] items-center justify-center bg-[#f7faff]"><div className="text-slate-400">Loading...</div></div>}>
        <Routes>
          <Route path="/about" element={<About />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Suspense>
    )
  }

  return (
    <Routes>
      <Route path="/*" element={<PremiumHome />} />
    </Routes>
  )
}

export default function App() {
  return <AppWrapper />
}
