import { motion } from 'framer-motion'
import { Shield, Lock, Database, AlertTriangle } from 'lucide-react'

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
}

const easeDefault: [number, number, number, number] = [0.4, 0, 0.2, 1]

export default function Privacy() {
  return (
    <div className="min-h-[100dvh] bg-white px-4 py-12 md:px-6 md:py-16">
      <div className="mx-auto max-w-[720px]">
        <motion.div {...fadeInUp} transition={{ duration: 0.5, ease: easeDefault }}>
          <Shield className="mb-4 h-8 w-8 text-medical-600" />
          <h1 className="mb-4 text-3xl font-bold text-slate-900">Privacy Policy</h1>
        </motion.div>

        <motion.div
          className="mb-8 rounded-xl border border-medical-200 bg-medical-50 p-4"
          {...fadeInUp}
          transition={{ duration: 0.4, delay: 0.1, ease: easeDefault }}
        >
          <p className="text-sm font-medium text-medical-700">
            Your health information is protected under PHIPA (Personal Health Information Protection Act).
          </p>
        </motion.div>

        <div className="space-y-8">
          {[
            {
              icon: Lock,
              title: 'Data Collection',
              text: 'CareMap Toronto collects only the information necessary to connect you with healthcare providers. This includes your name, contact details, and preferences. We do not collect medical history or diagnostic information.',
            },
            {
              icon: Database,
              title: 'Data Storage',
              text: 'All personal information is stored securely on servers located within Canada, in compliance with Ontario\'s data residency requirements. We use industry-standard encryption for all data in transit and at rest.',
            },
            {
              icon: Shield,
              title: 'How We Use Your Data',
              text: 'Your information is shared only with the clinic you choose to contact. We do not sell, rent, or share your personal data with third parties for marketing or any other purposes.',
            },
            {
              icon: AlertTriangle,
              title: 'AI Assistant Disclaimer',
              text: 'Conversations with our AI assistant are processed to improve service quality. The AI does not provide medical diagnosis or advice. Always consult a licensed healthcare professional for medical concerns.',
            },
          ].map((section, i) => (
            <motion.section
              key={section.title}
              {...fadeInUp}
              transition={{ duration: 0.4, delay: 0.2 + i * 0.08, ease: easeDefault }}
            >
              <div className="mb-2 flex items-center gap-2">
                <section.icon className="h-5 w-5 text-medical-600" />
                <h2 className="text-lg font-semibold text-slate-900">{section.title}</h2>
              </div>
              <p className="text-sm leading-relaxed text-slate-600">{section.text}</p>
            </motion.section>
          ))}
        </div>

        <motion.p
          className="mt-10 text-xs text-slate-400"
          {...fadeInUp}
          transition={{ duration: 0.4, delay: 0.6, ease: easeDefault }}
        >
          Last updated: May 2025. If you have any questions about this policy, please contact us.
        </motion.p>
      </div>
    </div>
  )
}
