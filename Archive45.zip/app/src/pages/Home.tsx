import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search,
  Phone,
  AlertTriangle,
  Stethoscope,
  Brain,
  Heart,
  ChevronRight,
  MapPin,
} from 'lucide-react'

/* ───────── Inline SVG Assets ───────── */

const LogoIcon = ({ size = 40 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
    <path d="M20 4C12.268 4 6 10.268 6 18c0 5.304 2.868 9.912 7.128 12.408L20 38l6.872-7.592C31.132 27.912 34 23.304 34 18c0-7.732-6.268-14-14-14z" fill="#2563EB" />
    <rect x="16" y="12" width="8" height="12" rx="1" fill="white" />
    <rect x="12" y="16" width="16" height="4" rx="1" fill="white" />
  </svg>
)

const EmergencyIcon = ({ size = 48 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
    <path d="M24 4L4 40h40L24 4z" fill="#DC2626" />
    <rect x="20" y="18" width="8" height="14" rx="1" fill="white" />
    <rect x="21" y="28" width="6" height="2" rx="1" fill="#DC2626" />
  </svg>
)

/* ───────── Emergency Overlay ───────── */

function EmergencyOverlay({ onDismiss }: { onDismiss: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4"
      role="alertdialog"
      aria-modal="true"
      aria-live="assertive"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] }}
        className="w-full max-w-[420px] animate-pulse-border rounded-[20px] border-2 border-alert-red bg-medical-50 p-8 text-center"
      >
        <div className="mb-4 flex justify-center">
          <EmergencyIcon size={48} />
        </div>
        <h2 className="mb-3 text-[22px] font-semibold text-alert-red">This sounds like an emergency</h2>
        <p className="mb-6 text-sm leading-relaxed text-slate-700">
          If you or someone nearby is experiencing severe symptoms, please call 911 or visit the nearest emergency room immediately.
        </p>
        <a
          href="tel:911"
          className="mb-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-alert-red px-6 py-4 text-base font-semibold text-white transition-transform active:scale-[0.98]"
        >
          <Phone size={18} />
          Call 911
        </a>
        <button
          onClick={onDismiss}
          className="mb-3 w-full rounded-2xl border border-medical-200 bg-white px-6 py-3.5 text-base font-medium text-slate-700 transition-colors hover:bg-medical-50"
        >
          Find Nearest ER
        </button>
        <button
          onClick={onDismiss}
          className="text-sm font-medium text-slate-500 underline underline-offset-2 transition-colors hover:text-slate-700"
        >
          I understand — continue searching
        </button>
      </motion.div>
    </motion.div>
  )
}

/* ───────── Animation Presets ───────── */

const easeDefault: [number, number, number, number] = [0.4, 0, 0.2, 1]

const fadeSlideUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
}

const slideInLeft = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
}

const slideInRight = {
  initial: { opacity: 0, x: 20 },
  animate: { opacity: 1, x: 0 },
}

/* ───────── Emergency Detection ───────── */

const EMERGENCY_KEYWORDS = [
  'chest pain',
  "can't breathe",
  'difficulty breathing',
  'severe bleeding',
  'unconscious',
  'heart attack',
  'stroke',
  'suicide',
  'overdose',
]

function checkEmergency(text: string): boolean {
  const lower = text.toLowerCase()
  return EMERGENCY_KEYWORDS.some((kw) => lower.includes(kw))
}

/* ───────── Category Data (3 only) ───────── */

const categories = [
  { icon: Stethoscope, title: 'Family Doctor', query: 'family medicine' },
  { icon: Heart, title: 'Dentist', query: 'dentist' },
  { icon: Brain, title: 'Mental Health', query: 'mental health' },
]

/* ───────── Main Home Page ───────── */

export default function Home() {
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [emergencyOpen, setEmergencyOpen] = useState(false)
  const [aiInput, setAiInput] = useState('')
  const [aiMessages, setAiMessages] = useState<
    { role: 'ai' | 'user'; text: string; action?: string }[]
  >([
    {
      role: 'ai',
      text: "Hi! I'm your CareMap assistant. Tell me what you need — whether it's a new family doctor, a dentist, or you're not feeling well.",
    },
    {
      role: 'user',
      text: 'I just moved to North York and need a family doctor. I prefer someone who speaks Mandarin.',
    },
    {
      role: 'ai',
      text: 'I found 4 family doctors in North York accepting new patients who speak Mandarin. Would you like to see them?',
      action: 'Show Results',
    },
  ])
  const [aiTyping, setAiTyping] = useState(false)
  const aiScrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (aiScrollRef.current) {
      aiScrollRef.current.scrollTop = aiScrollRef.current.scrollHeight
    }
  }, [aiMessages, aiTyping])

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return
    if (checkEmergency(query)) {
      setEmergencyOpen(true)
      return
    }
    navigate(`/results?q=${encodeURIComponent(query)}`)
  }

  const handleAiSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!aiInput.trim()) return
    if (checkEmergency(aiInput)) {
      setEmergencyOpen(true)
      setAiInput('')
      return
    }
    const userText = aiInput.trim()
    setAiMessages((prev) => [...prev, { role: 'user', text: userText }])
    setAiInput('')
    setAiTyping(true)

    setTimeout(() => {
      setAiTyping(false)
      const lower = userText.toLowerCase()
      let response = ''
      let action = ''
      if (lower.includes('family doctor') || lower.includes('gp')) {
        response = 'I found 8 family doctors in your area currently accepting new patients. The shortest wait time is about 2 weeks. Shall I show you the full list?'
        action = 'Show Results'
      } else if (lower.includes('dentist')) {
        response = 'I found 5 dentists nearby. Two are accepting new patients and offer evening hours. Want to see the results?'
        action = 'Show Results'
      } else {
        response = "I understand. Let me help you find the right care. Could you tell me which neighborhood you're in, or what language you prefer?"
      }
      setAiMessages((prev) => [...prev, { role: 'ai', text: response, action }])
    }, 1500)
  }

  return (
    <div className="relative">
      <AnimatePresence>
        {emergencyOpen && <EmergencyOverlay onDismiss={() => setEmergencyOpen(false)} />}
      </AnimatePresence>

      {/* ─── Hero ─── */}
      <section className="bg-white px-4 pb-12 pt-10 md:px-6 md:pb-16 md:pt-14">
        <div className="mx-auto max-w-[720px]">
          {/* Brand */}
          <motion.div
            className="mb-10 flex flex-col items-center"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.1, ease: easeDefault }}
          >
            <LogoIcon size={36} />
            <p className="mt-2 text-sm font-semibold tracking-wide text-medical-600 uppercase">
              CareMap Toronto
            </p>
          </motion.div>

          {/* Headline */}
          <motion.h1
            className="mb-3 text-center text-3xl font-bold leading-tight tracking-tight text-slate-900 md:text-4xl"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.2, ease: easeDefault }}
          >
            Find the right doctor, right now.
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            className="mx-auto mb-8 max-w-[480px] text-center text-base text-slate-500"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.3, ease: easeDefault }}
          >
            AI-powered healthcare navigation for Toronto
          </motion.p>

          {/* Search Bar */}
          <motion.form
            onSubmit={handleSearchSubmit}
            className="mb-4"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.4, ease: easeDefault }}
          >
            <div className="relative">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="What are you feeling?"
                className="w-full rounded-2xl border border-slate-200 bg-white py-4 pl-12 pr-5 text-base text-slate-900 placeholder:text-slate-400 focus:border-medical-500 focus:shadow-[0_0_0_3px_rgba(37,99,235,0.12)] focus:outline-none transition-all"
                aria-label="Search for a doctor"
              />
            </div>
          </motion.form>

          {/* Location pill */}
          <motion.div
            className="mb-10 flex justify-center"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.5, ease: easeDefault }}
          >
            <div className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-500">
              <MapPin size={14} className="text-medical-500" />
              Toronto
            </div>
          </motion.div>
        </div>
      </section>

      {/* ─── AI Assistant ─── */}
      <section className="bg-medical-50 px-4 py-10 md:px-6 md:py-14">
        <div className="mx-auto max-w-[720px]">
          <motion.div
            className="mb-6 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, ease: easeDefault }}
          >
            <h2 className="mb-2 text-[22px] font-semibold text-slate-900">Ask our AI Assistant</h2>
            <p className="text-sm text-slate-500">
              Describe your symptoms and we&apos;ll guide you
            </p>
          </motion.div>

          <motion.div
            className="rounded-2xl border border-slate-100 bg-white p-5 shadow-card"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, delay: 0.1, ease: easeDefault }}
          >
            <div ref={aiScrollRef} className="mb-4 flex max-h-[320px] flex-col gap-3 overflow-y-auto pr-1">
              {aiMessages.map((msg, i) => (
                <motion.div
                  key={i}
                  className={`flex ${msg.role === 'ai' ? 'justify-start' : 'justify-end'}`}
                  initial={msg.role === 'ai' ? slideInLeft.initial : slideInRight.initial}
                  whileInView={msg.role === 'ai' ? slideInLeft.animate : slideInRight.animate}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.1, ease: easeDefault }}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-[18px] py-[14px] text-[15px] leading-relaxed ${
                      msg.role === 'ai'
                        ? 'rounded-tl-sm bg-white border border-slate-100 text-slate-700'
                        : 'rounded-tr-sm bg-medical-100 text-slate-900'
                    }`}
                  >
                    {msg.text}
                    {msg.action && (
                      <button
                        onClick={() => navigate('/results?q=family+doctor+north+york+mandarin')}
                        className="mt-2 inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-medical-50 hover:text-medical-600"
                      >
                        {msg.action}
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
              {aiTyping && (
                <div className="flex justify-start">
                  <div className="flex max-w-[85%] items-center gap-1.5 rounded-2xl rounded-tl-sm bg-white border border-slate-100 px-[18px] py-[14px]">
                    <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-medical-400" style={{ animationDelay: '0ms' }} />
                    <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-medical-400" style={{ animationDelay: '150ms' }} />
                    <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-medical-400" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
            </div>

            <form onSubmit={handleAiSubmit} className="flex items-center gap-2 border-t border-slate-100 pt-3">
              <input
                type="text"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                placeholder="Type your question..."
                className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-medical-500 focus:shadow-[0_0_0_3px_rgba(37,99,235,0.12)] focus:outline-none transition-all"
                aria-label="AI chat input"
              />
              <button
                type="submit"
                disabled={!aiInput.trim()}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-medical-500 text-white transition-all hover:bg-medical-600 disabled:opacity-40 disabled:hover:bg-medical-500"
                aria-label="Send message"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </form>
          </motion.div>

          <p className="mx-auto mt-4 max-w-[480px] text-center text-xs leading-relaxed text-slate-500">
            <AlertTriangle className="inline h-3 w-3 align-text-bottom" /> This AI assistant cannot diagnose conditions. Always consult a healthcare professional for medical advice.
          </p>
        </div>
      </section>

      {/* ─── Categories ─── */}
      <section className="bg-white px-4 py-10 md:px-6 md:py-14">
        <div className="mx-auto max-w-[720px]">
          <motion.h2
            className="mb-8 text-center text-[22px] font-semibold text-slate-900"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, ease: easeDefault }}
          >
            What do you need?
          </motion.h2>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {categories.map((cat, i) => {
              const Icon = cat.icon
              return (
                <motion.button
                  key={cat.slug}
                  onClick={() => navigate(`/results?q=${encodeURIComponent(cat.query)}`)}
                  className="flex flex-col items-center rounded-2xl bg-white p-6 border border-slate-100 shadow-card transition-all hover:shadow-card-hover hover:border-medical-200 active:scale-[0.97]"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.4, delay: i * 0.08, ease: easeDefault }}
                >
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-medical-50">
                    <Icon className="h-6 w-6 text-medical-600" strokeWidth={1.5} />
                  </div>
                  <span className="text-center text-sm font-semibold text-slate-900">{cat.title}</span>
                </motion.button>
              )
            })}
          </div>
        </div>
      </section>
    </div>
  )
}
