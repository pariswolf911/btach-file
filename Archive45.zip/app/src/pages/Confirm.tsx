import { useNavigate } from 'react-router'
import { motion } from 'framer-motion'
import { CheckCircle } from 'lucide-react'

const easeDefault = [0.4, 0, 0.2, 1] as [number, number, number, number]

export default function Confirm() {
  const navigate = useNavigate()

  return (
    <div className="min-h-[100dvh] bg-medical-50 flex flex-col items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: easeDefault }}
        className="flex flex-col items-center text-center"
      >
        {/* Checkmark */}
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.45, delay: 0.15, ease: easeDefault }}
        >
          <CheckCircle size={64} className="text-success" strokeWidth={1.8} />
        </motion.div>

        {/* Heading */}
        <h1 className="mt-6 text-2xl font-bold text-slate-900">
          Request sent
        </h1>

        {/* Subtext */}
        <p className="mt-2 text-base text-slate-500 max-w-[320px]">
          The clinic will contact you shortly.
        </p>

        {/* Back to Home */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.4, ease: easeDefault }}
          onClick={() => navigate('/')}
          className="mt-8 flex h-12 items-center justify-center rounded-xl bg-white px-8 text-sm font-semibold text-slate-900 border border-slate-200 shadow-sm transition-all hover:bg-slate-50 active:scale-[0.98]"
        >
          Back to Home
        </motion.button>
      </motion.div>
    </div>
  )
}
