import { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, MessageSquare, Send, CheckCircle } from 'lucide-react'

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
}

const easeDefault: [number, number, number, number] = [0.4, 0, 0.2, 1]

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', message: '' })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) return
    setSubmitted(true)
  }

  return (
    <div className="min-h-[100dvh] bg-white px-4 py-12 md:px-6 md:py-16">
      <div className="mx-auto max-w-[720px]">
        <motion.div {...fadeInUp} transition={{ duration: 0.5, ease: easeDefault }}>
          <MessageSquare className="mb-4 h-8 w-8 text-medical-600" />
          <h1 className="mb-2 text-3xl font-bold text-slate-900">Contact Us</h1>
          <p className="mb-8 text-slate-600">
            Have questions or feedback? We would love to hear from you.
          </p>
        </motion.div>

        {submitted ? (
          <motion.div
            className="flex flex-col items-center rounded-2xl border border-slate-100 bg-medical-50 p-10 text-center"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, ease: easeDefault }}
          >
            <CheckCircle className="mb-4 h-12 w-12 text-success" />
            <h2 className="mb-2 text-xl font-semibold text-slate-900">Message sent</h2>
            <p className="text-sm text-slate-600">Thank you for reaching out. We will get back to you soon.</p>
          </motion.div>
        ) : (
          <motion.form
            onSubmit={handleSubmit}
            className="space-y-5"
            {...fadeInUp}
            transition={{ duration: 0.5, delay: 0.1, ease: easeDefault }}
          >
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Name</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Your name"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-medical-500 focus:shadow-[0_0_0_3px_rgba(37,99,235,0.12)] focus:outline-none transition-all"
                required
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="your@email.com"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-medical-500 focus:shadow-[0_0_0_3px_rgba(37,99,235,0.12)] focus:outline-none transition-all"
                required
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Message</label>
              <textarea
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                placeholder="How can we help?"
                rows={5}
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-medical-500 focus:shadow-[0_0_0_3px_rgba(37,99,235,0.12)] focus:outline-none transition-all resize-none"
                required
              />
            </div>

            <button
              type="submit"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-medical-600 px-6 py-3.5 text-sm font-semibold text-white transition-all hover:bg-medical-700 active:scale-[0.98]"
            >
              <Send className="h-4 w-4" />
              Send Message
            </button>
          </motion.form>
        )}

        <motion.div
          className="mt-10 rounded-2xl border border-slate-100 bg-medical-50 p-6"
          {...fadeInUp}
          transition={{ duration: 0.4, delay: 0.3, ease: easeDefault }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Mail className="h-5 w-5 text-medical-600" />
            <h3 className="text-base font-semibold text-slate-900">Email us directly</h3>
          </div>
          <p className="text-sm text-slate-600">
            For general inquiries: <span className="font-medium text-medical-600">hello@caremaptoronto.ca</span>
          </p>
        </motion.div>
      </div>
    </div>
  )
}
