import { useState, useMemo } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router'
import { motion } from 'framer-motion'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ChevronLeft, User, Mail, Phone, FileText } from 'lucide-react'

const easeDefault = [0.4, 0, 0.2, 1] as [number, number, number, number]

export default function Register() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    note: '',
  })

  // Parse doctor info from URL param ?doctor=Name|Clinic
  const doctorParam = searchParams.get('doctor')
  const doctorInfo = useMemo(() => {
    if (!doctorParam) return null
    const [name, clinic] = doctorParam.split('|')
    return { name: name || 'Unknown Doctor', clinic: clinic || '' }
  }, [doctorParam])

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user types
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev }
        delete next[field]
        return next
      })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const newErrors: Record<string, string> = {}
    if (!formData.name.trim()) newErrors.name = 'Please enter your name'
    if (!formData.email.trim()) newErrors.email = 'Please enter your email'
    if (!formData.phone.trim()) newErrors.phone = 'Please enter your phone number'

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 400))
    navigate('/confirm')
  }

  return (
    <div className="min-h-[100dvh] bg-white">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white px-4 py-4">
        <div className="mx-auto max-w-[640px]">
          <Link
            to="/"
            className="mb-3 inline-flex items-center gap-1 text-sm font-medium text-slate-500 transition-colors hover:text-medical-600"
          >
            <ChevronLeft size={16} />
            Back
          </Link>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Request Registration
          </h1>
        </div>
      </header>

      <div className="mx-auto max-w-[640px] px-4 py-5">
        {/* Doctor Info Card */}
        {doctorInfo ? (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: easeDefault }}
            className="mb-6 rounded-2xl bg-medical-50 p-4"
          >
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Selected Doctor
            </p>
            <p className="mt-1 text-base font-semibold text-slate-900">
              {doctorInfo.name}
            </p>
            {doctorInfo.clinic && (
              <p className="text-sm text-slate-500">{doctorInfo.clinic}</p>
            )}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: easeDefault }}
            className="mb-6 rounded-2xl bg-medical-50 p-4"
          >
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Selected Doctor
            </p>
            <p className="mt-1 text-sm text-slate-500">
              No doctor selected. You can still send a general request.
            </p>
          </motion.div>
        )}

        {/* Form */}
        <motion.form
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.35, delay: 0.1, ease: easeDefault }}
          onSubmit={handleSubmit}
          className="flex flex-col gap-5"
          noValidate
        >
          {/* Name */}
          <div>
            <Label
              htmlFor="name"
              className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-900"
            >
              <User size={14} className="text-slate-400" />
              Name
            </Label>
            <Input
              id="name"
              type="text"
              placeholder="Your full name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className="h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-medical-600 focus:ring-[3px] focus:ring-medical-600/15"
            />
            {errors.name && (
              <p className="mt-1 text-xs text-red-500">{errors.name}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <Label
              htmlFor="email"
              className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-900"
            >
              <Mail size={14} className="text-slate-400" />
              Email
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="you@email.com"
              value={formData.email}
              onChange={(e) => handleChange('email', e.target.value)}
              className="h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-medical-600 focus:ring-[3px] focus:ring-medical-600/15"
            />
            {errors.email && (
              <p className="mt-1 text-xs text-red-500">{errors.email}</p>
            )}
          </div>

          {/* Phone */}
          <div>
            <Label
              htmlFor="phone"
              className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-900"
            >
              <Phone size={14} className="text-slate-400" />
              Phone
            </Label>
            <Input
              id="phone"
              type="tel"
              placeholder="(416) 555-0000"
              value={formData.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              className="h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-medical-600 focus:ring-[3px] focus:ring-medical-600/15"
            />
            {errors.phone && (
              <p className="mt-1 text-xs text-red-500">{errors.phone}</p>
            )}
          </div>

          {/* Note */}
          <div>
            <Label
              htmlFor="note"
              className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-900"
            >
              <FileText size={14} className="text-slate-400" />
              Note
              <span className="text-slate-400 font-normal">(optional)</span>
            </Label>
            <Textarea
              id="note"
              rows={3}
              placeholder="Any additional information..."
              value={formData.note}
              onChange={(e) => handleChange('note', e.target.value)}
              className="rounded-xl border-slate-200 px-4 py-3 text-base text-slate-900 placeholder:text-slate-400 focus:border-medical-600 focus:ring-[3px] focus:ring-medical-600/15 resize-none"
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="mt-2 flex h-14 w-full items-center justify-center rounded-xl bg-medical-600 text-base font-semibold text-white transition-all hover:bg-medical-700 active:scale-[0.98] disabled:opacity-60"
          >
            {isSubmitting ? 'Sending...' : 'Send Request'}
          </button>
        </motion.form>
      </div>
    </div>
  )
}
