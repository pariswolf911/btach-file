import { motion } from 'framer-motion'
import { FileText, AlertTriangle, Heart } from 'lucide-react'

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
}

const easeDefault: [number, number, number, number] = [0.4, 0, 0.2, 1]

export default function Terms() {
  return (
    <div className="min-h-[100dvh] bg-white px-4 py-12 md:px-6 md:py-16">
      <div className="mx-auto max-w-[720px]">
        <motion.div {...fadeInUp} transition={{ duration: 0.5, ease: easeDefault }}>
          <FileText className="mb-4 h-8 w-8 text-medical-600" />
          <h1 className="mb-4 text-3xl font-bold text-slate-900">Terms of Use</h1>
        </motion.div>

        <motion.div
          className="mb-8 rounded-xl border border-alert-red/20 bg-alert-red-light p-4"
          {...fadeInUp}
          transition={{ duration: 0.4, delay: 0.1, ease: easeDefault }}
        >
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-alert-red" />
            <p className="text-sm text-alert-red">
              CareMap Toronto is not a substitute for professional medical advice, diagnosis, or treatment.
              Always seek the advice of a qualified healthcare provider.
            </p>
          </div>
        </motion.div>

        <div className="space-y-8">
          {[
            {
              title: 'Service Description',
              text: 'CareMap Toronto provides a healthcare provider directory and AI-assisted navigation tool. We help users find doctors, dentists, specialists, and clinics in the Greater Toronto Area. We do not provide medical services, diagnoses, or treatment recommendations.',
            },
            {
              title: 'No Medical Advice',
              text: 'Information provided through our platform, including AI assistant responses, is for informational purposes only. It does not constitute medical advice. Never disregard professional medical advice or delay seeking it because of something you read on CareMap.',
            },
            {
              title: 'Emergency Situations',
              text: 'If you are experiencing a medical emergency, call 911 immediately. Do not use CareMap Toronto for emergency medical situations. Our platform includes emergency detection to redirect users to appropriate emergency services.',
            },
            {
              title: 'User Responsibilities',
              text: 'You agree to provide accurate information when submitting registration requests to clinics. You understand that CareMap facilitates the connection but does not guarantee acceptance by any healthcare provider.',
            },
            {
              title: 'Data Accuracy',
              text: 'While we strive to keep all clinic information current and accurate, we rely on public registries and clinic-provided data. CareMap is not responsible for changes in clinic availability, services, or acceptance status.',
            },
            {
              title: 'Acceptable Use',
              text: 'You agree not to use the platform for any unlawful purpose, not to attempt to gain unauthorized access to our systems, and not to use automated tools to scrape or collect data from the platform.',
            },
          ].map((section, i) => (
            <motion.section
              key={section.title}
              {...fadeInUp}
              transition={{ duration: 0.4, delay: 0.15 + i * 0.06, ease: easeDefault }}
            >
              <h2 className="mb-2 text-lg font-semibold text-slate-900">{section.title}</h2>
              <p className="text-sm leading-relaxed text-slate-600">{section.text}</p>
            </motion.section>
          ))}
        </div>

        <motion.div
          className="mt-10 flex items-center gap-2 rounded-xl border border-slate-100 bg-medical-50 p-4"
          {...fadeInUp}
          transition={{ duration: 0.4, delay: 0.6, ease: easeDefault }}
        >
          <Heart className="h-5 w-5 text-medical-600" />
          <p className="text-sm text-slate-600">
            By using CareMap Toronto, you agree to these terms. If you do not agree, please discontinue use of the platform.
          </p>
        </motion.div>

        <motion.p
          className="mt-6 text-xs text-slate-400"
          {...fadeInUp}
          transition={{ duration: 0.4, delay: 0.7, ease: easeDefault }}
        >
          Last updated: May 2025
        </motion.p>
      </div>
    </div>
  )
}
