import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Shield,
  MapPin,
  Users,
  Brain,
  Stethoscope,
  Search,
  Filter,
  Star,
  Clock,
  Globe,
  CheckCircle,
  AlertTriangle,
  Phone,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Calendar,
  Building,
  Accessibility,
  Languages,
  Briefcase,
  HeartPulse,
  Sparkles,
} from 'lucide-react'

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
}

const easeDefault: [number, number, number, number] = [0.4, 0, 0.2, 1]

function Accordion({ title, children, icon: Icon }: { title: string; children: React.ReactNode; icon: React.ElementType }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="rounded-2xl border border-slate-100 bg-white overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between p-5 text-left transition-colors hover:bg-slate-50"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50">
            <Icon className="h-5 w-5 text-blue-600" />
          </div>
          <span className="text-base font-semibold text-slate-900">{title}</span>
        </div>
        {open ? <ChevronUp className="h-5 w-5 text-slate-400" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: easeDefault }}
          >
            <div className="border-t border-slate-100 px-5 pb-5 pt-4">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-5 transition-all hover:shadow-lg hover:border-blue-200">
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50">
        <Icon className="h-5 w-5 text-blue-600" />
      </div>
      <h3 className="mb-1.5 text-sm font-semibold text-slate-900">{title}</h3>
      <p className="text-xs leading-relaxed text-slate-500">{description}</p>
    </div>
  )
}

export default function About() {
  return (
    <div className="min-h-[100dvh] bg-white">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-950 via-blue-900 to-slate-900 px-4 py-16 md:px-6 md:py-24">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0aDR2NGgtNHpNMjQgMjRoNHY0aC00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
        <div className="relative mx-auto max-w-[720px]">
          <motion.div
            className="mb-4 flex items-center gap-2"
            {...fadeInUp}
            transition={{ duration: 0.5, ease: easeDefault }}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600">
              <HeartPulse className="h-5 w-5 text-white" />
            </div>
            <span className="text-sm font-bold tracking-wide text-blue-300 uppercase">CareMap Ontario</span>
          </motion.div>

          <motion.h1
            className="mb-4 text-3xl font-bold leading-tight text-white md:text-4xl"
            {...fadeInUp}
            transition={{ duration: 0.5, delay: 0.1, ease: easeDefault }}
          >
            AI healthcare navigation for Ontario
          </motion.h1>

          <motion.p
            className="text-lg leading-relaxed text-blue-100/80"
            {...fadeInUp}
            transition={{ duration: 0.5, delay: 0.2, ease: easeDefault }}
          >
            CareMap Ontario is an AI-powered healthcare navigation platform that helps patients find the right doctor, 
            dentist, or specialist based on real symptoms, location, language, and clinic availability — 
            without providing medical diagnosis.
          </motion.p>
        </div>
      </section>

      <div className="mx-auto max-w-[720px] px-4 py-12 md:px-6 md:py-16">
        {/* Platform Overview */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.3, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">What CareMap Does</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <FeatureCard icon={Search} title="Smart Search" description="Type symptoms and get directed to the right type of care — family doctor, dentist, or mental health provider." />
            <FeatureCard icon={Brain} title="AI Assistant" description="Conversational AI helps you describe needs, suggests doctor types, and shows matching results in real-time." />
            <FeatureCard icon={Filter} title="Powerful Filters" description="Filter by specialty, location, language spoken, wheelchair access, evening hours, and more." />
            <FeatureCard icon={MapPin} title="Ontario-Focused" description="Region-level search across Toronto, Ottawa, Hamilton, London, Kitchener-Waterloo, and more." />
            <FeatureCard icon={Languages} title="Language Matching" description="Find doctors who speak Mandarin, Arabic, Italian, Somali, Tamil, and 25+ languages." />
            <FeatureCard icon={Star} title="Verified Ratings" description="See patient ratings, review counts, and 'Accepting New Patients' badges in real-time." />
            <FeatureCard icon={Calendar} title="Availability View" description="Check next available appointment slots, estimated wait times, and clinic hours." />
            <FeatureCard icon={CheckCircle} title="Direct Registration" description="Send a registration request to the clinic directly through the platform — no phone calls needed." />
          </div>
        </motion.section>

        {/* User Journey */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.35, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">How It Works</h2>
          <div className="space-y-4">
            {[
              { step: '1', title: 'Describe Your Need', text: 'Type symptoms in the search bar or chat with the AI assistant. The AI suggests the right doctor type — family doctor, dentist, specialist, or mental health provider.' },
              { step: '2', title: 'Browse Verified Results', text: 'See a list of doctors matched to your needs. Each card shows name, specialty, clinic, distance, languages spoken, patient rating, wait time, and whether they are accepting new patients.' },
              { step: '3', title: 'Refine With Filters', text: 'Apply filters: location, language, specialty, accessibility, evening/weekend hours, maximum wait time, minimum rating.' },
              { step: '4', title: 'View Doctor Profile', text: 'See full doctor details: bio, education, clinic info with hours, available appointment slots, patient reviews, similar nearby doctors, and a verified badge.' },
              { step: '5', title: 'Request Registration', text: 'Fill a simple form (name, email, phone, optional note) and send your request. The clinic receives it and will contact you directly.' },
              { step: '6', title: 'Confirmation', text: 'Receive a confirmation: "Request sent. The clinic will contact you." — then return to browse more doctors or go home.' },
            ].map((item) => (
              <div key={item.step} className="flex gap-4 rounded-2xl border border-slate-100 bg-white p-5">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-600 text-sm font-bold text-white">{item.step}</div>
                <div>
                  <h3 className="mb-1 text-base font-semibold text-slate-900">{item.title}</h3>
                  <p className="text-sm leading-relaxed text-slate-600">{item.text}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* 20 Scenarios */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.4, ease: easeDefault }}>
          <h2 className="mb-2 text-2xl font-bold text-slate-900">Who It's For</h2>
          <p className="mb-6 text-sm text-slate-500">20 real-world scenarios CareMap is designed to solve</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {[
              'The Newcomer — Mandarin-speaking GP in North York',
              'Midnight Dental — Emergency clinic open past 8PM',
              'Cultural Fit — Italian-speaking specialist in Little Italy',
              'Student Access — Mental health near UofT campus',
              'After-Hours Parent — Pediatric Urgent Care <1hr wait',
              'Refugee Support — Clinics accepting IFHP coverage',
              'The "Unattached" — GPs accepting new patients today',
              'Accessibility — Wheelchair-accessible geriatric specialist',
              'Travel Prep — Rapid yellow fever vaccine clinic',
              'Safe Space — Gender-Affirming Care clinics',
              'Commuter Care — Optometrist near Union Station',
              'Queue Jumper — Shorter walk-in waits in Scarborough',
              'Post-Op — ACL-specialized physio with openings',
              'Hybrid Health — Naturopaths collaborating with MDs',
              'Fasting Lab — LifeLabs/Dynacare open at 6AM',
              'Commuter MD — Specialist near 400-series highway',
              'Social Care — Dental clinics accepting Ontario Works',
              'Executive Health — High-end clinics for annual physicals',
              'Med Inventory — Checking local pharmacy stock',
              'Critical Triage — "Chest Pain" triggers 911 overlay',
            ].map((scenario) => (
              <div key={scenario} className="flex items-start gap-2 rounded-xl border border-slate-100 bg-white p-3">
                <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
                <span className="text-sm text-slate-700">{scenario}</span>
              </div>
            ))}
          </div>
        </motion.section>

        {/* AI Assistant Deep Dive */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.45, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">AI Assistant</h2>
          <div className="space-y-3">
            <Accordion title="How the AI works" icon={MessageSquare}>
              <div className="space-y-3 text-sm text-slate-600">
                <p>The AI assistant uses simple keyword matching to guide users:</p>
                <ol className="space-y-2">
                  <li className="flex gap-2"><span className="font-semibold text-slate-900">1.</span><span>User types a message (e.g., "I need a family doctor in Ottawa")</span></li>
                  <li className="flex gap-2"><span className="font-semibold text-slate-900">2.</span><span>AI detects keywords ("family doctor", "Ottawa")</span></li>
                  <li className="flex gap-2"><span className="font-semibold text-slate-900">3.</span><span>AI responds with a contextual message + "Show Results" button</span></li>
                  <li className="flex gap-2"><span className="font-semibold text-slate-900">4.</span><span>Clicking "Show Results" navigates to the filtered doctor list</span></li>
                </ol>
                <div className="rounded-xl bg-blue-50 p-3">
                  <p className="text-xs font-medium text-blue-700">Example conversation:</p>
                  <p className="mt-1 text-xs text-slate-500"><strong>User:</strong> "I just moved to Ottawa and need a family doctor. I prefer someone who speaks Mandarin."</p>
                  <p className="text-xs text-slate-500"><strong>AI:</strong> "I found 4 family doctors in Ottawa accepting new patients who speak Mandarin. Would you like to see them?"</p>
                </div>
              </div>
            </Accordion>

            <Accordion title="Emergency Detection" icon={AlertTriangle}>
              <div className="space-y-3 text-sm text-slate-600">
                <p>The AI monitors every user input for emergency keywords. If detected, a full-screen emergency overlay appears immediately:</p>
                <div className="flex flex-wrap gap-2">
                  {['chest pain', "can't breathe", 'difficulty breathing', 'severe bleeding', 'unconscious', 'heart attack', 'stroke', 'suicide', 'overdose'].map((kw) => (
                    <span key={kw} className="rounded-md bg-red-50 px-2 py-1 text-xs font-medium text-red-600">{kw}</span>
                  ))}
                </div>
                <div className="rounded-xl border border-red-200 bg-red-50 p-3">
                  <p className="text-sm font-semibold text-red-600">⚠️ This sounds like an emergency</p>
                  <p className="mt-1 text-xs text-slate-600">The overlay shows: Call 911 button, Find Nearest ER button, and a dismiss option. No search results are shown for emergency queries.</p>
                </div>
              </div>
            </Accordion>
          </div>
        </motion.section>

        {/* Sample Doctor Data */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.5, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">Sample Doctor Data</h2>
          <p className="mb-4 text-sm text-slate-500">The platform uses a fully mocked database of doctors across Ontario. Here are 3 examples:</p>
          <div className="space-y-3">
            {[
              { name: 'Dr. Sarah Ahmed', specialty: 'Family Medicine', clinic: 'North York Family Health Centre', location: 'North York', languages: 'English, Arabic', accepting: true, wait: '14 days', rating: 4.8, reviews: 124 },
              { name: 'Dr. Michael Chen', specialty: 'Family Medicine', clinic: 'Scarborough Community Medical Clinic', location: 'Scarborough', languages: 'English, Mandarin', accepting: true, wait: '7 days', rating: 4.9, reviews: 89 },
              { name: 'Downtown Dental Care', specialty: 'Dentistry', clinic: 'Downtown Dental Care', location: 'Downtown Toronto', languages: 'English, Spanish', accepting: true, wait: '3 days', rating: 4.7, reviews: 203 },
            ].map((doc) => (
              <div key={doc.name} className="rounded-2xl border border-slate-100 bg-white p-5">
                <div className="mb-3 flex items-start justify-between">
                  <div>
                    <h3 className="text-base font-semibold text-slate-900">{doc.name}</h3>
                    <p className="text-sm text-slate-500">{doc.specialty} · {doc.clinic}</p>
                  </div>
                  {doc.accepting && (
                    <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-600">Accepting New Patients</span>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 sm:grid-cols-4">
                  <div className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5 text-slate-400" />{doc.location}</div>
                  <div className="flex items-center gap-1.5"><Globe className="h-3.5 w-3.5 text-slate-400" />{doc.languages}</div>
                  <div className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5 text-slate-400" />{doc.wait} wait</div>
                  <div className="flex items-center gap-1.5"><Star className="h-3.5 w-3.5 text-amber-500" />{doc.rating} ({doc.reviews})</div>
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* Filter Capabilities */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.55, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">Filter & Search Capabilities</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { icon: Stethoscope, label: 'Specialty', values: 'Family Medicine, Dentistry, Cardiology, Pediatrics, Mental Health, Physiotherapy, Dermatology' },
              { icon: MapPin, label: 'Location', values: 'Toronto, Ottawa, Hamilton, London, Kitchener-Waterloo, Mississauga, Brampton, Vaughan' },
              { icon: Globe, label: 'Language', values: 'English, Mandarin, Tamil, Arabic, French, Somali, Italian, Polish, Korean + 15 more' },
              { icon: Accessibility, label: 'Accessibility', values: 'Wheelchair accessible, Evening/Weekend hours, Parking, Transit nearby' },
              { icon: Clock, label: 'Availability', values: 'Accepting new patients, Max wait time, Next available slot' },
              { icon: Star, label: 'Quality', values: 'Minimum star rating (1-5), Number of reviews' },
              { icon: Briefcase, label: 'Insurance', values: 'OHIP accepted, IFHP (refugee coverage)' },
              { icon: Phone, label: 'Contact', values: 'Phone number, Clinic hours, Walk-in availability' },
            ].map((filter) => (
              <div key={filter.label} className="rounded-xl border border-slate-100 bg-white p-4">
                <div className="mb-2 flex items-center gap-2"><filter.icon className="h-4 w-4 text-blue-600" /><span className="text-sm font-semibold text-slate-900">{filter.label}</span></div>
                <p className="text-xs leading-relaxed text-slate-500">{filter.values}</p>
              </div>
            ))}
          </div>
        </motion.section>

        {/* Trust & Compliance */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.6, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">Trust & Compliance</h2>
          <div className="space-y-3">
            {[
              { icon: Shield, title: 'PHIPA Compliant', text: "All personal health information handling follows Ontario's Personal Health Information Protection Act. Data stored in Canada." },
              { icon: AlertTriangle, title: 'Non-Diagnostic AI', text: "The AI assistant explicitly does NOT provide medical diagnosis, treatment recommendations, or interpret symptoms. It only helps find care." },
              { icon: Building, title: 'Verified Clinic Data', text: "Doctor and clinic information is sourced from public CPSO/RCDSO registries and verified against official records." },
              { icon: Users, title: 'No Data Selling', text: "Your information is only shared with the clinic you choose to contact. We never sell or share data with third parties." },
            ].map((item) => (
              <div key={item.title} className="flex gap-4 rounded-2xl border border-slate-100 bg-white p-5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-50">
                  <item.icon className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="mb-1 text-base font-semibold text-slate-900">{item.title}</h3>
                  <p className="text-sm leading-relaxed text-slate-600">{item.text}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* Regions */}
        <motion.section className="mb-12" {...fadeInUp} transition={{ duration: 0.5, delay: 0.65, ease: easeDefault }}>
          <h2 className="mb-6 text-2xl font-bold text-slate-900">Ontario Regions</h2>
          <div className="rounded-2xl border border-slate-100 bg-white p-6">
            <p className="mb-4 text-sm text-slate-600">CareMap Ontario is launching region by region across the province.</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { name: 'Toronto', status: 'Live', color: 'bg-emerald-50 text-emerald-700' },
                { name: 'Ottawa', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
                { name: 'Hamilton', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
                { name: 'London', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
                { name: 'Kitchener-Waterloo', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
                { name: 'Mississauga', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
                { name: 'Brampton', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
                { name: 'Windsor', status: 'Coming Soon', color: 'bg-slate-50 text-slate-500' },
              ].map((region) => (
                <div key={region.name} className={`rounded-xl ${region.color} p-3 text-center`}>
                  <div className="text-sm font-semibold">{region.name}</div>
                  <div className="text-xs">{region.status}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* Disclaimer */}
        <motion.div className="rounded-2xl border border-red-200 bg-red-50 p-5" {...fadeInUp} transition={{ duration: 0.5, delay: 0.7, ease: easeDefault }}>
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
            <div>
              <p className="text-sm font-semibold text-red-600">Medical Disclaimer</p>
              <p className="mt-1 text-sm leading-relaxed text-slate-600">CareMap Ontario is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of a qualified healthcare provider. If you are experiencing a medical emergency, call 911 immediately.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
