import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate, useSearchParams } from 'react-router'
import { motion, AnimatePresence, useInView } from 'framer-motion'
import { toast } from 'sonner'
import {
  ChevronLeft,
  Star,
  CheckCircle,
  ShieldCheck,
  MapPin,
  Phone,
  Clock,
  Globe,
  Building,
  GraduationCap,
  ChevronRight,
} from 'lucide-react'
import {
  doctors,
  clinics,
  reviews,
  daySlots,
  timeSlots as timeSlotsData,
  similarDoctors,
} from '@/data/doctorProfiles'
import type { Doctor, DaySlot, TimeSlot } from '@/data/doctorProfiles'

/* ─── Animation presets ─── */
const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] } },
}

const scaleIn = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.4, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] } },
}

const slideInRight = {
  hidden: { opacity: 0, x: 20 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] } },
}

const staggerContainer = (stagger = 0.08) => ({
  hidden: {},
  visible: { transition: { staggerChildren: stagger } },
})

const staggerChild = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] } },
}

/* ─── Helpers ─── */
function getDoctorById(id: string | null): Doctor {
  return doctors.find((d) => d.id === id) ?? doctors[0]
}

/* ─── Star rating component ─── */
function StarRating({ rating, size = 18 }: { rating: number; size?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={size}
          className={
            i <= Math.round(rating)
              ? 'fill-[#F59E0B] text-[#F59E0B]'
              : 'fill-[#E2E8F0] text-[#E2E8F0]'
          }
        />
      ))}
    </div>
  )
}

/* ─── Section wrapper with scroll-trigger ─── */
function ScrollSection({
  children,
  className = '',
  variants = fadeInUp,
}: {
  children: React.ReactNode
  className?: string
  variants?: typeof fadeInUp
}) {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, amount: 0.15 })
  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={inView ? 'visible' : 'hidden'}
      variants={variants}
      className={className}
    >
      {children}
    </motion.div>
  )
}

/* ─── Main Profile Page ─── */
export default function Profile() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const doctorId = searchParams.get('doctor')
  const doctor = getDoctorById(doctorId)
  const clinic = clinics[doctor.id] ?? clinics['dr-priya-sharma']
  const reviewList = reviews[doctor.id] ?? reviews['dr-priya-sharma']
  const daySlotList = daySlots[doctor.id] ?? daySlots['dr-priya-sharma']
  const similarList = similarDoctors[doctor.id] ?? similarDoctors['dr-priya-sharma']

  const [selectedDay, setSelectedDay] = useState<DaySlot>(daySlotList[3]) // default Thu Mar 13
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [bioExpanded, setBioExpanded] = useState(false)
  const [showStickyCTA, setShowStickyCTA] = useState(false)

  const heroRef = useRef<HTMLDivElement>(null)

  /* Sticky CTA visibility after hero scrolls out */
  useEffect(() => {
    const hero = heroRef.current
    if (!hero) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        setShowStickyCTA(!entry.isIntersecting)
      },
      { threshold: 0, rootMargin: '-1px 0px 0px 0px' }
    )
    observer.observe(hero)
    return () => observer.disconnect()
  }, [])

  const currentSlots: TimeSlot[] =
    timeSlotsData[selectedDay.fullDate] ?? timeSlotsData['2025-03-13']

  const handleDaySelect = useCallback((day: DaySlot) => {
    setSelectedDay(day)
    setSelectedTime(null)
  }, [])

  const handleRequestAttachment = useCallback(() => {
    navigate(`/register?doctor=${doctor.id}`)
  }, [navigate, doctor.id])

  const handlePhoneClick = useCallback(() => {
    toast(`Calling ${clinic.phone}...`)
  }, [clinic.phone])

  const handleAddressClick = useCallback(() => {
    toast('Opening map...')
  }, [])

  const today = new Date().toLocaleDateString('en-CA', { weekday: 'short' }) // e.g. "Mon"

  return (
    <div className="relative mx-auto max-w-[720px]">
      {/* ── Profile Header ── */}
      <div ref={heroRef} className="bg-white">
        {/* Back button */}
        <div className="px-4 pt-4 md:px-6">
          <button
            onClick={() => navigate('/results')}
            className="inline-flex items-center gap-1 rounded-lg py-2 text-xs font-medium text-slate-700 transition-colors hover:text-medical-700"
          >
            <ChevronLeft size={16} />
            Results
          </button>
        </div>

        {/* Profile Card */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={staggerContainer(0.08)}
          className="mx-4 mb-6 mt-2 rounded-[20px] bg-[#EFF6FF] p-6 text-center md:mx-6"
        >
          {/* Avatar */}
          <motion.div variants={scaleIn} className="relative mx-auto inline-block">
            <img
              src={doctor.photoUrl}
              alt={`Photo of ${doctor.name}`}
              className="h-24 w-24 rounded-full border-[3px] border-white object-cover shadow-[0_2px_8px_rgba(15,23,42,0.1)]"
            />
            <div className="absolute -right-1 -bottom-1 flex h-6 w-6 items-center justify-center rounded-full bg-medical-600">
              <ShieldCheck size={14} className="text-white" />
            </div>
          </motion.div>

          {/* Name & Specialty */}
          <motion.h1
            variants={staggerChild}
            className="mt-4 text-[28px] font-bold leading-[1.2] tracking-[-0.01em] text-slate-900"
          >
            {doctor.name}
          </motion.h1>
          <motion.p
            variants={staggerChild}
            className="mt-1 text-base font-medium text-medical-600"
          >
            {doctor.specialty}
          </motion.p>

          {/* Rating */}
          <motion.div
            variants={staggerChild}
            className="mt-2 inline-flex items-center gap-2"
          >
            <StarRating rating={doctor.rating} />
            <span className="text-base font-semibold text-slate-900">{doctor.rating}</span>
            <button
              onClick={() => {
                const el = document.getElementById('reviews-section')
                el?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="text-sm text-slate-500 underline transition-colors hover:text-medical-600"
            >
              ({doctor.reviewCount} reviews)
            </button>
          </motion.div>

          {/* Badges */}
          <motion.div
            variants={staggerContainer(0.08)}
            className="mt-4 flex flex-wrap items-center justify-center gap-2"
          >
            {doctor.acceptingNewPatients && (
              <motion.span
                variants={staggerChild}
                className="inline-flex items-center gap-1.5 rounded-md bg-[#16A34A] px-2.5 py-1 text-xs font-medium text-white"
              >
                <CheckCircle size={12} />
                Accepting New Patients
              </motion.span>
            )}
            {doctor.ohip && (
              <motion.span
                variants={staggerChild}
                className="inline-flex items-center gap-1.5 rounded-md border border-medical-200 bg-[#EFF6FF] px-2.5 py-1 text-xs font-medium text-medical-700"
              >
                <ShieldCheck size={12} />
                OHIP
              </motion.span>
            )}
            <motion.span
              variants={staggerChild}
              className="inline-flex items-center gap-1.5 rounded-md border border-medical-200 bg-[#EFF6FF] px-2.5 py-1 text-xs font-medium text-medical-700"
            >
              <ShieldCheck size={12} />
              Verified
            </motion.span>
          </motion.div>

          {/* Top CTA */}
          <motion.div variants={staggerChild} className="mt-6">
            <button
              onClick={handleRequestAttachment}
              className="w-full rounded-xl bg-[#3B82F6] px-7 py-3.5 text-base font-semibold text-white shadow-[0_1px_2px_rgba(59,130,246,0.2)] transition-all hover:bg-[#2563DB] hover:scale-[1.02] active:scale-[0.98]"
            >
              Request Attachment
            </button>
            <p className="mt-2 text-xs text-slate-500">
              Typically responds within 2 business days
            </p>
          </motion.div>
        </motion.div>
      </div>

      {/* ── Quick Info Bar ── */}
      <ScrollSection className="border-b border-slate-200 bg-white px-4 py-4 md:px-6">
        <motion.div
          variants={staggerContainer(0.06)}
          className="flex gap-3 overflow-x-auto pb-1 scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          <motion.div
            variants={staggerChild}
            className="flex min-w-[140px] flex-col items-center gap-1 rounded-xl border border-slate-200 bg-white px-4 py-3"
          >
            <Clock size={20} className="text-medical-600" />
            <span className="text-xs font-medium text-slate-500">Wait Time</span>
            <span className="text-sm font-medium text-slate-900">~{doctor.waitTimeDays} days</span>
          </motion.div>
          <motion.div
            variants={staggerChild}
            className="flex min-w-[140px] flex-col items-center gap-1 rounded-xl border border-slate-200 bg-white px-4 py-3"
          >
            <MapPin size={20} className="text-medical-600" />
            <span className="text-xs font-medium text-slate-500">Distance</span>
            <span className="text-sm font-medium text-slate-900">{doctor.distanceKm} km away</span>
          </motion.div>
          <motion.div
            variants={staggerChild}
            className="flex min-w-[140px] flex-col items-center gap-1 rounded-xl border border-slate-200 bg-white px-4 py-3"
          >
            <Globe size={20} className="text-medical-600" />
            <span className="text-xs font-medium text-slate-500">Languages</span>
            <span className="text-sm font-medium text-slate-900">{doctor.languages.join(', ')}</span>
          </motion.div>
          <motion.div
            variants={staggerChild}
            className="flex min-w-[140px] flex-col items-center gap-1 rounded-xl border border-slate-200 bg-white px-4 py-3"
          >
            <Building size={20} className="text-medical-600" />
            <span className="text-xs font-medium text-slate-500">Clinic</span>
            <span className="text-sm font-medium text-slate-900">{doctor.clinicName}</span>
          </motion.div>
        </motion.div>
      </ScrollSection>

      {/* ── About ── */}
      <ScrollSection className="bg-white px-4 py-6 md:px-6">
        <h2 className="text-[22px] font-semibold leading-[1.3] text-slate-900">About</h2>
        <div className="mt-3">
          <p
            className={`text-base leading-[1.7] text-slate-700 ${bioExpanded ? '' : 'line-clamp-4'}`}
          >
            {doctor.bio}
          </p>
          <button
            onClick={() => setBioExpanded(!bioExpanded)}
            className="mt-2 text-xs font-medium text-medical-600 transition-colors hover:text-medical-700"
          >
            {bioExpanded ? 'Read less' : 'Read more'}
          </button>
        </div>
        <div className="mt-5">
          <h4 className="mb-2 text-base font-semibold text-slate-900">Education</h4>
          <ul className="space-y-2">
            {doctor.education.map((edu, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                <GraduationCap size={16} className="mt-0.5 shrink-0 text-slate-400" />
                {edu}
              </li>
            ))}
          </ul>
        </div>
      </ScrollSection>

      {/* ── Clinic Information ── */}
      <ScrollSection className="border-b border-slate-200 bg-white px-4 py-6 md:px-6">
        <h2 className="text-[22px] font-semibold leading-[1.3] text-slate-900">Clinic</h2>
        <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_1px_2px_rgba(15,23,42,0.05)]">
          <img
            src="/clinic-exterior-1.jpg"
            alt={`${clinic.name} exterior`}
            className="h-[180px] w-full rounded-xl object-cover"
          />
          <h3 className="mt-4 text-lg font-semibold text-slate-900">{clinic.name}</h3>

          <div className="mt-3 space-y-2">
            <button
              onClick={handleAddressClick}
              className="flex items-start gap-2 text-left text-sm text-slate-700 transition-colors hover:text-medical-600"
            >
              <MapPin size={16} className="mt-0.5 shrink-0 text-slate-400" />
              {clinic.address}
            </button>
            <button
              onClick={handlePhoneClick}
              className="flex items-start gap-2 text-left text-sm text-medical-600 underline transition-colors hover:text-medical-700"
            >
              <Phone size={16} className="mt-0.5 shrink-0 text-slate-400" />
              {clinic.phone}
            </button>
            <div className="flex items-start gap-2 text-sm text-slate-700">
              <Clock size={16} className="mt-0.5 shrink-0 text-slate-400" />
              <div className="space-y-0.5">
                {clinic.hours.map((h) => (
                  <div key={h.day} className="flex gap-2">
                    <span className={h.day === today ? 'font-semibold text-medical-600' : ''}>
                      {h.day}:
                    </span>
                    <span>
                      {h.open === 'Closed' ? 'Closed' : `${h.open} – ${h.close}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div className="mt-3 flex flex-wrap gap-2">
            {doctor.wheelchair && (
              <span className="inline-flex items-center rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700">
                Wheelchair Accessible
              </span>
            )}
            {clinic.parking && (
              <span className="inline-flex items-center rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700">
                Parking
              </span>
            )}
            {clinic.transitNearby.length > 0 && (
              <span className="inline-flex items-center rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700">
                Transit Nearby
              </span>
            )}
            {doctor.eveningWeekend && (
              <span className="inline-flex items-center rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700">
                Evening Hours
              </span>
            )}
          </div>
        </div>
      </ScrollSection>

      {/* ── Availability Calendar ── */}
      <ScrollSection className="bg-white px-4 py-6 md:px-6">
        <h2 className="text-[22px] font-semibold leading-[1.3] text-slate-900">
          Next Available Appointments
        </h2>
        <p className="mt-1 text-sm text-slate-500">
          These are estimated first-visit slots for new patients.
        </p>

        {/* Week Strip */}
        <motion.div
          variants={staggerContainer(0.04)}
          className="mt-4 flex gap-2 overflow-x-auto pb-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {daySlotList.map((day) => {
            const isSelected = selectedDay.fullDate === day.fullDate
            const isToday = day.day === today
            return (
              <motion.button
                key={day.fullDate}
                variants={staggerChild}
                onClick={() => handleDaySelect(day)}
                whileTap={{ scale: 0.97 }}
                className={`flex h-20 w-[72px] shrink-0 flex-col items-center justify-center gap-0.5 rounded-[14px] border transition-colors duration-150 ${
                  isSelected
                    ? 'border-2 border-teal-600 bg-medical-600 text-white'
                    : isToday
                    ? 'border border-slate-200 bg-[#EFF6FF] text-slate-900'
                    : 'border border-slate-200 bg-white text-slate-900'
                }`}
              >
                <span
                  className={`text-xs font-medium ${
                    isSelected ? 'text-white' : 'text-slate-500'
                  }`}
                >
                  {day.day}
                </span>
                <span className="text-base font-semibold">{day.date.split(' ')[1]}</span>
                <span
                  className={`text-[10px] font-medium ${
                    isSelected
                      ? 'text-white'
                      : day.slots > 0
                      ? 'text-medical-600'
                      : 'text-slate-400'
                  }`}
                >
                  {day.slots > 0 && (
                    <span className="mr-1 inline-block h-1.5 w-1.5 rounded-full bg-medical-500" />
                  )}
                  {day.label}
                </span>
              </motion.button>
            )
          })}
        </motion.div>

        {/* Time Slots */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedDay.fullDate}
            initial="hidden"
            animate="visible"
            exit="hidden"
            variants={staggerContainer(0.03)}
            className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4"
          >
            {currentSlots.map((slot) => {
              const isSelected = selectedTime === slot.time
              const isBooked = slot.status === 'booked'
              const isUnavailable = slot.status === 'unavailable'
              const disabled = isBooked || isUnavailable
              return (
                <motion.button
                  key={slot.time}
                  variants={staggerChild}
                  whileTap={!disabled ? { scale: 0.97 } : undefined}
                  onClick={() => !disabled && setSelectedTime(slot.time)}
                  disabled={disabled}
                  className={`rounded-[10px] border px-3 py-3 text-center text-sm font-medium transition-colors duration-150 ${
                    isSelected
                      ? 'border-teal-600 bg-medical-600 text-white'
                      : disabled
                      ? 'border-slate-100 bg-slate-100 text-slate-400 line-through'
                      : 'border-slate-200 bg-white text-slate-900 hover:border-medical-300 hover:bg-[#EFF6FF]'
                  }`}
                >
                  {slot.time}
                </motion.button>
              )
            })}
          </motion.div>
        </AnimatePresence>
      </ScrollSection>

      {/* ── Reviews Preview ── */}
      <div id="reviews-section" className="border-b border-slate-200 bg-white px-4 py-6 md:px-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-[22px] font-semibold leading-[1.3] text-slate-900">Patient Reviews</h2>
          <button className="inline-flex items-center gap-1 text-xs font-medium text-medical-600 transition-colors hover:text-medical-700">
            See all {doctor.reviewCount}
            <ChevronRight size={14} />
          </button>
        </div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          variants={staggerContainer(0.1)}
          className="flex gap-3 overflow-x-auto pb-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {reviewList.map((review) => (
            <motion.div
              key={review.id}
              variants={slideInRight}
              className="w-[280px] shrink-0 rounded-[14px] bg-white p-4"
            >
              <StarRating rating={review.rating} size={14} />
              <div className="mt-2 flex items-center gap-2">
                <span className="text-sm font-medium text-slate-700">{review.reviewer}</span>
                <span className="text-xs text-slate-500">{review.date}</span>
              </div>
              <p className="mt-2 line-clamp-3 text-sm leading-[1.5] text-slate-700">
                {review.text}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* ── Similar Doctors ── */}
      <ScrollSection className="bg-white px-4 py-6 pb-8 md:px-6">
        <h2 className="text-[22px] font-semibold leading-[1.3] text-slate-900">
          Similar Doctors Nearby
        </h2>
        <motion.div
          variants={staggerContainer(0.08)}
          className="mt-4 flex gap-3 overflow-x-auto pb-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {similarList.map((sim) => (
            <motion.button
              key={sim.id}
              variants={staggerChild}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate(`/profile?doctor=${sim.id}`)}
              className="w-[220px] shrink-0 rounded-2xl bg-white p-4 text-left shadow-[0_1px_3px_rgba(15,23,42,0.06),0_1px_2px_rgba(15,23,42,0.04)] transition-shadow hover:shadow-[0_4px_12px_rgba(15,23,42,0.08)]"
            >
              <div className="flex items-center gap-3">
                <img
                  src={sim.photoUrl}
                  alt={sim.name}
                  className="h-12 w-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="text-base font-semibold text-slate-900">{sim.name}</h4>
                  <p className="text-xs font-medium text-medical-600">{sim.specialty}</p>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <StarRating rating={sim.rating} size={12} />
                <span className="text-xs font-medium text-slate-700">{sim.rating}</span>
              </div>
              <p className="mt-1 text-xs text-slate-500">{sim.distanceKm} km away</p>
            </motion.button>
          ))}
        </motion.div>
      </ScrollSection>

      {/* ── Sticky Bottom CTA ── */}
      <AnimatePresence>
        {showStickyCTA && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
            className="fixed bottom-0 left-0 right-0 z-50 border-t border-slate-200 bg-white shadow-[0_-4px_16px_rgba(15,23,42,0.06)]"
          >
            <div className="mx-auto flex max-w-[720px] items-center justify-between gap-4 px-5 py-4">
              <div className="flex flex-col gap-0.5">
                {doctor.acceptingNewPatients && (
                  <span className="text-xs font-medium text-[#16A34A]">Accepting new patients</span>
                )}
                {doctor.ohip && (
                  <span className="text-xs text-slate-500">OHIP covered</span>
                )}
              </div>
              <button
                onClick={handleRequestAttachment}
                className="rounded-xl bg-[#3B82F6] px-6 py-3 text-sm font-semibold text-white shadow-[0_1px_2px_rgba(59,130,246,0.2)] transition-all hover:bg-[#2563DB] hover:scale-[1.02] active:scale-[0.98] max-[400px]:w-full max-[400px]:px-4"
              >
                Request Attachment
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
