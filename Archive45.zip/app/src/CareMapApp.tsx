import { useMemo, useState, useEffect, useRef, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Search, MapPin, ShieldCheck, Sparkles, Stethoscope, Languages, Star, Clock,
  CalendarCheck, AlertTriangle, HeartPulse, UserRound, Filter, ChevronRight,
  Phone, CheckCircle2, Building2, MessageCircle, Globe2, LockKeyhole,
  ArrowRight, X, Bot, Check, ChevronDown, Download, Apple, Smartphone,
  MessageSquare, Send, Menu, CloseIcon, Activity, Users,
} from "lucide-react"
import { Link } from "react-router"

type Doctor = {
  id: number; name: string; clinic: string; specialty: string; location: string;
  distance: string; languages: string[]; accepting: boolean; wait: string;
  rating: number; reviews: number; tags: string[]; bio: string;
}

type ChatMsg = { from: "ai" | "user"; text: string }

const doctors: Doctor[] = [
  { id: 1, name: "Dr. Sarah Ahmed", clinic: "North York Family Health Centre", specialty: "Family Physician", location: "North York", distance: "3.2 km", languages: ["English", "Arabic"], accepting: true, wait: "3–5 days", rating: 4.8, reviews: 126, tags: ["Family care", "Women's health"], bio: "Focused on long-term primary care, preventative health, and accessible family medicine." },
  { id: 2, name: "Dr. Michael Chen", clinic: "Scarborough Community Medical Clinic", specialty: "Family Physician", location: "Scarborough", distance: "6.8 km", languages: ["English", "Mandarin"], accepting: true, wait: "2–4 days", rating: 4.7, reviews: 94, tags: ["Immigrant care", "Chronic care"], bio: "Primary care physician supporting multilingual families and routine healthcare needs." },
  { id: 3, name: "Dr. Laura Rossi", clinic: "Vaughan Family Practice", specialty: "Family Physician", location: "Vaughan", distance: "11.4 km", languages: ["English", "Italian"], accepting: true, wait: "5–7 days", rating: 4.6, reviews: 81, tags: ["Senior care", "Preventative care"], bio: "Family doctor with experience supporting seniors, families, and preventative care planning." },
  { id: 4, name: "Downtown Dental Care", clinic: "Downtown Dental Care", specialty: "Dental Clinic", location: "Downtown Toronto", distance: "1.1 km", languages: ["English", "Spanish"], accepting: true, wait: "Same day", rating: 4.9, reviews: 211, tags: ["Emergency dental", "Open late"], bio: "Dental clinic offering emergency dental appointments and extended evening hours." },
  { id: 5, name: "Toronto Mind Wellness", clinic: "Toronto Mind Wellness", specialty: "Mental Health Provider", location: "Downtown Toronto", distance: "2.4 km", languages: ["English", "French"], accepting: true, wait: "1–2 days", rating: 4.8, reviews: 153, tags: ["Virtual care", "Anxiety support", "Counselling"], bio: "Mental health clinic offering in-person and virtual counselling support." },
]

const clinics = [
  { name: "North York Family Health Centre", location: "North York", type: "Family Medicine", patients: "2,400+", rating: 4.8 },
  { name: "Scarborough Community Medical Clinic", location: "Scarborough", type: "Family Medicine", patients: "1,800+", rating: 4.7 },
  { name: "Downtown Dental Care", location: "Downtown Toronto", type: "Dental", patients: "3,200+", rating: 4.9 },
  { name: "Toronto Mind Wellness", location: "Downtown Toronto", type: "Mental Health", patients: "1,500+", rating: 4.8 },
  { name: "Vaughan Family Practice", location: "Vaughan", type: "Family Medicine", patients: "1,900+", rating: 4.6 },
]

const regions = [
  { name: "Toronto", status: "active", pop: "2.9M" },
  { name: "Ottawa", status: "coming", pop: "1.0M" },
  { name: "Hamilton", status: "coming", pop: "580K" },
  { name: "London", status: "coming", pop: "420K" },
  { name: "Kitchener-Waterloo", status: "coming", pop: "520K" },
  { name: "Mississauga", status: "coming", pop: "720K" },
  { name: "Brampton", status: "coming", pop: "660K" },
  { name: "Windsor", status: "coming", pop: "230K" },
]

const emergencyKw = ["chest pain", "shortness of breath", "severe bleeding", "stroke", "heart attack", "can't breathe", "cant breathe", "unconscious"]
const announcements = ["CareMap Ontario is now live in Toronto", "AI healthcare navigation — not diagnosis", "Helping patients find the right care instantly", "Over 2.2M Ontarians lack a primary care provider", "PHIPA-aware and privacy-first", "More Ontario regions coming soon"]

function classify(input: string) {
  const t = input.toLowerCase()
  if (emergencyKw.some(w => t.includes(w))) return "emergency"
  if (t.includes("tooth") || t.includes("dental") || t.includes("dentist")) return "dental"
  if (t.includes("anxiety") || t.includes("stress") || t.includes("mental")) return "mental"
  return "family"
}

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.5, delay: i * 0.08 } }) }
const staggerContainer = { hidden: {}, visible: { transition: { staggerChildren: 0.06 } } }

export default function CareMapApp() {
  const [query, setQuery] = useState("")
  const [need, setNeed] = useState("family")
  const [searched, setSearched] = useState(false)
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor>(doctors[0])
  const [showEmergency, setShowEmergency] = useState(false)
  const [language, setLanguage] = useState("All")
  const [specialty, setSpecialty] = useState("All")
  const [showForm, setShowForm] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [showChatPopup, setShowChatPopup] = useState(false)
  const [activeTab, setActiveTab] = useState("patients")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [heroPassed, setHeroPassed] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => { const h = () => setHeroPassed(window.scrollY > 80); window.addEventListener("scroll", h); return () => window.removeEventListener("scroll", h) }, [])

  const filteredDoctors = useMemo(() => {
    let base = [...doctors]
    if (need === "family") base = base.filter(d => d.specialty === "Family Physician")
    if (need === "dental") base = base.filter(d => d.specialty === "Dental Clinic")
    if (need === "mental") base = base.filter(d => d.specialty === "Mental Health Provider")
    if (language !== "All") base = base.filter(d => d.languages.includes(language))
    if (specialty !== "All") base = base.filter(d => d.specialty === specialty)
    return base
  }, [need, language, specialty])

  const runSearch = useCallback((value = query) => {
    const type = classify(value || "family doctor")
    if (type === "emergency") { setShowEmergency(true); return }
    setNeed(type); setSearched(true); setActiveTab("patients")
    const match = doctors.find(d => { if (type === "dental") return d.specialty === "Dental Clinic"; if (type === "mental") return d.specialty === "Mental Health Provider"; return d.specialty === "Family Physician" }) || doctors[0]
    setSelectedDoctor(match)
    setTimeout(() => heroRef.current?.scrollIntoView({ behavior: "smooth" }), 50)
  }, [query])

  const quickSearch = useCallback((text: string) => {
    setQuery(text); const type = classify(text)
    if (type === "emergency") { setShowEmergency(true); return }
    setNeed(type); setSearched(true); setActiveTab("patients")
    setTimeout(() => heroRef.current?.scrollIntoView({ behavior: "smooth" }), 50)
  }, [])

  const assistant = (() => {
    if (need === "dental") return { title: "Dental care may be the right next step.", text: "CareMap can show dental clinics near you with emergency availability, reviews, and language filters." }
    if (need === "mental") return { title: "A mental health provider may be appropriate.", text: "CareMap can guide you to in-person or virtual mental health providers based on location, language, and availability." }
    return { title: "A family physician may be the right care path.", text: "CareMap found family doctors near you who may be accepting new patients. You can filter by language, area, and estimated wait time." }
  })()

  const explanation = (() => {
    const q = query || "family doctor"
    if (need === "dental") return { heading: "Dental care request analyzed", lines: [`You are looking for dental care: "${q}"`, "CareMap identified dental clinics in your area that may be accepting new patients.", "You can refine by language, distance, or availability."] }
    if (need === "mental") return { heading: "Mental health support identified", lines: [`You are looking for mental health support: "${q}"`, "CareMap identified mental health providers in your area that may be accepting new patients.", "You can refine by language, distance, or availability."] }
    return { heading: "Family physician request analyzed", lines: [`You are looking for a family physician for ongoing care: "${q}"`, "CareMap identified providers in your area that may be accepting new patients.", "You can refine by language, distance, or availability."] }
  })()

  const tabs = [
    { id: "patients", label: "Patients", icon: UserRound },
    { id: "doctors", label: "Doctors", icon: Stethoscope },
    { id: "clinics", label: "Clinics", icon: Building2 },
    { id: "ai", label: "AI Assistant", icon: Sparkles },
    { id: "regions", label: "Regions", icon: MapPin },
    { id: "download", label: "Download App", icon: Download },
  ]

  return (
    <div className="min-h-screen bg-[#f7faff] text-slate-950">
      <AnimatePresence>{showEmergency && <EmergencyModal onClose={() => setShowEmergency(false)} />}</AnimatePresence>

      {/* Announcement Bar */}
      <div className="relative overflow-hidden bg-blue-950 py-2.5 text-white">
        <div className="animate-marquee flex whitespace-nowrap">
          {[...announcements, ...announcements, ...announcements].map((t, i) => (
            <span key={i} className="mx-8 flex items-center gap-2 text-xs font-semibold tracking-wide text-blue-100"><Sparkles size={12} className="text-blue-300" />{t}</span>
          ))}
        </div>
      </div>

      {/* Header */}
      <header className={`sticky top-0 z-40 border-b transition-all duration-300 ${heroPassed ? "border-blue-100 bg-white/95 shadow-lg shadow-blue-900/5 backdrop-blur-xl" : "border-transparent bg-white/60 backdrop-blur-md"}`}>
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/25"><HeartPulse size={22} /></div>
            <div><div className="text-base font-bold tracking-tight">CareMap Ontario</div><div className="text-[11px] font-medium text-slate-400">AI healthcare navigation — not diagnosis</div></div>
          </div>
          <nav className="hidden items-center gap-1 lg:flex">
            {tabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition ${activeTab === tab.id ? "bg-blue-600 text-white shadow-md shadow-blue-600/20" : "text-slate-500 hover:bg-blue-50 hover:text-blue-700"}`}>
                <tab.icon size={14} />{tab.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/about" className="hidden rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-slate-900/15 transition hover:scale-[1.02] md:block">Learn More</Link>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700 lg:hidden">{mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}</button>
          </div>
        </div>
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden border-t border-slate-100 bg-white lg:hidden">
              <div className="space-y-1 px-5 py-4">
                {tabs.map(t => <button key={t.id} onClick={() => { setActiveTab(t.id); setMobileMenuOpen(false) }} className={`flex w-full items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium ${activeTab === t.id ? "bg-blue-50 text-blue-700" : "text-slate-600"}`}><t.icon size={16} />{t.label}</button>)}
                <Link to="/about" className="flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium text-slate-600" onClick={() => setMobileMenuOpen(false)}><ArrowRight size={16} />Learn More</Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {activeTab === "patients" && (
          <motion.div key="patients" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
            {/* Full-Screen Hero */}
            <section className="relative flex min-h-[92dvh] flex-col items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-950 via-blue-900 to-slate-900" />
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0aDR2NGgtNHpNMjQgMjRoNHY0aC00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-50" />
              <div className="absolute left-1/4 top-1/3 h-72 w-72 rounded-full bg-blue-500/20 blur-3xl animate-pulse" />
              <div className="absolute bottom-1/3 right-1/4 h-96 w-96 rounded-full bg-indigo-400/10 blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {[Stethoscope, HeartPulse, Activity, ShieldCheck, Globe2].map((Icon, i) => (
                  <motion.div key={i} className="absolute text-white/[0.04]" style={{ left: `${10 + i * 20}%`, top: `${15 + (i % 3) * 25}%` }}
                    animate={{ y: [0, -20, 0], rotate: [0, 5, -5, 0] }} transition={{ duration: 6 + i * 2, repeat: Infinity, ease: "easeInOut" }}>
                    <Icon size={80 + i * 20} />
                  </motion.div>
                ))}
              </div>
              <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
                  className="mb-8 inline-flex items-center gap-2 rounded-full border border-blue-400/30 bg-white/10 px-5 py-2 text-sm font-medium text-blue-100 backdrop-blur-md">
                  <MapPin size={16} className="text-blue-300" /><span>Active region:</span><span className="font-bold text-white">Toronto</span><span className="ml-2 rounded-full bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-300">LIVE</span>
                </motion.div>
                <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.15 }}
                  className="text-6xl font-bold tracking-tight text-white md:text-8xl">
                  Find the right care<span className="block bg-gradient-to-r from-blue-300 via-white to-blue-200 bg-clip-text text-transparent">in Ontario</span>
                </motion.h1>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.35 }}
                  className="mx-auto mt-8 max-w-2xl text-xl leading-relaxed text-blue-100/70">
                  AI healthcare navigation — not diagnosis.<br />Helping patients find the right care instantly.
                </motion.p>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.5 }}
                  className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
                  <button onClick={() => document.getElementById('search-area')?.scrollIntoView({ behavior: 'smooth' })}
                    className="flex items-center gap-2 rounded-2xl bg-white px-8 py-4 text-lg font-bold text-blue-900 shadow-2xl shadow-white/20 transition hover:scale-[1.02]"><Search size={20} />Find Care Now</button>
                  <button onClick={() => { setActiveTab("ai") }}
                    className="flex items-center gap-2 rounded-2xl border border-white/20 bg-white/10 px-8 py-4 text-lg font-semibold text-white backdrop-blur-md transition hover:bg-white/20"><Sparkles size={20} />Try AI Search</button>
                </motion.div>
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.7 }} className="mt-16 grid grid-cols-3 gap-4 sm:gap-8 max-w-lg mx-auto">
                  <div><div className="text-3xl font-bold text-white md:text-4xl">2.2M+</div><div className="mt-1 text-sm text-blue-200/60">Unattached patients</div></div>
                  <div><div className="text-3xl font-bold text-white md:text-4xl">5,000+</div><div className="mt-1 text-sm text-blue-200/60">Verified providers</div></div>
                  <div><div className="text-3xl font-bold text-white md:text-4xl">25+</div><div className="mt-1 text-sm text-blue-200/60">Languages</div></div>
                </motion.div>
              </div>
              <motion.div className="absolute bottom-8 left-1/2 -translate-x-1/2" animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity }}>
                <ChevronDown size={28} className="text-white/30" />
              </motion.div>
            </section>

            {/* Region Selector */}
            <section className="border-y border-blue-100 bg-white">
              <div className="mx-auto max-w-7xl px-5 py-5">
                <div className="flex items-center gap-4 overflow-x-auto pb-2">
                  <span className="shrink-0 text-sm font-bold text-slate-400">Select region:</span>
                  {regions.map(r => (
                    <button key={r.name} disabled={r.status !== "active"}
                      className={`shrink-0 flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium transition ${r.status === "active" ? "bg-blue-600 text-white shadow-md shadow-blue-600/20" : "bg-slate-100 text-slate-400 cursor-not-allowed"}`}>
                      <MapPin size={14} />{r.name}{r.status === "active" ? <span className="ml-1 rounded-full bg-white/20 px-1.5 py-0.5 text-[10px] font-bold">LIVE</span> : <span className="ml-1 rounded-full bg-slate-200 px-1.5 py-0.5 text-[10px] font-bold">SOON</span>}
                    </button>
                  ))}
                </div>
              </div>
            </section>

            {/* Search + AI Panel */}
            <div id="search-area" ref={heroRef} className="relative overflow-hidden">
              <div className="absolute left-1/2 top-0 h-[460px] w-[900px] -translate-x-1/2 rounded-full bg-blue-200/50 blur-3xl" />
              <div className="relative mx-auto grid max-w-7xl gap-10 px-5 py-12 lg:grid-cols-[1.05fr_0.95fr] lg:py-20">
                <motion.div variants={staggerContainer} initial="hidden" whileInView="visible" viewport={{ once: true }}>
                  <motion.div variants={fadeUp} className="mb-5 inline-flex items-center gap-2 rounded-full border border-blue-100 bg-white px-4 py-2 text-sm font-medium text-blue-700 shadow-sm"><Sparkles size={16} />Healthcare Navigation Layer</motion.div>
                  <motion.h2 variants={fadeUp} className="max-w-3xl text-4xl font-bold tracking-tight text-slate-950 md:text-5xl">What care do you need?</motion.h2>
                  <motion.p variants={fadeUp} className="mt-4 max-w-2xl text-lg leading-8 text-slate-500">Describe your symptoms or care needs. CareMap's AI will guide you to the right provider — without providing medical diagnosis.</motion.p>
                  <motion.div variants={fadeUp} className="mt-8 rounded-[2rem] border border-white bg-white p-3 shadow-2xl shadow-blue-900/10">
                    <div className="flex flex-col gap-3 md:flex-row">
                      <div className="flex flex-1 items-center gap-3 rounded-2xl bg-slate-50 px-4 py-3">
                        <Search className="text-blue-600 shrink-0" size={22} />
                        <input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && runSearch()} placeholder="What are you feeling or looking for?" className="w-full bg-transparent text-base outline-none placeholder:text-slate-400" />
                      </div>
                      <button onClick={() => runSearch()} className="rounded-2xl bg-blue-600 px-7 py-4 font-semibold text-white shadow-lg shadow-blue-600/25 transition hover:scale-[1.01] hover:bg-blue-700">Find Care</button>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2 px-1">
                      <QBtn label="I need a family doctor" onClick={() => quickSearch("I need a family doctor")} />
                      <QBtn label="I have tooth pain" onClick={() => quickSearch("I have tooth pain")} />
                      <QBtn label="I feel anxious" onClick={() => quickSearch("I feel anxious")} />
                      <QBtn label="Chest pain" danger onClick={() => quickSearch("chest pain")} />
                    </div>
                  </motion.div>
                  <motion.div variants={fadeUp} className="mt-8 grid max-w-2xl grid-cols-3 gap-3">
                    <Metric value="3 clicks" label="from search to doctor" />
                    <Metric value="0" label="diagnosis claims" />
                    <Metric value="24/7" label="navigation layer" />
                  </motion.div>
                </motion.div>
                <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}>
                  <AIPanel searched={searched} assistant={assistant} filteredDoctors={filteredDoctors} onDoctor={setSelectedDoctor} />
                </motion.div>
              </div>
            </div>

            {/* Results */}
            {searched && (
              <section className="mx-auto grid max-w-7xl gap-6 px-5 pb-16 lg:grid-cols-[0.95fr_1.05fr]">
                <div className="space-y-5">
                  <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
                    className="rounded-[2rem] border border-blue-100 bg-blue-50 p-6">
                    <div className="mb-4 flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-600 text-white"><Bot size={22} /></div>
                      <div><div className="text-sm font-bold text-blue-900">Based on your request</div><div className="text-xs text-blue-600">CareMap AI analysis</div></div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-slate-800">{explanation.heading}</p>
                      {explanation.lines.map((line, i) => <p key={i} className="text-sm leading-6 text-slate-600">{line}</p>)}
                    </div>
                  </motion.div>
                  <div className="rounded-[2rem] border border-white bg-white p-5 shadow-xl shadow-blue-900/5">
                    <div className="mb-4 flex items-center justify-between">
                      <div><h2 className="text-2xl font-bold">Matched care options</h2><p className="text-sm text-slate-500">Navigation results based on your request.</p></div>
                      <Filter className="text-blue-600" />
                    </div>
                    <div className="grid gap-3 md:grid-cols-2">
                      <Sel label="Language" value={language} setValue={setLanguage} opts={["All", "English", "Arabic", "Mandarin", "Italian", "Spanish", "French"]} />
                      <Sel label="Specialty" value={specialty} setValue={setSpecialty} opts={["All", "Family Physician", "Dental Clinic", "Mental Health Provider"]} />
                    </div>
                  </div>
                  <div className="space-y-4">{filteredDoctors.map((doc, i) => <DocCard key={doc.id} doc={doc} sel={selectedDoctor?.id === doc.id} onClick={() => setSelectedDoctor(doc)} i={i} />)}</div>
                </div>
                <DocProfile doc={selectedDoctor} onRegister={() => setShowForm(true)} />
              </section>
            )}
            {!searched && <DownloadSection />}
            <Footer />
          </motion.div>
        )}
        {activeTab === "doctors" && <DoctorsView key="doctors" setSelDoc={setSelectedDoctor} setShowForm={setShowForm} setTab={setActiveTab} />}
        {activeTab === "clinics" && <ClinicsView key="clinics" />}
        {activeTab === "ai" && <AIView key="ai" quickSearch={quickSearch} setTab={setActiveTab} />}
        {activeTab === "regions" && <RegionsView key="regions" />}
        {activeTab === "download" && <DownloadView key="download" />}
      </AnimatePresence>

      <AnimatePresence>{showForm && <RegModal doc={selectedDoctor} submitted={submitted} onSubmit={() => setSubmitted(true)} onClose={() => { setShowForm(false); setSubmitted(false) }} />}</AnimatePresence>
      <ChatPopup open={showChatPopup} onClose={() => setShowChatPopup(false)} onSearch={quickSearch} />
      {!showChatPopup && <motion.button initial={{ scale: 0 }} animate={{ scale: 1 }} onClick={() => setShowChatPopup(true)} className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-blue-600 text-white shadow-2xl shadow-blue-600/30 transition hover:scale-110"><MessageSquare size={22} /></motion.button>}
    </div>
  )
}

/* ─── Sub-views ─── */

function DoctorsView({ setSelDoc, setShowForm, setTab }: any) {
  const [sel, setSel] = useState<Doctor>(doctors[0])
  const [spec, setSpec] = useState("All")
  const filtered = spec === "All" ? doctors : doctors.filter(d => d.specialty === spec)
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }}>
      <div className="mx-auto max-w-7xl px-5 py-12">
        <div className="mb-8 text-center">
          <h2 className="text-4xl font-bold text-slate-950">All Doctors</h2>
          <p className="mt-2 text-lg text-slate-500">Browse verified healthcare providers across Ontario</p>
        </div>
        <div className="mb-6 flex flex-wrap justify-center gap-2">
          {["All", "Family Physician", "Dental Clinic", "Mental Health Provider"].map(s => (
            <button key={s} onClick={() => setSpec(s)} className={`rounded-full px-5 py-2 text-sm font-medium transition ${spec === s ? "bg-blue-600 text-white" : "bg-white text-slate-600 border border-slate-200 hover:border-blue-300"}`}>{s}</button>
          ))}
        </div>
        <div className="mx-auto grid max-w-5xl gap-4">{filtered.map((doc, i) => <DocCard key={doc.id} doc={doc} sel={sel?.id === doc.id} onClick={() => setSel(doc)} i={i} />)}</div>
        {sel && <div className="mx-auto mt-8 max-w-5xl"><DocProfile doc={sel} onRegister={() => { setSelDoc(sel); setShowForm(true); setTab("patients") }} /></div>}
      </div>
      <Footer />
    </motion.div>
  )
}

function ClinicsView() {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }}>
      <div className="mx-auto max-w-7xl px-5 py-12">
        <div className="mb-10 text-center">
          <h2 className="text-4xl font-bold text-slate-950">Clinics</h2>
          <p className="mt-2 text-lg text-slate-500">Verified healthcare clinics across Ontario</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {clinics.map((c, i) => (
            <motion.div key={c.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
              className="rounded-[2rem] border border-white bg-white p-6 shadow-sm transition hover:shadow-xl">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600"><Building2 size={24} /></div>
              <h3 className="text-lg font-bold text-slate-900">{c.name}</h3>
              <p className="mt-1 text-sm text-slate-500">{c.type} · {c.location}</p>
              <div className="mt-4 flex items-center gap-4 text-sm text-slate-600">
                <span className="flex items-center gap-1"><Users size={14} />{c.patients} patients</span>
                <span className="flex items-center gap-1"><Star size={14} className="text-amber-500" fill="currentColor" />{c.rating}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
      <Footer />
    </motion.div>
  )
}

function AIView({ quickSearch, setTab }: { quickSearch: (q: string) => void; setTab: (t: string) => void }) {
  const [msgs, setMsgs] = useState<ChatMsg[]>([{ from: "ai", text: "Hello! I'm CareMap AI. I can help you find the right doctor, dentist, or mental health provider in Ontario.\n\nAI healthcare navigation — not diagnosis.\n\nWhat do you need help with?" }])
  const [inp, setInp] = useState("")
  const scrollRef = useRef<HTMLDivElement>(null)
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }) }, [msgs])

  function send() {
    if (!inp.trim()) return
    const txt = inp.trim()
    setMsgs(m => [...m, { from: "user", text: txt }])
    setInp("")
    setTimeout(() => {
      const lower = txt.toLowerCase()
      let reply = "I can help you find care. Try asking for a family doctor, dentist, or mental health support."
      if (lower.includes("family") || lower.includes("doctor")) reply = "I found family physicians accepting new patients. Click 'View Results' to see them."
      if (lower.includes("tooth") || lower.includes("dental")) reply = "I can show you dental clinics with same-day availability. Click 'View Results' to see them."
      if (lower.includes("anxiety") || lower.includes("mental")) reply = "I found mental health providers with virtual and in-person options. Click 'View Results' to see them."
      if (lower.includes("chest pain") || lower.includes("emergency")) reply = "⚠️ This may be an emergency. Please call 911 immediately."
      setMsgs(m => [...m, { from: "ai", text: reply }])
    }, 600)
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }} className="flex h-[calc(100dvh-64px)] flex-col">
      <div className="mx-auto w-full max-w-3xl px-5 pt-8 text-center">
        <h2 className="text-3xl font-bold text-slate-950">CareMap AI Assistant</h2>
        <p className="mt-2 text-slate-500">AI healthcare navigation — not diagnosis</p>
      </div>
      <div ref={scrollRef} className="mx-auto w-full max-w-3xl flex-1 overflow-y-auto px-5 py-6">
        <div className="space-y-4">
          {msgs.map((msg, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`flex ${msg.from === "ai" ? "justify-start" : "justify-end"}`}>
              <div className={`max-w-[85%] rounded-3xl px-5 py-3.5 text-sm leading-6 ${msg.from === "ai" ? "bg-white text-slate-800 shadow-sm border border-slate-100" : "bg-blue-600 text-white"}`}>{msg.text}</div>
            </motion.div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-2">
          {["Family doctor", "Dentist", "Mental health"].map(opt => (
            <button key={opt} onClick={() => quickSearch(`I need a ${opt.toLowerCase()}`)} className="rounded-full bg-slate-100 px-4 py-2 text-sm font-medium text-slate-600 transition hover:bg-blue-600 hover:text-white">{opt}</button>
          ))}
          <button onClick={() => setTab("patients")} className="rounded-full bg-blue-100 px-4 py-2 text-sm font-medium text-blue-700 transition hover:bg-blue-600 hover:text-white">View Results →</button>
        </div>
      </div>
      <div className="mx-auto w-full max-w-3xl border-t border-slate-100 bg-white px-5 py-4">
        <div className="flex items-center gap-3">
          <input value={inp} onChange={e => setInp(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Describe what you need..."
            className="flex-1 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-blue-400" />
          <button onClick={send} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white transition hover:bg-blue-500"><Send size={16} /></button>
        </div>
        <p className="mt-2 text-center text-[11px] text-slate-400">CareMap AI does not provide medical diagnosis. Always consult a healthcare professional.</p>
      </div>
    </motion.div>
  )
}

function RegionsView() {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }}>
      <div className="mx-auto max-w-7xl px-5 py-12">
        <div className="mb-10 text-center">
          <h2 className="text-4xl font-bold text-slate-950">Ontario Regions</h2>
          <p className="mt-2 text-lg text-slate-500">CareMap is expanding across Ontario. Toronto is live now.</p>
        </div>
        <div className="mb-10 rounded-[2.5rem] bg-gradient-to-br from-blue-600 to-blue-900 p-8 text-white md:p-12">
          <div className="flex items-center gap-3 mb-4"><MapPin size={24} /><span className="text-sm font-bold uppercase tracking-wider text-blue-200">Currently Active</span></div>
          <h3 className="text-5xl font-bold">Toronto</h3>
          <p className="mt-3 text-xl text-blue-100">2.9 million people · 5,000+ verified providers · 25+ languages</p>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-emerald-400/20 px-4 py-2 text-sm font-bold text-emerald-200"><Zap size={16} />Live and accepting patients</div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {regions.map((r, i) => (
            <motion.div key={r.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
              className={`rounded-2xl border p-6 text-center transition ${r.status === "active" ? "border-blue-200 bg-blue-50" : "border-slate-100 bg-white"}`}>
              <div className={`mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl ${r.status === "active" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-400"}`}><MapPin size={22} /></div>
              <h3 className="text-lg font-bold text-slate-900">{r.name}</h3>
              <p className="mt-1 text-sm text-slate-500">{r.pop} people</p>
              <span className={`mt-3 inline-block rounded-full px-3 py-1 text-xs font-bold ${r.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-400"}`}>{r.status === "active" ? "LIVE" : "Coming Soon"}</span>
            </motion.div>
          ))}
        </div>
      </div>
      <Footer />
    </motion.div>
  )
}

function DownloadView() {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }} className="flex min-h-[80dvh] items-center justify-center">
      <div className="mx-auto max-w-2xl px-5 text-center">
        <div className="mb-6 inline-flex h-20 w-20 items-center justify-center rounded-3xl bg-blue-50 text-blue-600"><Download size={36} /></div>
        <h2 className="text-5xl font-bold text-slate-950">Get CareMap Ontario</h2>
        <p className="mx-auto mt-4 max-w-xl text-lg text-slate-500">Healthcare navigation in your pocket. Find doctors, book appointments, and manage your care — all from your phone.</p>
        <p className="mt-2 text-sm text-slate-400">AI healthcare navigation — not diagnosis</p>
        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <button className="flex w-48 items-center gap-3 rounded-2xl bg-slate-950 px-6 py-4 text-white shadow-xl transition hover:scale-[1.02]"><Apple size={28} /><div className="text-left"><div className="text-[10px] text-slate-400">Coming Soon</div><div className="text-sm font-bold">App Store</div></div></button>
          <button className="flex w-48 items-center gap-3 rounded-2xl bg-slate-100 px-6 py-4 text-slate-900 shadow-xl transition hover:scale-[1.02]"><Smartphone size={28} /><div className="text-left"><div className="text-[10px] text-slate-500">Coming Soon</div><div className="text-sm font-bold">Google Play</div></div></button>
        </div>
        <div className="mt-12 grid grid-cols-3 gap-4">
          {[{ icon: Search, label: "Find Doctors" }, { icon: MessageSquare, label: "AI Assistant" }, { icon: ShieldCheck, label: "PHIPA Safe" }].map(f => (
            <div key={f.label} className="rounded-2xl bg-white p-4 shadow-sm"><f.icon size={20} className="mx-auto mb-2 text-blue-600" /><div className="text-xs font-semibold text-slate-600">{f.label}</div></div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

/* ─── Shared Components ─── */

function AIPanel({ searched, assistant, filteredDoctors, onDoctor }: any) {
  return (
    <div className="rounded-[2.5rem] border border-white bg-white/90 p-5 shadow-2xl shadow-blue-900/10 backdrop-blur-xl">
      <div className="rounded-[2rem] bg-gradient-to-br from-slate-950 to-blue-950 p-5 text-white">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3"><div className="rounded-2xl bg-white/10 p-3"><Stethoscope /></div><div><div className="font-bold">CareMap AI</div><div className="text-xs text-blue-100">Non-diagnostic navigation assistant</div></div></div>
          <div className="rounded-full bg-emerald-400/15 px-3 py-1 text-xs font-semibold text-emerald-200">Safe mode</div>
        </div>
        <div className="space-y-4">
          <div className="flex justify-end"><div className="max-w-[85%] rounded-3xl bg-blue-500 px-4 py-3 text-sm leading-6 text-white">{searched ? "I need help finding care near me." : "I need a family doctor near me."}</div></div>
          <div className="flex justify-start"><div className="max-w-[85%] rounded-3xl bg-white/12 px-4 py-3 text-sm leading-6 text-blue-50">{searched ? assistant.title + " " + assistant.text : "I can help you navigate care options in Ontario. Tell me what you need, your area, or preferred language."}</div></div>
        </div>
      </div>
      <div className="mt-5 grid gap-4">
        {(searched ? filteredDoctors : doctors).slice(0, 3).map((doc: Doctor) => (
          <button key={doc.id} onClick={() => onDoctor(doc)} className="group rounded-3xl border border-slate-100 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-xl">
            <div className="flex items-start justify-between gap-3"><div className="flex-1 min-w-0"><div className="font-bold text-slate-950 truncate">{doc.name}</div><div className="mt-1 text-sm text-slate-500">{doc.specialty} · {doc.location}</div></div><ChevronRight className="shrink-0 text-slate-300 transition group-hover:translate-x-1 group-hover:text-blue-600" /></div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {doc.accepting && <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-bold text-emerald-700"><Check size={16} strokeWidth={3} /> Accepting New Patients</span>}
              <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">{doc.wait}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

function DocCard({ doc, sel, onClick, i = 0 }: { doc: Doctor; sel: boolean; onClick: () => void; i?: number }) {
  return (
    <motion.button onClick={onClick} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: i * 0.05 }}
      className={`w-full rounded-[2rem] border bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-xl ${sel ? "border-blue-300 ring-4 ring-blue-100" : "border-white"}`}>
      {doc.accepting && (
        <div className="mb-4 flex items-center gap-2 rounded-2xl bg-emerald-50 px-4 py-2.5"><Check size={18} strokeWidth={3} className="text-emerald-600" /><span className="text-sm font-bold text-emerald-700">Accepting New Patients</span></div>
      )}
      <div className="flex items-start justify-between gap-4">
        <div className="flex gap-4"><div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-blue-50 text-blue-600"><UserRound /></div><div><div className="text-lg font-bold">{doc.name}</div><div className="text-sm text-slate-500">{doc.clinic}</div></div></div>
        <div className="flex items-center gap-1 rounded-full bg-amber-50 px-3 py-1 text-sm font-bold text-amber-700"><Star size={15} fill="currentColor" />{doc.rating}</div>
      </div>
      <div className="mt-4 grid gap-2 text-sm text-slate-600 md:grid-cols-2">
        <div className="flex items-center gap-2"><span className="text-blue-600"><MapPin size={16} /></span>{doc.location} · {doc.distance}</div>
        <div className="flex items-center gap-2"><span className="text-blue-600"><Languages size={16} /></span>{doc.languages.join(", ")}</div>
        <div className="flex items-center gap-2"><span className="text-blue-600"><Clock size={16} /></span>Estimated wait: {doc.wait}</div>
        <div className="flex items-center gap-2"><span className="text-blue-600"><CalendarCheck size={16} /></span>Registration request available</div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">{doc.tags.map(tag => <span key={tag} className="rounded-full bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-600">{tag}</span>)}</div>
    </motion.button>
  )
}

function DocProfile({ doc, onRegister }: { doc: Doctor | null; onRegister: () => void }) {
  if (!doc) return null
  return (
    <div className="sticky top-24 h-fit rounded-[2.4rem] border border-white bg-white p-6 shadow-2xl shadow-blue-900/10">
      <div className="mb-5 rounded-[2rem] bg-gradient-to-br from-blue-600 to-blue-900 p-6 text-white">
        <div className="flex items-start justify-between">
          <div><div className="mb-3 inline-flex rounded-full bg-white/15 px-3 py-1 text-xs font-bold">Verified profile</div><h2 className="text-3xl font-bold">{doc.name}</h2><p className="mt-2 text-blue-100">{doc.specialty}</p></div>
          <div className="rounded-2xl bg-white/15 p-3"><Building2 /></div>
        </div>
      </div>
      <div className="space-y-5">
        {doc.accepting && (
          <div className="flex items-center gap-3 rounded-2xl bg-emerald-50 px-5 py-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600"><Check size={20} strokeWidth={3} /></div>
            <div><div className="text-sm font-bold text-emerald-800">Accepting New Patients</div><div className="text-xs text-emerald-600">This clinic is currently accepting new patients through CareMap.</div></div>
          </div>
        )}
        <div><h3 className="font-bold">Clinic</h3><p className="mt-1 text-slate-600">{doc.clinic}, {doc.location}</p></div>
        <div><h3 className="font-bold">Why this match</h3><p className="mt-1 leading-7 text-slate-600">{doc.bio}</p></div>
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-3xl bg-slate-50 p-4"><div className="mb-2 text-blue-600"><CheckCircle2 /></div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Status</div><div className="mt-1 text-sm font-bold text-slate-800">{doc.accepting ? "Accepting" : "Limited"}</div></div>
          <div className="rounded-3xl bg-slate-50 p-4"><div className="mb-2 text-blue-600"><Clock /></div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Wait</div><div className="mt-1 text-sm font-bold text-slate-800">{doc.wait}</div></div>
          <div className="rounded-3xl bg-slate-50 p-4"><div className="mb-2 text-blue-600"><Languages /></div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Languages</div><div className="mt-1 text-sm font-bold text-slate-800">{doc.languages.join(", ")}</div></div>
          <div className="rounded-3xl bg-slate-50 p-4"><div className="mb-2 text-blue-600"><Star /></div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">Reviews</div><div className="mt-1 text-sm font-bold text-slate-800">{doc.rating} / 5</div></div>
        </div>
        <div className="rounded-3xl bg-slate-50 p-4"><div className="mb-2 flex items-center gap-2 font-bold"><MessageCircle size={18} />Patient review</div><p className="text-sm leading-6 text-slate-600">"Clean clinic, respectful staff, and clear communication. Registration was easy."</p></div>
        <button onClick={onRegister} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-4 font-bold text-white shadow-xl shadow-slate-900/20 transition hover:scale-[1.01]">Request Registration <ArrowRight size={18} /></button>
        <p className="text-center text-xs leading-5 text-slate-500">CareMap sends a request only. Clinic acceptance is not guaranteed.</p>
      </div>
    </div>
  )
}

function EmergencyModal({ onClose }: { onClose: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-red-950/80 p-5 backdrop-blur-md">
      <motion.div initial={{ scale: 0.95, y: 15 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 15 }} className="max-w-xl rounded-[2rem] bg-white p-7 shadow-2xl">
        <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-3xl bg-red-100 text-red-600"><AlertTriangle size={34} /></div>
        <h2 className="text-3xl font-bold text-slate-950">This may require immediate medical attention.</h2>
        <p className="mt-4 text-lg leading-8 text-slate-600">Please call 911 or go to the nearest emergency department. Do not delay seeking urgent care.</p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <a href="tel:911" className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-red-600 px-5 py-4 font-bold text-white"><Phone size={18} /> Call 911</a>
          <button onClick={onClose} className="flex-1 rounded-2xl border border-slate-200 px-5 py-4 font-bold text-slate-700">Close</button>
        </div>
      </motion.div>
    </motion.div>
  )
}

function RegModal({ doc, submitted, onSubmit, onClose }: { doc: Doctor; submitted: boolean; onSubmit: () => void; onClose: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-5 backdrop-blur-md">
      <motion.div initial={{ scale: 0.95, y: 15 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 15 }} className="w-full max-w-lg rounded-[2rem] bg-white p-6 shadow-2xl">
        <button onClick={onClose} className="ml-auto flex rounded-full p-2 text-slate-400 hover:bg-slate-100"><X /></button>
        {!submitted ? (
          <><h2 className="text-3xl font-bold">Request registration</h2><p className="mt-2 text-slate-500">Send a simple request to {doc?.clinic}. This is demo mock data only.</p>
            <div className="mt-6 space-y-3">
              <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-400" placeholder="Full name" />
              <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-400" placeholder="Email address" />
              <input className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-400" placeholder="Phone number" />
              <textarea className="min-h-28 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-blue-400" placeholder="Optional note" />
            </div>
            <button onClick={onSubmit} className="mt-5 w-full rounded-2xl bg-blue-600 px-5 py-4 font-bold text-white shadow-lg shadow-blue-600/25">Send Request</button></>
        ) : (
          <div className="py-8 text-center">
            <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 text-emerald-600"><CheckCircle2 size={42} /></div>
            <h2 className="text-3xl font-bold">Request sent</h2><p className="mt-3 text-slate-500">The clinic will contact you if registration is available.</p>
            <button onClick={onClose} className="mt-6 rounded-2xl bg-slate-950 px-8 py-4 font-bold text-white">Done</button>
          </div>
        )}
      </motion.div>
    </motion.div>
  )
}

function ChatPopup({ open, onClose, onSearch }: { open: boolean; onClose: () => void; onSearch: (q: string) => void }) {
  const [msgs, setMsgs] = useState<ChatMsg[]>([{ from: "ai", text: "Hi! I'm CareMap AI. How can I help you find care today?" }])
  const [inp, setInp] = useState("")
  const scrollRef = useRef<HTMLDivElement>(null)
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }) }, [msgs])

  function send() {
    if (!inp.trim()) return
    const txt = inp.trim()
    setMsgs(m => [...m, { from: "user", text: txt }])
    setInp("")
    setTimeout(() => {
      const lower = txt.toLowerCase()
      let r = "I can help you find the right care. Ask me about family doctors, dentists, or mental health providers."
      if (lower.includes("family") || lower.includes("doctor")) r = "I found family physicians near you. Click 'View Doctors' to browse."
      if (lower.includes("tooth") || lower.includes("dental")) r = "I found dental clinics with availability. Click 'View Clinics' to browse."
      if (lower.includes("anxiety") || lower.includes("mental")) r = "I found mental health providers. Click 'View Doctors' to browse."
      if (lower.includes("chest") || lower.includes("emergency")) r = "⚠️ This may be an emergency. Please call 911."
      setMsgs(m => [...m, { from: "ai", text: r }])
    }, 500)
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0, y: 50, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 50, scale: 0.9 }}
          className="fixed bottom-24 right-6 z-50 flex h-[440px] w-[360px] flex-col overflow-hidden rounded-[2rem] border border-slate-200/50 bg-white shadow-2xl shadow-slate-950/20 md:bottom-24 md:right-8">
          <div className="flex items-center justify-between border-b border-slate-100 bg-slate-950 px-5 py-4">
            <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white"><Sparkles size={16} /></div><div><div className="text-sm font-bold text-white">CareMap AI</div><div className="text-[10px] text-slate-400">AI healthcare navigation — not diagnosis</div></div></div>
            <button onClick={onClose} className="rounded-full p-2 text-slate-400 hover:bg-slate-800"><CloseIcon size={18} /></button>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4"><div className="space-y-3">
            {msgs.map((m, i) => (<div key={i} className={`flex ${m.from === "ai" ? "justify-start" : "justify-end"}`}><div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-5 ${m.from === "ai" ? "bg-slate-100 text-slate-800" : "bg-blue-600 text-white"}`}>{m.text}</div></div>))}
          </div></div>
          <div className="flex flex-wrap gap-1.5 border-t border-slate-100 px-5 py-2">
            {["Family doctor", "Dentist", "Mental health"].map(opt => <button key={opt} onClick={() => onSearch(`I need a ${opt.toLowerCase()}`)} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 hover:bg-blue-600 hover:text-white transition">{opt}</button>)}
          </div>
          <div className="flex items-center gap-2 border-t border-slate-100 px-5 py-3">
            <input value={inp} onChange={e => setInp(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Ask anything..." className="flex-1 rounded-xl bg-slate-100 px-3 py-2 text-sm outline-none placeholder:text-slate-400" />
            <button onClick={send} className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white hover:bg-blue-500 transition"><Send size={14} /></button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

function DownloadSection() {
  return (
    <section className="relative overflow-hidden bg-slate-950 py-20">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMiI+PHBhdGggZD0iTTM2IDM0aDR2NGgtNHpNMjQgMjRoNHY0aC00eiIvPjwvZz48L2c+PC9zdmc+')]" />
      <div className="relative mx-auto max-w-7xl px-5 text-center">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-blue-500/10 px-4 py-2 text-sm font-medium text-blue-300"><Download size={16} />Download CareMap Ontario</div>
        <h2 className="text-4xl font-bold text-white md:text-5xl">Healthcare navigation in your pocket</h2>
        <p className="mx-auto mt-4 max-w-xl text-lg text-slate-400">Get instant access to AI care guidance, doctor search, and registration requests — anytime, anywhere in Ontario.</p>
        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <button className="flex items-center gap-3 rounded-2xl bg-white px-8 py-4 text-slate-900 shadow-xl transition hover:scale-[1.02]"><Apple size={24} /><div className="text-left"><div className="text-xs text-slate-500">Coming Soon</div><div className="text-sm font-bold">App Store</div></div></button>
          <button className="flex items-center gap-3 rounded-2xl bg-white/10 px-8 py-4 text-white shadow-xl backdrop-blur-md transition hover:bg-white/20"><Smartphone size={24} /><div className="text-left"><div className="text-xs text-slate-400">Coming Soon</div><div className="text-sm font-bold">Google Play</div></div></button>
        </div>
        <p className="mt-6 text-xs text-slate-600">AI healthcare navigation — not diagnosis. Available first in Toronto.</p>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t border-slate-800 bg-slate-950 px-5 py-10">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-col items-start justify-between gap-6 md:flex-row">
          <div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white"><HeartPulse size={20} /></div><div><div className="text-lg font-bold text-white">CareMap Ontario</div><div className="text-xs text-slate-500">AI healthcare navigation — not diagnosis</div></div></div>
          <div className="flex flex-wrap gap-6 text-sm text-slate-400">
            <Link to="/about" className="transition hover:text-blue-400">About</Link>
            <Link to="/privacy" className="transition hover:text-blue-400">Privacy</Link>
            <Link to="/terms" className="transition hover:text-blue-400">Terms</Link>
            <Link to="/contact" className="transition hover:text-blue-400">Contact</Link>
          </div>
        </div>
        <div className="flex flex-col justify-between gap-4 border-t border-slate-800 pt-6 text-xs text-slate-600 md:flex-row">
          <div>© 2026 CareMap Ontario. AI healthcare navigation — not diagnosis.</div>
          <div className="flex items-center gap-4"><span className="flex items-center gap-1"><LockKeyhole size={12} />Privacy-first</span><span className="flex items-center gap-1"><Globe2 size={12} />Multilingual access</span><span className="flex items-center gap-1"><ShieldCheck size={12} />PHIPA-aware</span></div>
        </div>
      </div>
    </footer>
  )
}

/* ─── Primitives ─── */
function QBtn({ label, onClick, danger }: { label: string; onClick: () => void; danger?: boolean }) {
  return <button onClick={onClick} className={`rounded-full px-4 py-2 text-sm font-semibold transition hover:scale-[1.02] ${danger ? "bg-red-50 text-red-600" : "bg-blue-50 text-blue-700"}`}>{label}</button>
}
function Metric({ value, label }: { value: string; label: string }) {
  return <div className="rounded-3xl border border-white bg-white/80 p-4 shadow-sm"><div className="text-2xl font-bold text-blue-700">{value}</div><div className="mt-1 text-xs font-medium text-slate-500">{label}</div></div>
}
function Sel({ label, value, setValue, opts }: { label: string; value: string; setValue: (v: string) => void; opts: string[] }) {
  return <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wide text-slate-500">{label}</span><select value={value} onChange={e => setValue(e.target.value)} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 font-semibold outline-none focus:border-blue-400">{opts.map(o => <option key={o}>{o}</option>)}</select></label>
}
