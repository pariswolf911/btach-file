import { useSearchParams } from 'react-router'
import { useCallback } from 'react'

export interface FilterState {
  specialties: string[]
  neighborhoods: string[]
  languages: string[]
  acceptingNewPatients: boolean
  maxWaitTime: 'Any' | '2 weeks' | '1 month' | '3 months'
  nextAvailableDate: string
  distanceKm: number
  wheelchair: boolean
  eveningWeekend: boolean
  parking: boolean
  transit: boolean
  ohip: boolean
  ifhp: boolean
  minRating: number
  sortBy: 'nearest' | 'shortest_wait' | 'highest_rated' | 'accepting'
  query: string
}

export const defaultFilters: FilterState = {
  specialties: [],
  neighborhoods: [],
  languages: [],
  acceptingNewPatients: false,
  maxWaitTime: 'Any',
  nextAvailableDate: '',
  distanceKm: 50,
  wheelchair: false,
  eveningWeekend: false,
  parking: false,
  transit: false,
  ohip: false,
  ifhp: false,
  minRating: 0,
  sortBy: 'nearest',
  query: '',
}

export const emergencyKeywords = [
  'chest pain',
  "can't breathe",
  'cannot breathe',
  'difficulty breathing',
  'severe bleeding',
  'unconscious',
  'heart attack',
  'stroke',
  'suicide',
  'overdose',
]

export function containsEmergencyKeyword(text: string): boolean {
  const lower = text.toLowerCase()
  return emergencyKeywords.some((kw) => lower.includes(kw))
}

function parseBool(value: string | null): boolean | undefined {
  if (value === 'true') return true
  if (value === 'false') return false
  return undefined
}

function parseNumber(value: string | null): number | undefined {
  if (!value) return undefined
  const n = Number(value)
  return Number.isNaN(n) ? undefined : n
}

export function filtersFromSearchParams(params: URLSearchParams): FilterState {
  const getArr = (key: string) => {
    const raw = params.get(key)
    return raw ? raw.split(',') : []
  }

  const sortBy = params.get('sortBy')
  const maxWaitTime = params.get('maxWaitTime')

  return {
    specialties: getArr('specialties'),
    neighborhoods: getArr('neighborhoods'),
    languages: getArr('languages'),
    acceptingNewPatients: parseBool(params.get('acceptingNewPatients')) ?? defaultFilters.acceptingNewPatients,
    maxWaitTime: (maxWaitTime as FilterState['maxWaitTime']) || defaultFilters.maxWaitTime,
    nextAvailableDate: params.get('nextAvailableDate') ?? defaultFilters.nextAvailableDate,
    distanceKm: parseNumber(params.get('distanceKm')) ?? defaultFilters.distanceKm,
    wheelchair: parseBool(params.get('wheelchair')) ?? defaultFilters.wheelchair,
    eveningWeekend: parseBool(params.get('eveningWeekend')) ?? defaultFilters.eveningWeekend,
    parking: parseBool(params.get('parking')) ?? defaultFilters.parking,
    transit: parseBool(params.get('transit')) ?? defaultFilters.transit,
    ohip: parseBool(params.get('ohip')) ?? defaultFilters.ohip,
    ifhp: parseBool(params.get('ifhp')) ?? defaultFilters.ifhp,
    minRating: parseNumber(params.get('minRating')) ?? defaultFilters.minRating,
    sortBy: (sortBy as FilterState['sortBy']) || defaultFilters.sortBy,
    query: params.get('query') ?? defaultFilters.query,
  }
}

export function filtersToSearchParams(filters: FilterState): URLSearchParams {
  const params = new URLSearchParams()
  const setArr = (key: string, value: string[]) => {
    if (value.length > 0) params.set(key, value.join(','))
  }

  setArr('specialties', filters.specialties)
  setArr('neighborhoods', filters.neighborhoods)
  setArr('languages', filters.languages)
  if (filters.acceptingNewPatients) params.set('acceptingNewPatients', 'true')
  if (filters.maxWaitTime !== defaultFilters.maxWaitTime) params.set('maxWaitTime', filters.maxWaitTime)
  if (filters.nextAvailableDate) params.set('nextAvailableDate', filters.nextAvailableDate)
  if (filters.distanceKm !== defaultFilters.distanceKm) params.set('distanceKm', String(filters.distanceKm))
  if (filters.wheelchair) params.set('wheelchair', 'true')
  if (filters.eveningWeekend) params.set('eveningWeekend', 'true')
  if (filters.parking) params.set('parking', 'true')
  if (filters.transit) params.set('transit', 'true')
  if (filters.ohip) params.set('ohip', 'true')
  if (filters.ifhp) params.set('ifhp', 'true')
  if (filters.minRating > 0) params.set('minRating', String(filters.minRating))
  if (filters.sortBy !== defaultFilters.sortBy) params.set('sortBy', filters.sortBy)
  if (filters.query) params.set('query', filters.query)

  return params
}

export function useFilterParams() {
  const [searchParams, setSearchParams] = useSearchParams()

  const filters = filtersFromSearchParams(searchParams)

  const setFilters = useCallback(
    (updater: FilterState | ((prev: FilterState) => FilterState)) => {
      setSearchParams((prev) => {
        const current = filtersFromSearchParams(prev)
        const next = typeof updater === 'function' ? updater(current) : updater
        return filtersToSearchParams(next)
      })
    },
    [setSearchParams]
  )

  const resetFilters = useCallback(() => {
    setSearchParams(filtersToSearchParams(defaultFilters))
  }, [setSearchParams])

  return { filters, setFilters, resetFilters }
}
