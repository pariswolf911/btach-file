export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  clinicName: string;
  address: string;
  neighborhood: string;
  coordinates: { lat: number; lng: number };
  languages: string[];
  acceptingNewPatients: boolean;
  waitTimeDays: number;
  rating: number;
  reviewCount: number;
  phone: string;
  ohip: boolean;
  wheelchair: boolean;
  eveningWeekend: boolean;
  distanceKm: number;
  photoUrl: string;
  nextAvailable: string;
  gender: string;
  education: string[];
  bio: string;
}

export interface Clinic {
  id: string;
  name: string;
  address: string;
  phone: string;
  hours: { day: string; open: string; close: string }[];
  services: string[];
  parking: boolean;
  transitNearby: string[];
}

export interface Review {
  id: string;
  reviewer: string;
  rating: number;
  date: string;
  text: string;
}

export interface DaySlot {
  day: string;
  date: string;
  fullDate: string;
  slots: number;
  label: string;
}

export interface TimeSlot {
  time: string;
  status: "available" | "booked" | "unavailable";
}

export const doctors: Doctor[] = [
  {
    id: "dr-priya-sharma",
    name: "Dr. Priya Sharma",
    specialty: "Family Medicine",
    clinicName: "Scarborough Family Health Centre",
    address: "123 Ellesmere Rd, Scarborough, ON M1R 4E6",
    neighborhood: "Scarborough",
    coordinates: { lat: 43.7731, lng: -79.2577 },
    languages: ["English", "Hindi", "Gujarati"],
    acceptingNewPatients: true,
    waitTimeDays: 14,
    rating: 4.8,
    reviewCount: 156,
    phone: "(416) 555-0101",
    ohip: true,
    wheelchair: true,
    eveningWeekend: true,
    distanceKm: 1.2,
    photoUrl: "/doctor-avatar-1.jpg",
    nextAvailable: "Mar 15",
    gender: "Female",
    education: [
      "MD, McMaster University",
      "Residency, University of Toronto",
      "Board Certified, Family Medicine",
    ],
    bio: "Dr. Priya Sharma has been serving the Scarborough community for over 12 years. She completed her medical degree at McMaster Medical School and her residency at the University of Toronto. Dr. Sharma focuses on preventive care, chronic disease management, and women's health. She is passionate about providing culturally sensitive care to Toronto's diverse communities.",
  },
  {
    id: "dr-james-okonkwo",
    name: "Dr. James Okonkwo",
    specialty: "Family Medicine",
    clinicName: "Downtown Toronto Medical Group",
    address: "456 Bay St, Toronto, ON M5H 2R9",
    neighborhood: "Downtown",
    coordinates: { lat: 43.6532, lng: -79.3832 },
    languages: ["English", "French", "Igbo"],
    acceptingNewPatients: true,
    waitTimeDays: 7,
    rating: 4.9,
    reviewCount: 203,
    phone: "(416) 555-0202",
    ohip: true,
    wheelchair: true,
    eveningWeekend: false,
    distanceKm: 3.5,
    photoUrl: "/doctor-avatar-2.jpg",
    nextAvailable: "Mar 12",
    gender: "Male",
    education: [
      "MD, University of Ottawa",
      "Residency, McGill University",
      "Fellowship, Geriatric Medicine, U of T",
    ],
    bio: "Dr. James Okonkwo is a dedicated family physician with over 15 years of experience in downtown Toronto. He specializes in geriatric care and chronic disease management. Dr. Okonkwo is known for his patient-centered approach and commitment to health equity. He speaks English, French, and Igbo, making him accessible to a wide range of patients.",
  },
  {
    id: "dr-mei-lin-chen",
    name: "Dr. Mei Lin Chen",
    specialty: "Family Medicine",
    clinicName: "North York Community Clinic",
    address: "789 Yonge St, North York, ON M2N 5W1",
    neighborhood: "North York",
    coordinates: { lat: 43.7615, lng: -79.4111 },
    languages: ["English", "Mandarin", "Cantonese"],
    acceptingNewPatients: true,
    waitTimeDays: 10,
    rating: 4.9,
    reviewCount: 178,
    phone: "(416) 555-0303",
    ohip: true,
    wheelchair: true,
    eveningWeekend: true,
    distanceKm: 5.2,
    photoUrl: "/doctor-avatar-3.jpg",
    nextAvailable: "Mar 13",
    gender: "Female",
    education: [
      "MD, University of Toronto",
      "Residency, Sunnybrook Health Sciences",
      "Certificate, Acupuncture, McMaster",
    ],
    bio: "Dr. Mei Lin Chen is a compassionate family physician serving North York and surrounding communities. With expertise in integrative medicine, she combines conventional and complementary approaches to patient care. Dr. Chen is fluent in Mandarin and Cantonese, and she is dedicated to supporting Toronto's Asian communities with culturally informed healthcare.",
  },
  {
    id: "dr-aisha-patel",
    name: "Dr. Aisha Patel",
    specialty: "Family Medicine",
    clinicName: "Etobicoke Wellness Centre",
    address: "321 Bloor St W, Etobicoke, ON M8X 1E1",
    neighborhood: "Etobicoke",
    coordinates: { lat: 43.6432, lng: -79.5432 },
    languages: ["English", "Urdu", "Hindi"],
    acceptingNewPatients: false,
    waitTimeDays: 30,
    rating: 4.7,
    reviewCount: 92,
    phone: "(416) 555-0404",
    ohip: true,
    wheelchair: false,
    eveningWeekend: false,
    distanceKm: 8.1,
    photoUrl: "/doctor-avatar-5.jpg",
    nextAvailable: "Apr 2",
    gender: "Female",
    education: [
      "MD, Western University",
      "Residency, St. Michael's Hospital",
      "Board Certified, Family Medicine",
    ],
    bio: "Dr. Aisha Patel is an experienced family physician based in Etobicoke. She has a special interest in pediatric and adolescent health, and she works closely with families to build long-term health plans. Although her practice is currently at capacity, she maintains a waitlist for prospective patients.",
  },
];

export const clinics: Record<string, Clinic> = {
  "dr-priya-sharma": {
    id: "clinic-1",
    name: "Scarborough Family Health Centre",
    address: "123 Ellesmere Rd, Scarborough, ON M1R 4E6",
    phone: "(416) 555-0101",
    hours: [
      { day: "Mon", open: "9:00 AM", close: "6:00 PM" },
      { day: "Tue", open: "9:00 AM", close: "6:00 PM" },
      { day: "Wed", open: "9:00 AM", close: "6:00 PM" },
      { day: "Thu", open: "9:00 AM", close: "6:00 PM" },
      { day: "Fri", open: "9:00 AM", close: "6:00 PM" },
      { day: "Sat", open: "9:00 AM", close: "2:00 PM" },
      { day: "Sun", open: "Closed", close: "" },
    ],
    services: ["Family Medicine", "Vaccinations", "Lab Services"],
    parking: true,
    transitNearby: ["Bus 95", "Bus 38"],
  },
  "dr-james-okonkwo": {
    id: "clinic-2",
    name: "Downtown Toronto Medical Group",
    address: "456 Bay St, Toronto, ON M5H 2R9",
    phone: "(416) 555-0202",
    hours: [
      { day: "Mon", open: "8:00 AM", close: "5:00 PM" },
      { day: "Tue", open: "8:00 AM", close: "5:00 PM" },
      { day: "Wed", open: "8:00 AM", close: "5:00 PM" },
      { day: "Thu", open: "8:00 AM", close: "5:00 PM" },
      { day: "Fri", open: "8:00 AM", close: "4:00 PM" },
      { day: "Sat", open: "Closed", close: "" },
      { day: "Sun", open: "Closed", close: "" },
    ],
    services: ["Family Medicine", "Geriatrics", "Travel Medicine"],
    parking: false,
    transitNearby: ["TTC Line 1", "Streetcar 505"],
  },
  "dr-mei-lin-chen": {
    id: "clinic-3",
    name: "North York Community Clinic",
    address: "789 Yonge St, North York, ON M2N 5W1",
    phone: "(416) 555-0303",
    hours: [
      { day: "Mon", open: "9:00 AM", close: "7:00 PM" },
      { day: "Tue", open: "9:00 AM", close: "7:00 PM" },
      { day: "Wed", open: "9:00 AM", close: "7:00 PM" },
      { day: "Thu", open: "9:00 AM", close: "7:00 PM" },
      { day: "Fri", open: "9:00 AM", close: "5:00 PM" },
      { day: "Sat", open: "10:00 AM", close: "3:00 PM" },
      { day: "Sun", open: "Closed", close: "" },
    ],
    services: ["Family Medicine", "Acupuncture", "Mental Health"],
    parking: true,
    transitNearby: ["TTC Line 1", "Bus 97"],
  },
  "dr-aisha-patel": {
    id: "clinic-4",
    name: "Etobicoke Wellness Centre",
    address: "321 Bloor St W, Etobicoke, ON M8X 1E1",
    phone: "(416) 555-0404",
    hours: [
      { day: "Mon", open: "8:30 AM", close: "5:00 PM" },
      { day: "Tue", open: "8:30 AM", close: "5:00 PM" },
      { day: "Wed", open: "8:30 AM", close: "5:00 PM" },
      { day: "Thu", open: "8:30 AM", close: "5:00 PM" },
      { day: "Fri", open: "8:30 AM", close: "4:00 PM" },
      { day: "Sat", open: "Closed", close: "" },
      { day: "Sun", open: "Closed", close: "" },
    ],
    services: ["Family Medicine", "Pediatrics", "Women's Health"],
    parking: true,
    transitNearby: ["Bus 15", "Bus 49"],
  },
};

export const reviews: Record<string, Review[]> = {
  "dr-priya-sharma": [
    {
      id: "r1",
      reviewer: "Sarah M.",
      rating: 5,
      date: "2 months ago",
      text: "Dr. Sharma is incredibly thorough and caring. She took time to understand my concerns and explained everything clearly.",
    },
    {
      id: "r2",
      reviewer: "James K.",
      rating: 5,
      date: "3 months ago",
      text: "Finally found a doctor who listens. The staff is friendly and the clinic is clean and accessible.",
    },
    {
      id: "r3",
      reviewer: "Anonymous",
      rating: 4,
      date: "4 months ago",
      text: "Great doctor, but wait times can be a bit long. Worth it for the quality of care.",
    },
  ],
  "dr-james-okonkwo": [
    {
      id: "r4",
      reviewer: "Margaret L.",
      rating: 5,
      date: "1 month ago",
      text: "Dr. Okonkwo is wonderful with seniors. He is patient, kind, and always explains medications thoroughly.",
    },
    {
      id: "r5",
      reviewer: "Robert T.",
      rating: 5,
      date: "2 months ago",
      text: "The best family doctor I've had in Toronto. Very knowledgeable and truly cares about his patients.",
    },
    {
      id: "r6",
      reviewer: "Lucie B.",
      rating: 4,
      date: "5 months ago",
      text: "Excellent care. Sometimes the office is busy but the quality of care is outstanding.",
    },
  ],
  "dr-mei-lin-chen": [
    {
      id: "r7",
      reviewer: "Wei Z.",
      rating: 5,
      date: "2 weeks ago",
      text: "Dr. Chen is amazing. She speaks Mandarin which helps my parents so much. Highly recommend.",
    },
    {
      id: "r8",
      reviewer: "Karen D.",
      rating: 5,
      date: "1 month ago",
      text: "Very professional and warm. The integrative approach really helped with my chronic pain.",
    },
    {
      id: "r9",
      reviewer: "Tom H.",
      rating: 4,
      date: "3 months ago",
      text: "Great doctor, convenient evening hours. Booking is easy and the clinic is modern.",
    },
  ],
  "dr-aisha-patel": [
    {
      id: "r10",
      reviewer: "Nadia F.",
      rating: 5,
      date: "1 month ago",
      text: "Dr. Patel is excellent with children. My kids actually look forward to their checkups!",
    },
    {
      id: "r11",
      reviewer: "Hassan R.",
      rating: 4,
      date: "3 months ago",
      text: "Knowledgeable and caring. Wish she was accepting new patients so I could refer more friends.",
    },
    {
      id: "r12",
      reviewer: "Priya S.",
      rating: 5,
      date: "6 months ago",
      text: "Dr. Patel has been our family doctor for years. She is thorough and always follows up.",
    },
  ],
};

export const daySlots: Record<string, DaySlot[]> = {
  "dr-priya-sharma": [
    { day: "Mon", date: "Mar 10", fullDate: "2025-03-10", slots: 0, label: "Full" },
    { day: "Tue", date: "Mar 11", fullDate: "2025-03-11", slots: 2, label: "2 slots" },
    { day: "Wed", date: "Mar 12", fullDate: "2025-03-12", slots: 0, label: "Full" },
    { day: "Thu", date: "Mar 13", fullDate: "2025-03-13", slots: 3, label: "3 slots" },
    { day: "Fri", date: "Mar 14", fullDate: "2025-03-14", slots: 1, label: "1 slot" },
    { day: "Sat", date: "Mar 15", fullDate: "2025-03-15", slots: 2, label: "2 slots" },
    { day: "Sun", date: "Mar 16", fullDate: "2025-03-16", slots: 0, label: "Closed" },
  ],
  "dr-james-okonkwo": [
    { day: "Mon", date: "Mar 10", fullDate: "2025-03-10", slots: 1, label: "1 slot" },
    { day: "Tue", date: "Mar 11", fullDate: "2025-03-11", slots: 3, label: "3 slots" },
    { day: "Wed", date: "Mar 12", fullDate: "2025-03-12", slots: 2, label: "2 slots" },
    { day: "Thu", date: "Mar 13", fullDate: "2025-03-13", slots: 0, label: "Full" },
    { day: "Fri", date: "Mar 14", fullDate: "2025-03-14", slots: 1, label: "1 slot" },
    { day: "Sat", date: "Mar 15", fullDate: "2025-03-15", slots: 0, label: "Closed" },
    { day: "Sun", date: "Mar 16", fullDate: "2025-03-16", slots: 0, label: "Closed" },
  ],
  "dr-mei-lin-chen": [
    { day: "Mon", date: "Mar 10", fullDate: "2025-03-10", slots: 2, label: "2 slots" },
    { day: "Tue", date: "Mar 11", fullDate: "2025-03-11", slots: 0, label: "Full" },
    { day: "Wed", date: "Mar 12", fullDate: "2025-03-12", slots: 3, label: "3 slots" },
    { day: "Thu", date: "Mar 13", fullDate: "2025-03-13", slots: 1, label: "1 slot" },
    { day: "Fri", date: "Mar 14", fullDate: "2025-03-14", slots: 2, label: "2 slots" },
    { day: "Sat", date: "Mar 15", fullDate: "2025-03-15", slots: 0, label: "Closed" },
    { day: "Sun", date: "Mar 16", fullDate: "2025-03-16", slots: 0, label: "Closed" },
  ],
  "dr-aisha-patel": [
    { day: "Mon", date: "Mar 10", fullDate: "2025-03-10", slots: 0, label: "Full" },
    { day: "Tue", date: "Mar 11", fullDate: "2025-03-11", slots: 0, label: "Full" },
    { day: "Wed", date: "Mar 12", fullDate: "2025-03-12", slots: 0, label: "Full" },
    { day: "Thu", date: "Mar 13", fullDate: "2025-03-13", slots: 0, label: "Full" },
    { day: "Fri", date: "Mar 14", fullDate: "2025-03-14", slots: 0, label: "Full" },
    { day: "Sat", date: "Mar 15", fullDate: "2025-03-15", slots: 0, label: "Closed" },
    { day: "Sun", date: "Mar 16", fullDate: "2025-03-16", slots: 0, label: "Closed" },
  ],
};

export const timeSlots: Record<string, TimeSlot[]> = {
  "2025-03-10": [
    { time: "9:00 AM", status: "booked" },
    { time: "9:30 AM", status: "booked" },
    { time: "10:00 AM", status: "booked" },
    { time: "10:30 AM", status: "booked" },
    { time: "11:00 AM", status: "booked" },
    { time: "2:00 PM", status: "booked" },
    { time: "2:30 PM", status: "booked" },
    { time: "3:00 PM", status: "booked" },
  ],
  "2025-03-11": [
    { time: "9:00 AM", status: "available" },
    { time: "9:30 AM", status: "booked" },
    { time: "10:00 AM", status: "available" },
    { time: "10:30 AM", status: "booked" },
    { time: "11:00 AM", status: "booked" },
    { time: "2:00 PM", status: "booked" },
    { time: "2:30 PM", status: "booked" },
    { time: "3:00 PM", status: "booked" },
  ],
  "2025-03-12": [
    { time: "9:00 AM", status: "booked" },
    { time: "9:30 AM", status: "booked" },
    { time: "10:00 AM", status: "booked" },
    { time: "10:30 AM", status: "booked" },
    { time: "11:00 AM", status: "booked" },
    { time: "2:00 PM", status: "booked" },
    { time: "2:30 PM", status: "booked" },
    { time: "3:00 PM", status: "booked" },
  ],
  "2025-03-13": [
    { time: "9:00 AM", status: "available" },
    { time: "9:30 AM", status: "available" },
    { time: "10:00 AM", status: "booked" },
    { time: "10:30 AM", status: "available" },
    { time: "11:00 AM", status: "available" },
    { time: "2:00 PM", status: "available" },
    { time: "2:30 PM", status: "available" },
    { time: "3:00 PM", status: "booked" },
  ],
  "2025-03-14": [
    { time: "9:00 AM", status: "available" },
    { time: "9:30 AM", status: "booked" },
    { time: "10:00 AM", status: "booked" },
    { time: "10:30 AM", status: "booked" },
    { time: "11:00 AM", status: "booked" },
    { time: "2:00 PM", status: "booked" },
    { time: "2:30 PM", status: "booked" },
    { time: "3:00 PM", status: "booked" },
  ],
  "2025-03-15": [
    { time: "9:00 AM", status: "available" },
    { time: "9:30 AM", status: "booked" },
    { time: "10:00 AM", status: "available" },
    { time: "10:30 AM", status: "booked" },
    { time: "11:00 AM", status: "booked" },
    { time: "2:00 PM", status: "booked" },
    { time: "2:30 PM", status: "booked" },
    { time: "3:00 PM", status: "booked" },
  ],
  "2025-03-16": [
    { time: "9:00 AM", status: "unavailable" },
    { time: "9:30 AM", status: "unavailable" },
    { time: "10:00 AM", status: "unavailable" },
    { time: "10:30 AM", status: "unavailable" },
    { time: "11:00 AM", status: "unavailable" },
    { time: "2:00 PM", status: "unavailable" },
    { time: "2:30 PM", status: "unavailable" },
    { time: "3:00 PM", status: "unavailable" },
  ],
};

export const similarDoctors: Record<string, Doctor[]> = {
  "dr-priya-sharma": [
    doctors[1], // Dr. James Okonkwo
    doctors[2], // Dr. Mei Lin Chen
  ],
  "dr-james-okonkwo": [
    doctors[0], // Dr. Priya Sharma
    doctors[2], // Dr. Mei Lin Chen
  ],
  "dr-mei-lin-chen": [
    doctors[0], // Dr. Priya Sharma
    doctors[1], // Dr. James Okonkwo
  ],
  "dr-aisha-patel": [
    doctors[0], // Dr. Priya Sharma
    doctors[2], // Dr. Mei Lin Chen
  ],
};
