import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router'
import { Menu, X } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const LogoIcon = () => (
  <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 4C12.268 4 6 10.268 6 18c0 5.304 2.868 9.912 7.128 12.408L20 38l6.872-7.592C31.132 27.912 34 23.304 34 18c0-7.732-6.268-14-14-14z" fill="#0D9488" />
    <rect x="16" y="12" width="8" height="12" rx="1" fill="white" />
    <rect x="12" y="16" width="16" height="4" rx="1" fill="white" />
  </svg>
)

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/results', label: 'Results' },
  { to: '/filters', label: 'Filters' },
  { to: '/profile', label: 'Profile' },
  { to: '/register', label: 'Register' },
  { to: '/confirm', label: 'Confirm' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname])

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white shadow-[0_1px_3px_rgba(0,0,0,0.05)]'
          : 'bg-transparent'
      }`}
    >
      <div className="mx-auto flex h-14 max-w-[720px] items-center justify-between px-4 md:h-16 md:px-6">
        <Link to="/" className="flex items-center gap-2">
          <LogoIcon />
          <div className="flex flex-col leading-none">
            <span className="text-lg font-bold text-teal-700">CareMap</span>
            <span className="text-sm font-normal text-slate-500">Toronto</span>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`relative text-sm font-medium transition-colors ${
                location.pathname === link.to ? 'text-teal-600' : 'text-slate-700 hover:text-teal-600'
              }`}
            >
              {link.label}
              <span
                className={`absolute -bottom-1 left-0 h-0.5 bg-teal-500 transition-all duration-200 ${
                  location.pathname === link.to ? 'w-full' : 'w-0 group-hover:w-full'
                }`}
              />
            </Link>
          ))}
        </nav>

        <button
          className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-700 transition-colors hover:bg-slate-100 md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden border-b border-slate-100 bg-white md:hidden"
          >
            <div className="mx-auto max-w-[720px] px-4 py-3">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`block rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    location.pathname === link.to
                      ? 'bg-teal-50 text-teal-700'
                      : 'text-slate-700 hover:bg-slate-50 hover:text-teal-600'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
