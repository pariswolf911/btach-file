import { Link } from 'react-router'

const LogoIconWhite = () => (
  <svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 4C12.268 4 6 10.268 6 18c0 5.304 2.868 9.912 7.128 12.408L20 38l6.872-7.592C31.132 27.912 34 23.304 34 18c0-7.732-6.268-14-14-14z" fill="#F0FDFA" />
    <rect x="16" y="12" width="8" height="12" rx="1" fill="#0F172A" />
    <rect x="12" y="16" width="16" height="4" rx="1" fill="#0F172A" />
  </svg>
)

const footerLinks = [
  { to: '/', label: 'About' },
  { to: '/', label: 'Privacy' },
  { to: '/', label: 'Terms' },
  { to: '/', label: 'Accessibility' },
  { to: '/', label: 'Contact' },
]

export default function Footer() {
  return (
    <footer className="bg-slate-900 px-6 py-10 text-white">
      <div className="mx-auto max-w-[720px]">
        <div className="mb-6 flex items-center gap-2">
          <LogoIconWhite />
          <div className="flex flex-col leading-none">
            <span className="text-base font-bold text-white">CareMap</span>
            <span className="text-xs font-normal text-slate-400">Toronto</span>
          </div>
        </div>

        <div className="mb-6 flex flex-wrap gap-4">
          {footerLinks.map((link) => (
            <Link
              key={link.label}
              to={link.to}
              className="text-sm text-slate-400 transition-colors hover:text-white"
            >
              {link.label}
            </Link>
          ))}
        </div>

        <p className="mb-2 text-xs leading-relaxed text-slate-500">
          CareMap Toronto is not a substitute for professional medical advice. Always consult a healthcare provider for personal medical concerns.
        </p>
        <p className="text-xs text-slate-500">&copy; 2025 CareMap Toronto</p>
      </div>
    </footer>
  )
}
