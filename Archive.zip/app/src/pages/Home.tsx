import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search,
  Mic,
  Phone,
  AlertTriangle,
  Stethoscope,
  Brain,
  Baby,
  Eye,
  Syringe,
  Heart,
  Footprints,
  ChevronRight,
} from 'lucide-react'

/* ───────── Inline SVG Assets ───────── */

const LogoIcon = ({ size = 40 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
    <path d="M20 4C12.268 4 6 10.268 6 18c0 5.304 2.868 9.912 7.128 12.408L20 38l6.872-7.592C31.132 27.912 34 23.304 34 18c0-7.732-6.268-14-14-14z" fill="#0D9488" />
    <rect x="16" y="12" width="8" height="12" rx="1" fill="white" />
    <rect x="12" y="16" width="16" height="4" rx="1" fill="white" />
  </svg>
)

const HeroIllustration = () => (
  <svg viewBox="0 0 600 400" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto max-w-[480px]">
    <rect width="600" height="400" rx="20" fill="#FAFAF9" />
    <circle cx="150" cy="200" r="60" fill="#F0FDFA" />
    <circle cx="300" cy="140" r="50" fill="#FFF7ED" />
    <circle cx="450" cy="200" r="60" fill="#F0FDFA" />
    <circle cx="300" cy="280" r="55" fill="#FFF7ED" />
    {/* People icons */}
    <circle cx="150" cy="180" r="20" fill="#0D9488" opacity="0.2" />
    <rect x="130" y="200" width="40" height="50" rx="20" fill="#0D9488" opacity="0.2" />
    <circle cx="300" cy="125" r="18" fill="#F97316" opacity="0.2" />
    <rect x="282" y="143" width="36" height="45" rx="18" fill="#F97316" opacity="0.2" />
    <circle cx="450" cy="180" r="20" fill="#0D9488" opacity="0.2" />
    <rect x="430" y="200" width="40" height="50" rx="20" fill="#0D9488" opacity="0.2" />
    <circle cx="300" cy="265" r="18" fill="#F97316" opacity="0.2" />
    <rect x="282" y="283" width="36" height="45" rx="18" fill="#F97316" opacity="0.2" />
    {/* Dotted connections */}
    <line x1="170" y1="200" x2="282" y2="165" stroke="#0D9488" strokeWidth="2" strokeDasharray="6 4" opacity="0.5" />
    <line x1="318" y1="165" x2="430" y2="200" stroke="#0D9488" strokeWidth="2" strokeDasharray="6 4" opacity="0.5" />
    <line x1="170" y1="230" x2="282" y2="283" stroke="#0D9488" strokeWidth="2" strokeDasharray="6 4" opacity="0.5" />
    <line x1="318" y1="283" x2="430" y2="230" stroke="#0D9488" strokeWidth="2" strokeDasharray="6 4" opacity="0.5" />
    {/* Central location pin */}
    <path d="M300 190c-11 0-20 9-20 20s20 30 20 30 20-19 20-30-9-20-20-20zm0 26c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6z" fill="#0D9488" />
    {/* Decorative circles */}
    <circle cx="80" cy="100" r="8" fill="#0D9488" opacity="0.15" />
    <circle cx="520" cy="320" r="10" fill="#F97316" opacity="0.15" />
    <circle cx="100" cy="320" r="6" fill="#F97316" opacity="0.15" />
    <circle cx="500" cy="80" r="8" fill="#0D9488" opacity="0.15" />
  </svg>
)

const AiAssistantIcon = ({ size = 32 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
    <rect x="4" y="10" width="40" height="28" rx="14" fill="#F0FDFA" />
    <circle cx="20" cy="24" r="3" fill="#0D9488" />
    <circle cx="28" cy="24" r="3" fill="#0D9488" />
    <path d="M18 30c2 2 10 2 12 0" stroke="#0D9488" strokeWidth="2" strokeLinecap="round" />
    <path d="M36 18l4-4M36 30l4 4" stroke="#0D9488" strokeWidth="2" strokeLinecap="round" />
    <rect x="10" y="6" width="12" height="4" rx="2" fill="#0D9488" opacity="0.3" />
  </svg>
)

const EmergencyIcon = ({ size = 48 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
    <path d="M24 4L4 40h40L24 4z" fill="#DC2626" />
    <rect x="20" y="18" width="8" height="14" rx="1" fill="white" />
    <rect x="21" y="28" width="6" height="2" rx="1" fill="#DC2626" />
  </svg>
)

/* ───────── Emergency Overlay ───────── */

function EmergencyOverlay({ onDismiss }: { onDismiss: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4"
      role="alertdialog"
      aria-modal="true"
      aria-live="assertive"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] }}
        className="w-full max-w-[420px] animate-pulse-border rounded-[20px] border-2 border-alert-red bg-alert-red-light p-8 text-center"
      >
        <div className="mb-4 flex justify-center">
          <EmergencyIcon size={48} />
        </div>
        <h2 className="mb-3 text-[22px] font-semibold text-alert-red">This sounds like an emergency</h2>
        <p className="mb-6 text-sm leading-relaxed text-slate-700">
          If you or someone nearby is experiencing severe symptoms, please call 911 or visit the nearest emergency room immediately.
        </p>
        <a
          href="tel:911"
          className="mb-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-alert-red px-6 py-4 text-base font-semibold text-white transition-transform active:scale-[0.98]"
        >
          <Phone size={18} />
          Call 911
        </a>
        <button
          onClick={onDismiss}
          className="mb-3 w-full rounded-2xl border border-slate-200 bg-white px-6 py-3.5 text-base font-medium text-slate-700 transition-colors hover:bg-slate-50"
        >
          Find Nearest ER
        </button>
        <button
          onClick={onDismiss}
          className="text-sm font-medium text-slate-500 underline underline-offset-2 transition-colors hover:text-slate-700"
        >
          I understand — continue searching
        </button>
      </motion.div>
    </motion.div>
  )
}

/* ───────── Animation Presets ───────── */

const easeDefault: [number, number, number, number] = [0.4, 0, 0.2, 1]

const fadeSlideUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
}

const slideInLeft = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
}

const slideInRight = {
  initial: { opacity: 0, x: 20 },
  animate: { opacity: 1, x: 0 },
}

/* ───────── Emergency Detection ───────── */

const EMERGENCY_KEYWORDS = [
  'chest pain',
  "can't breathe",
  'difficulty breathing',
  'severe bleeding',
  'unconscious',
  'heart attack',
  'stroke',
  'suicide',
  'overdose',
]

function checkEmergency(text: string): boolean {
  const lower = text.toLowerCase()
  return EMERGENCY_KEYWORDS.some((kw) => lower.includes(kw))
}

/* ───────── Category Data ───────── */

const categories = [
  { icon: Stethoscope, title: 'Family Doctor', subtitle: 'Accepting new patients', slug: 'family-doctor' },
  { icon: Heart, title: 'Dentist', subtitle: 'Emergency & routine care', slug: 'dentist' },
  { icon: Brain, title: 'Specialist', subtitle: 'Cardiology, derm, more', slug: 'specialist' },
  { icon: Brain, title: 'Mental Health', subtitle: 'Counselling & therapy', slug: 'mental-health' },
  { icon: Baby, title: 'Pediatrics', subtitle: "Children's health", slug: 'pediatrics' },
  { icon: Eye, title: 'Eye Care', subtitle: 'Optometrists & clinics', slug: 'eye-care' },
  { icon: Footprints, title: 'Physiotherapy', subtitle: 'Rehab & sports', slug: 'physiotherapy' },
  { icon: Syringe, title: 'Vaccinations', subtitle: 'Travel & routine', slug: 'vaccinations' },
]

/* ───────── Main Home Page ───────── */

export default function Home() {
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [emergencyOpen, setEmergencyOpen] = useState(false)
  const [aiInput, setAiInput] = useState('')
  const [aiMessages, setAiMessages] = useState<
    { role: 'ai' | 'user'; text: string; action?: string }[]
  >([
    {
      role: 'ai',
      text: "Hi! I'm your CareMap assistant. Tell me what you need — whether it's a new family doctor, a dentist, or you're not feeling well.",
    },
    {
      role: 'user',
      text: 'I just moved to North York and need a family doctor. I prefer someone who speaks Mandarin.',
    },
    {
      role: 'ai',
      text: 'I found 4 family doctors in North York accepting new patients who speak Mandarin. Would you like to see them?',
      action: 'Show Results',
    },
  ])
  const [aiTyping, setAiTyping] = useState(false)
  const [listening, setListening] = useState(false)
  const aiScrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (aiScrollRef.current) {
      aiScrollRef.current.scrollTop = aiScrollRef.current.scrollHeight
    }
  }, [aiMessages, aiTyping])

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return
    if (checkEmergency(query)) {
      setEmergencyOpen(true)
      return
    }
    navigate(`/results?q=${encodeURIComponent(query)}`)
  }

  const handleAiSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!aiInput.trim()) return
    if (checkEmergency(aiInput)) {
      setEmergencyOpen(true)
      setAiInput('')
      return
    }
    const userText = aiInput.trim()
    setAiMessages((prev) => [...prev, { role: 'user', text: userText }])
    setAiInput('')
    setAiTyping(true)

    setTimeout(() => {
      setAiTyping(false)
      const lower = userText.toLowerCase()
      let response = ''
      let action = ''
      if (lower.includes('family doctor') || lower.includes('gp')) {
        response = 'I found 8 family doctors in your area currently accepting new patients. The shortest wait time is about 2 weeks. Shall I show you the full list?'
        action = 'Show Results'
      } else if (lower.includes('dentist')) {
        response = 'I found 5 dentists nearby. Two are accepting new patients and offer evening hours. Want to see the results?'
        action = 'Show Results'
      } else {
        response = "I understand. Let me help you find the right care. Could you tell me which neighborhood you're in, or what language you prefer?"
      }
      setAiMessages((prev) => [...prev, { role: 'ai', text: response, action }])
    }, 1500)
  }

  const handleMicToggle = () => {
    if (listening) {
      setListening(false)
      return
    }
    setListening(true)
    setTimeout(() => {
      setListening(false)
      const mockText = 'I have a headache and need to see a doctor today'
      setQuery(mockText)
    }, 2000)
  }

  return (
    <div className="relative">
      <AnimatePresence>
        {emergencyOpen && <EmergencyOverlay onDismiss={() => setEmergencyOpen(false)} />}
      </AnimatePresence>

      {/* ─── Hero ─── */}
      <section className="bg-stone-50 px-4 pb-10 pt-12 md:px-6 md:pb-12 md:pt-16">
        <div className="mx-auto max-w-[720px]">
          {/* Logo lockup */}
          <motion.div
            className="mb-8 flex flex-col items-center"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.1, ease: easeDefault }}
          >
            <LogoIcon size={40} />
            <div className="mt-2 text-center">
              <h1 className="text-[28px] font-bold leading-tight tracking-tight text-teal-700 md:text-[36px]">
                CareMap
              </h1>
              <p className="text-base font-normal text-slate-500">Toronto</p>
            </div>
          </motion.div>

          {/* Headline */}
          <motion.h2
            className="mb-4 text-center text-[28px] font-bold leading-[1.1] tracking-tight text-slate-900 md:text-[36px]"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.2, ease: easeDefault }}
          >
            Find the right doctor, right now.
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            className="mx-auto mb-8 max-w-[520px] text-center text-base leading-relaxed text-slate-600"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.3, ease: easeDefault }}
          >
            Search family doctors, dentists, specialists, and clinics across Toronto — by language, location, and availability.
          </motion.p>

          {/* Search Bar */}
          <motion.form
            onSubmit={handleSearchSubmit}
            className="mb-5"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.4, ease: easeDefault }}
          >
            <div className="relative">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Describe your symptoms or search for a doctor..."
                className="w-full rounded-[14px] border border-slate-200 bg-white py-4 pl-12 pr-12 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:shadow-[0_0_0_3px_rgba(13,148,136,0.15)] focus:outline-none transition-all"
                aria-label="Search for a doctor"
              />
              <button
                type="button"
                onClick={handleMicToggle}
                className="absolute right-3 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
                aria-label="Voice input"
              >
                <Mic className="h-5 w-5" />
              </button>
            </div>
            {listening && (
              <p className="mt-2 text-center text-sm text-teal-600">Listening...</p>
            )}
            <p className="mt-2 text-center text-xs italic text-teal-600">
              Try: &ldquo;family doctor in Scarborough who speaks Mandarin&rdquo;
            </p>
          </motion.form>

          {/* CTA */}
          <motion.div
            className="mb-8 flex justify-center"
            {...fadeSlideUp}
            transition={{ duration: 0.5, delay: 0.5, ease: easeDefault }}
          >
            <button
              onClick={handleSearchSubmit}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-coral-500 px-7 py-3.5 text-base font-semibold text-white shadow-[0_1px_2px_rgba(249,115,22,0.2)] transition-all hover:bg-coral-600 hover:scale-[1.02] active:scale-[0.98] md:w-auto"
            >
              <Search className="h-[18px] w-[18px]" />
              Find Care Now
            </button>
          </motion.div>

          {/* Hero Illustration */}
          <motion.div
            className="flex justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6, ease: easeDefault }}
          >
            <HeroIllustration />
          </motion.div>
        </div>
      </section>

      {/* ─── AI Assistant Preview ─── */}
      <section className="relative -mt-5 rounded-t-[20px] bg-white px-4 pb-10 pt-8 shadow-ai-section md:px-6">
        <div className="mx-auto max-w-[720px]">
          <motion.div
            className="mb-6 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, ease: easeDefault }}
          >
            <div className="mb-3 flex justify-center">
              <AiAssistantIcon size={32} />
            </div>
            <h2 className="mb-2 text-[22px] font-semibold text-slate-900">Ask our AI Assistant</h2>
            <p className="text-sm text-slate-500">
              Describe how you&apos;re feeling. We&apos;ll guide you to the right care.
            </p>
          </motion.div>

          <motion.div
            className="mb-4 rounded-2xl border border-slate-200 bg-white p-5"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, delay: 0.1, ease: easeDefault }}
          >
            <div ref={aiScrollRef} className="mb-4 flex max-h-[320px] flex-col gap-3 overflow-y-auto pr-1">
              {aiMessages.map((msg, i) => (
                <motion.div
                  key={i}
                  className={`flex ${msg.role === 'ai' ? 'justify-start' : 'justify-end'}`}
                  initial={msg.role === 'ai' ? slideInLeft.initial : slideInRight.initial}
                  whileInView={msg.role === 'ai' ? slideInLeft.animate : slideInRight.animate}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.1, ease: easeDefault }}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-[18px] py-[14px] text-[15px] leading-relaxed ${
                      msg.role === 'ai'
                        ? 'rounded-tl-sm bg-teal-50 text-slate-700'
                        : 'rounded-tr-sm border border-slate-200 bg-white text-slate-900'
                    }`}
                  >
                    {msg.text}
                    {msg.action && (
                      <button
                        onClick={() => navigate('/results?q=family+doctor+north+york+mandarin')}
                        className="mt-2 inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-teal-50 hover:text-teal-700"
                      >
                        {msg.action}
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
              {aiTyping && (
                <div className="flex justify-start">
                  <div className="flex max-w-[85%] items-center gap-1.5 rounded-2xl rounded-tl-sm bg-teal-50 px-[18px] py-[14px]">
                    <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-teal-400" style={{ animationDelay: '0ms' }} />
                    <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-teal-400" style={{ animationDelay: '150ms' }} />
                    <span className="inline-block h-1.5 w-1.5 animate-bounce rounded-full bg-teal-400" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
            </div>

            <form onSubmit={handleAiSubmit} className="flex items-center gap-2 border-t border-slate-200 pt-3">
              <input
                type="text"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                placeholder="Type your question..."
                className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:shadow-[0_0_0_3px_rgba(13,148,136,0.12)] focus:outline-none transition-all"
                aria-label="AI chat input"
              />
              <button
                type="submit"
                disabled={!aiInput.trim()}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-teal-600 text-white transition-all hover:bg-teal-700 disabled:opacity-40 disabled:hover:bg-teal-600"
                aria-label="Send message"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </form>
          </motion.div>

          <p className="mx-auto max-w-[480px] text-center text-xs leading-relaxed text-slate-500">
            <AlertTriangle className="inline h-3 w-3 align-text-bottom" /> This AI assistant cannot diagnose conditions. Always consult a healthcare professional for medical advice.
          </p>
        </div>
      </section>

      {/* ─── Service Categories ─── */}
      <section className="bg-stone-50 px-4 py-10 md:px-6">
        <div className="mx-auto max-w-[720px]">
          <motion.h2
            className="mb-6 text-center text-[22px] font-semibold text-slate-900"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, ease: easeDefault }}
          >
            What are you looking for?
          </motion.h2>

          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
            {categories.map((cat, i) => {
              const Icon = cat.icon
              return (
                <motion.button
                  key={cat.slug}
                  onClick={() => navigate(`/results?category=${cat.slug}`)}
                  className="flex flex-col items-center rounded-2xl bg-white p-5 shadow-card transition-all hover:-translate-y-1 hover:border hover:border-teal-200 hover:shadow-card-hover active:scale-[0.97]"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.4, delay: i * 0.06, ease: easeDefault }}
                >
                  <Icon className="mb-2 h-8 w-8 text-teal-600" strokeWidth={1.5} />
                  <span className="mb-1 text-center text-sm font-semibold text-slate-900">{cat.title}</span>
                  <span className="text-center text-xs text-slate-500">{cat.subtitle}</span>
                </motion.button>
              )
            })}
          </div>
        </div>
      </section>

      {/* ─── How It Works ─── */}
      <section className="bg-white px-4 py-12 md:px-6">
        <div className="mx-auto max-w-[720px]">
          <motion.h2
            className="mb-8 text-center text-[22px] font-semibold text-slate-900"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.4, ease: easeDefault }}
          >
            Three simple steps
          </motion.h2>

          <div className="relative flex flex-col gap-8">
            {/* Vertical dotted line (desktop only) */}
            <div className="absolute left-5 top-10 hidden h-[calc(100%-80px)] w-px border-l-2 border-dashed border-teal-200 md:block" />

            {[
              {
                num: '1',
                title: 'Describe your need',
                body: 'Search by symptom, doctor type, or location. Our AI helps you find the right words.',
              },
              {
                num: '2',
                title: 'Compare doctors',
                body: "See ratings, wait times, languages spoken, and who's accepting new patients today.",
              },
              {
                num: '3',
                title: 'Request attachment',
                body: 'Send your info directly to the clinic. No phone tag, no endless hold music.',
              },
            ].map((step, i) => (
              <motion.div
                key={step.num}
                className="flex items-start gap-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.4, delay: i * 0.1, ease: easeDefault }}
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-teal-600 text-base font-bold text-white md:h-10 md:w-10">
                  {step.num}
                </div>
                <div>
                  <h3 className="mb-1 text-lg font-semibold text-slate-900">{step.title}</h3>
                  <p className="text-sm leading-relaxed text-slate-600">{step.body}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Trust Signals ─── */}
      <section className="bg-teal-50 px-4 py-10 md:px-6">
        <div className="mx-auto max-w-[720px]">
          <div className="mb-8 flex flex-col items-center gap-8 md:flex-row md:justify-center">
            {[
              { num: '2,400+', label: 'Verified doctors' },
              { num: '150+', label: 'Languages supported' },
              { num: '24/7', label: 'AI assistance' },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.4, delay: i * 0.1, ease: easeDefault }}
              >
                <p className="mb-1 text-[28px] font-bold leading-tight text-teal-700">{stat.num}</p>
                <p className="text-sm text-slate-600">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            {['PHIPA Compliant', 'Canadian Data', 'Non-Diagnostic AI', 'Ontario Verified'].map((badge, i) => (
              <motion.span
                key={badge}
                className="inline-flex items-center rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.4, delay: i * 0.08, ease: easeDefault }}
              >
                {badge}
              </motion.span>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Emergency Banner ─── */}
      <section className="sticky bottom-0 z-40 border-t-2 border-alert-red bg-alert-red-light px-4 py-5 md:static md:px-6">
        <div className="mx-auto flex max-w-[720px] items-center justify-center gap-3">
          <AlertTriangle className="h-5 w-5 shrink-0 text-alert-red" />
          <p className="text-base font-semibold text-alert-red">
            Experiencing a medical emergency?
          </p>
          <button
            onClick={() => setEmergencyOpen(true)}
            className="text-base font-semibold text-alert-red underline underline-offset-2 transition-colors hover:text-red-800"
          >
            Call 911
          </button>
        </div>
      </section>
    </div>
  )
}
