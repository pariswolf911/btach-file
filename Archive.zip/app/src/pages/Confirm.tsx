import { useState, useMemo, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router'
import { motion, AnimatePresence } from 'framer-motion'
import { toast, Toaster } from 'sonner'
import { cn } from '@/lib/utils'
import {
  CheckCircle2,
  Clock,
  Phone,
  CalendarDays,
  Copy,
  Calendar,
  Pill,
  AlertTriangle,
  Search,
  Share2,
  Star,
  Send,
} from 'lucide-react'

const easeDefault = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeSpring = [0.34, 1.56, 0.64, 1] as [number, number, number, number]

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: easeDefault } },
}

const staggerCardVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
    },
  },
}

const cardItemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: easeDefault } },
}

const summaryRowVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
}

const summaryItemVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { duration: 0.3, ease: easeDefault } },
}

const timelineSteps = [
  {
    id: 1,
    icon: CheckCircle2,
    status: 'Done',
    statusColor: 'text-success',
    iconColor: 'text-success',
    bgColor: 'bg-green-50',
    title: 'Request submitted',
    body: 'Your information was sent to Scarborough Family Health Centre.',
  },
  {
    id: 2,
    icon: Clock,
    status: 'Now',
    statusColor: 'text-teal-600',
    iconColor: 'text-teal-600',
    bgColor: 'bg-teal-50',
    title: 'Clinic reviews your request',
    body: 'The clinic will review your information and check their patient roster availability.',
  },
  {
    id: 3,
    icon: Phone,
    status: 'In 1-2 days',
    statusColor: 'text-slate-500',
    iconColor: 'text-slate-400',
    bgColor: 'bg-slate-50',
    title: 'Clinic contacts you',
    body: 'They will call or email to confirm your registration and schedule an initial appointment.',
  },
  {
    id: 4,
    icon: CalendarDays,
    status: 'Soon',
    statusColor: 'text-slate-500',
    iconColor: 'text-slate-400',
    bgColor: 'bg-slate-50',
    title: 'Your first appointment',
    body: 'Bring your health card and any current medications list.',
  },
]

function LogoIcon() {
  return (
    <svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M20 4C12.268 4 6 10.268 6 18c0 5.304 2.868 9.912 7.128 12.408L20 38l6.872-7.592C31.132 27.912 34 23.304 34 18c0-7.732-6.268-14-14-14z"
        fill="#0D9488"
      />
      <rect x="16" y="12" width="8" height="12" rx="1" fill="white" />
      <rect x="12" y="16" width="16" height="4" rx="1" fill="white" />
    </svg>
  )
}

export default function Confirm() {
  const navigate = useNavigate()
  const [copied, setCopied] = useState(false)
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [feedbackText, setFeedbackText] = useState('')
  const [feedbackSent, setFeedbackSent] = useState(false)

  const referenceNumber = useMemo(() => {
    const random = Math.floor(10000 + Math.random() * 90000)
    return `CM-2025-${random}`
  }, [])

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(referenceNumber)
      setCopied(true)
      toast.success('Copied to clipboard')
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error('Failed to copy')
    }
  }, [referenceNumber])

  const handleAddToCalendar = useCallback(() => {
    toast.success('Reminder added to your calendar')
  }, [])

  const handleFindPharmacy = useCallback(() => {
    navigate('/results?category=pharmacy&near=Scarborough')
  }, [navigate])

  const handleGetDirections = useCallback(() => {
    toast.info('Opening map...')
  }, [])

  const handleBrowseMore = useCallback(() => {
    navigate('/results?specialty=family-medicine')
  }, [navigate])

  const handleShare = useCallback(async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'CareMap Toronto',
          text: 'Find a family doctor in Toronto with CareMap.',
          url: window.location.origin,
        })
      } catch {
        toast.info('Share sheet opened')
      }
    } else {
      toast.info('Share sheet opened')
    }
  }, [])

  const handleSendFeedback = useCallback(() => {
    setFeedbackSent(true)
    toast.success('Thank you for your feedback!')
  }, [])

  const handleEditRequest = useCallback(() => {
    toast.info('Please contact the clinic directly to update your information.', { duration: 3000 })
  }, [])

  // Intersection observer for scroll-triggered animations
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set())

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections((prev) => new Set(prev).add(entry.target.id))
          }
        })
      },
      { threshold: 0.15 }
    )

    document.querySelectorAll('[data-animate]').forEach((el) => {
      if (el.id) observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-[100dvh] bg-white">
      <Toaster />

      {/* Success Header */}
      <section className="mx-auto max-w-[480px] px-4 pt-12 pb-6 text-center">
        {/* Minimal Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: easeDefault }}
          className="mb-8 flex items-center justify-center gap-2"
        >
          <LogoIcon />
          <span className="text-lg font-bold text-teal-700">CareMap</span>
        </motion.div>

        {/* Success Illustration */}
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: easeSpring }}
          className="mx-auto mb-6"
        >
          <motion.img
            src="/success-illustration.svg"
            alt="Success"
            className="mx-auto h-40 w-40 md:h-[200px] md:w-[200px]"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 3, ease: 'easeInOut', repeat: Infinity }}
          />
        </motion.div>

        {/* Success Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2, ease: easeDefault }}
          className="text-[1.75rem] font-bold leading-tight text-success"
        >
          Request sent!
        </motion.h1>

        {/* Success Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.35, ease: easeDefault }}
          className="mx-auto mt-3 max-w-[420px] text-base leading-relaxed text-slate-700"
        >
          Dr. Priya Sharma&apos;s clinic has received your information. They will contact you within 2
          business days to confirm your registration.
        </motion.p>

        {/* Reference Number */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.5, ease: easeDefault }}
          className="mt-6 rounded-xl bg-teal-50 px-4 py-4"
        >
          <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
            Your reference number
          </p>
          <div className="mt-1 flex items-center justify-center gap-2">
            <p className="text-lg font-bold tracking-wider text-teal-700">{referenceNumber}</p>
            <button
              onClick={handleCopy}
              className="rounded-md p-1 text-teal-600 transition-colors hover:bg-teal-100"
              aria-label="Copy reference number"
            >
              {copied ? <CheckCircle2 size={16} /> : <Copy size={16} />}
            </button>
          </div>
          <p className="mt-1 text-xs text-slate-500">Save this for your records</p>
        </motion.div>
      </section>

      {/* What Happens Next */}
      <section
        id="timeline"
        data-animate
        className="relative mx-auto max-w-[720px] rounded-t-[20px] bg-stone-50 px-4 py-8"
      >
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={visibleSections.has('timeline') ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.4, ease: easeDefault }}
          className="mb-6 text-[1.375rem] font-semibold text-slate-900"
        >
          What happens next
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={visibleSections.has('timeline') ? 'show' : 'hidden'}
          className="relative flex flex-col gap-5"
        >
          {timelineSteps.map((step, index) => {
            const Icon = step.icon
            const isLast = index === timelineSteps.length - 1
            return (
              <motion.div
                key={step.id}
                variants={itemVariants}
                className="relative flex gap-4"
              >
                {/* Connector line */}
                {!isLast && (
                  <div className="absolute left-[15px] top-[40px] h-[calc(100%+8px)] w-[2px] border-l-2 border-dashed border-slate-200" />
                )}

                {/* Icon */}
                <div className="relative z-10 flex shrink-0">
                  <motion.div
                    animate={
                      step.status === 'Now'
                        ? { scale: [1, 1.05, 1] }
                        : {}
                    }
                    transition={
                      step.status === 'Now'
                        ? { duration: 2, repeat: Infinity, ease: 'easeInOut' }
                        : {}
                    }
                    className={cn(
                      'flex h-8 w-8 items-center justify-center rounded-full',
                      step.bgColor
                    )}
                  >
                    <Icon size={20} className={step.iconColor} />
                  </motion.div>
                </div>

                {/* Content */}
                <div className="pb-1">
                  <div className="mb-0.5 flex items-center gap-2">
                    <span className={cn('text-xs font-medium', step.statusColor)}>{step.status}</span>
                  </div>
                  <h4 className="text-base font-semibold text-slate-900">{step.title}</h4>
                  <p className="mt-0.5 text-sm leading-relaxed text-slate-600">{step.body}</p>
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </section>

      {/* Appointment Summary Card */}
      <section
        id="summary"
        data-animate
        className="mx-auto max-w-[720px] bg-white px-4 py-6"
      >
        <motion.div
          variants={summaryRowVariants}
          initial="hidden"
          animate={visibleSections.has('summary') ? 'show' : 'hidden'}
          className="rounded-2xl border border-slate-200 p-5"
        >
          <motion.h3 variants={summaryItemVariants} className="mb-4 text-lg font-semibold text-slate-900">
            Request Summary
          </motion.h3>

          <div className="flex flex-col gap-3.5">
            <motion.div variants={summaryItemVariants} className="flex flex-col gap-0.5">
              <span className="text-xs font-medium uppercase tracking-wide text-slate-500">Doctor</span>
              <span className="text-sm font-medium text-slate-900">Dr. Priya Sharma</span>
            </motion.div>
            <motion.div variants={summaryItemVariants} className="flex flex-col gap-0.5">
              <span className="text-xs font-medium uppercase tracking-wide text-slate-500">Clinic</span>
              <span className="text-sm font-medium text-slate-900">Scarborough Family Health Centre</span>
            </motion.div>
            <motion.div variants={summaryItemVariants} className="flex flex-col gap-0.5">
              <span className="text-xs font-medium uppercase tracking-wide text-slate-500">Your Name</span>
              <span className="text-sm font-medium text-slate-900">Jennifer Wong</span>
            </motion.div>
            <motion.div variants={summaryItemVariants} className="flex flex-col gap-0.5">
              <span className="text-xs font-medium uppercase tracking-wide text-slate-500">Contact</span>
              <span className="text-sm font-medium text-slate-900">
                (416) 555-0199 · jennifer@email.com
              </span>
            </motion.div>
            <motion.div variants={summaryItemVariants} className="flex flex-col gap-0.5">
              <span className="text-xs font-medium uppercase tracking-wide text-slate-500">Submitted</span>
              <span className="text-sm font-medium text-slate-900">
                {new Date().toLocaleDateString('en-CA', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}{' '}
                at{' '}
                {new Date().toLocaleTimeString('en-CA', {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </motion.div>
          </div>

          <motion.div variants={summaryItemVariants} className="mt-4">
            <button
              onClick={handleEditRequest}
              className="text-xs font-medium text-teal-600 underline underline-offset-2 transition-colors hover:text-teal-700"
            >
              Need to make changes?
            </button>
          </motion.div>
        </motion.div>
      </section>

      {/* Quick Actions */}
      <section
        id="actions"
        data-animate
        className="mx-auto max-w-[720px] bg-stone-50 px-4 py-6 pb-8"
      >
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={visibleSections.has('actions') ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.4, ease: easeDefault }}
          className="mb-5 text-[1.375rem] font-semibold text-slate-900"
        >
          While you wait
        </motion.h2>

        <motion.div
          variants={staggerCardVariants}
          initial="hidden"
          animate={visibleSections.has('actions') ? 'show' : 'hidden'}
          className="grid grid-cols-2 gap-3"
        >
          {/* Add to Calendar */}
          <motion.div
            variants={cardItemVariants}
            className="rounded-[14px] bg-white p-5"
          >
            <Calendar size={28} className="mb-3 text-teal-600" />
            <h4 className="mb-1 text-base font-semibold text-slate-900">Add reminder</h4>
            <p className="mb-3 text-sm leading-relaxed text-slate-600">
              Set a reminder to follow up in 3 days.
            </p>
            <button
              onClick={handleAddToCalendar}
              className="text-sm font-medium text-teal-600 transition-colors hover:text-teal-700"
            >
              Add to Calendar
            </button>
          </motion.div>

          {/* Find Pharmacy */}
          <motion.div
            variants={cardItemVariants}
            className="rounded-[14px] bg-white p-5"
          >
            <Pill size={28} className="mb-3 text-teal-600" />
            <h4 className="mb-1 text-base font-semibold text-slate-900">Pharmacy nearby</h4>
            <p className="mb-3 text-sm leading-relaxed text-slate-600">
              Find a pharmacy near the clinic.
            </p>
            <button
              onClick={handleFindPharmacy}
              className="text-sm font-medium text-teal-600 transition-colors hover:text-teal-700"
            >
              Find Pharmacy
            </button>
          </motion.div>

          {/* Emergency Info */}
          <motion.div
            variants={cardItemVariants}
            className="rounded-[14px] border border-alert-red bg-alert-red-light p-5"
          >
            <AlertTriangle size={28} className="mb-3 text-alert-red" />
            <h4 className="mb-1 text-base font-semibold text-alert-red">Know where to go</h4>
            <p className="mb-3 text-sm leading-relaxed text-slate-700">
              Nearest ER: Scarborough Health Network — 2.1 km
            </p>
            <button
              onClick={handleGetDirections}
              className="text-sm font-medium text-alert-red transition-colors hover:text-red-700"
            >
              Get Directions
            </button>
          </motion.div>

          {/* Browse More */}
          <motion.div
            variants={cardItemVariants}
            className="rounded-[14px] bg-white p-5"
          >
            <Search size={28} className="mb-3 text-teal-600" />
            <h4 className="mb-1 text-base font-semibold text-slate-900">Keep looking</h4>
            <p className="mb-3 text-sm leading-relaxed text-slate-600">
              Not sure? Browse more family doctors.
            </p>
            <button
              onClick={handleBrowseMore}
              className="text-sm font-medium text-teal-600 transition-colors hover:text-teal-700"
            >
              Browse More
            </button>
          </motion.div>
        </motion.div>
      </section>

      {/* Feedback Prompt */}
      <section
        id="feedback"
        data-animate
        className="mx-auto max-w-[720px] border-t border-slate-200 bg-white px-4 py-6 pb-8"
      >
        <AnimatePresence>
          {!feedbackSent && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={visibleSections.has('feedback') ? { opacity: 1, y: 0 } : {}}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.4, ease: easeDefault }}
            >
              <h3 className="mb-4 text-lg font-semibold text-slate-900">
                How was your experience with CareMap?
              </h3>

              {/* Star Rating */}
              <div className="mb-4 flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <motion.button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    whileHover={{ scale: 1.2 }}
                    transition={{ duration: 0.15, ease: easeSpring }}
                    className="p-1"
                  >
                    <Star
                      size={32}
                      className={cn(
                        'transition-colors',
                        star <= (hoverRating || rating)
                          ? 'fill-rating text-rating'
                          : 'fill-none text-slate-200'
                      )}
                    />
                  </motion.button>
                ))}
              </div>

              {/* Feedback Textarea */}
              <AnimatePresence>
                {rating > 0 && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3, ease: easeDefault }}
                    className="overflow-hidden"
                  >
                    <textarea
                      rows={3}
                      placeholder="Tell us what went well or what we can improve..."
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 px-4 py-3 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-[3px] focus:ring-teal-500/15"
                    />
                    <button
                      onClick={handleSendFeedback}
                      className="mt-3 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-teal-50 hover:text-teal-700"
                    >
                      <Send size={16} />
                      Send Feedback
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Share CTA */}
      <section
        id="share"
        data-animate
        className="mx-auto max-w-[720px] bg-teal-600 px-4 py-8"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={visibleSections.has('share') ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.4, ease: easeDefault }}
          className="text-center"
        >
          <h2 className="text-[1.375rem] font-semibold text-white">
            Help someone else find care
          </h2>
          <p className="mx-auto mt-2 max-w-[420px] text-base leading-relaxed text-teal-50">
            Know someone looking for a doctor? Share CareMap with them.
          </p>
          <motion.button
            onClick={handleShare}
            initial={{ scale: 0.95, opacity: 0 }}
            animate={visibleSections.has('share') ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.3, delay: 0.2, ease: easeSpring }}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white py-3.5 text-base font-semibold text-teal-700 transition-colors hover:bg-teal-50"
          >
            <Share2 size={18} />
            Share CareMap
          </motion.button>
        </motion.div>
      </section>
    </div>
  )
}
