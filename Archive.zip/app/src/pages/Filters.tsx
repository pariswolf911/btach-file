import { useState, useMemo, useCallback, useEffect } from 'react'
import { useNavigate } from 'react-router'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  Search,
  Star,
  ChevronDown,
  ChevronUp,
  Check,
  Accessibility,
  Moon,
  ParkingCircle,
  TrainFront,
  TreePine,
  Globe,
} from 'lucide-react'
import { useFilterParams } from '@/data/filters'
import { doctors } from '@/data/mockDoctors'
import { specialties, neighborhoods, languages } from '@/data/mockDoctors'
import type { FilterState } from '@/data/filters'

/* ------------------------------------------------------------------ */
/*  Toggle Switch                                                      */
/* ------------------------------------------------------------------ */

function Toggle({
  checked,
  onChange,
  ariaLabel,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  ariaLabel?: string
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      onClick={() => onChange(!checked)}
      className={`relative h-7 w-12 rounded-full transition-colors duration-200 ${
        checked ? 'bg-teal-600' : 'bg-slate-200'
      }`}
    >
      <span
        className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow-sm transition-transform duration-200 ${
          checked ? 'translate-x-5' : 'translate-x-0.5'
        }`}
      />
    </button>
  )
}

/* ------------------------------------------------------------------ */
/*  Checkbox Item                                                      */
/* ------------------------------------------------------------------ */

function CheckboxItem({
  label,
  sublabel,
  checked,
  onChange,
}: {
  label: string
  sublabel?: string
  checked: boolean
  onChange: () => void
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-lg py-2 transition-colors hover:bg-slate-50">
      <div
        className={`flex h-5 w-5 flex-shrink-0 items-center justify-center rounded border transition-colors ${
          checked ? 'border-teal-600 bg-teal-600' : 'border-slate-300 bg-white'
        }`}
      >
        {checked && <Check size={12} className="text-white" aria-hidden="true" />}
      </div>
      <input type="checkbox" className="sr-only" checked={checked} onChange={onChange} />
      <div className="flex-1 min-w-0">
        <span className={`text-sm ${checked ? 'font-medium text-teal-700' : 'text-slate-700'}`}>{label}</span>
        {sublabel && <span className="ml-2 text-xs text-slate-500">{sublabel}</span>}
      </div>
    </label>
  )
}

/* ------------------------------------------------------------------ */
/*  Specialty Grid                                                   */
/* ------------------------------------------------------------------ */

function SpecialtySection({
  value,
  onChange,
}: {
  value: string[]
  onChange: (v: string[]) => void
}) {
  const toggle = useCallback(
    (s: string) => {
      onChange(value.includes(s) ? value.filter((x) => x !== s) : [...value, s])
    },
    [value, onChange]
  )

  return (
    <div className="pb-5">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-900">Specialty</h4>
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-1 md:gap-1">
        {specialties.map((s, i) => {
          const active = value.includes(s)
          return (
            <motion.button
              key={s}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04, duration: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
              onClick={() => toggle(s)}
              className={`rounded-xl border px-3 py-3 text-sm font-medium transition-all md:flex md:items-center md:gap-3 md:rounded-lg md:px-3 md:py-2.5 ${
                active
                  ? 'border-transparent bg-teal-600 text-white'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-stone-50'
              } active:scale-[0.97]`}
            >
              <span className="hidden md:block">
                <div
                  className={`flex h-5 w-5 items-center justify-center rounded border ${
                    active ? 'border-white bg-white/20' : 'border-slate-300 bg-white'
                  }`}
                >
                  {active && <Check size={12} className="text-teal-700" />}
                </div>
              </span>
              {s}
            </motion.button>
          )
        })}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Location Section                                                   */
/* ------------------------------------------------------------------ */

function LocationSection({
  neighborhoodsValue,
  onNeighborhoodsChange,
  distanceKm,
  onDistanceChange,
}: {
  neighborhoodsValue: string[]
  onNeighborhoodsChange: (v: string[]) => void
  distanceKm: number
  onDistanceChange: (v: number) => void
}) {
  const [neighSearch, setNeighSearch] = useState('')
  const [neighExpanded, setNeighExpanded] = useState(true)

  const filteredNeigh = useMemo(
    () =>
      neighborhoods.filter((n) => n.toLowerCase().includes(neighSearch.toLowerCase())),
    [neighSearch]
  )

  return (
    <div className="border-b border-slate-100 py-5 md:border-b-0">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-900">Location</h4>

      {/* Distance Slider */}
      <div className="mb-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm font-medium text-slate-700">Within {distanceKm} km</span>
        </div>
        <input
          type="range"
          min={1}
          max={50}
          step={1}
          value={distanceKm}
          onChange={(e) => onDistanceChange(Number(e.target.value))}
          className="w-full accent-teal-600"
          style={{
            accentColor: '#0D9488',
          }}
          aria-label="Distance range"
        />
        <div className="mt-1 flex justify-between text-xs text-slate-500">
          <span>1km</span>
          <span>10km</span>
          <span>25km</span>
          <span>50km</span>
        </div>
      </div>

      {/* Neighborhood Multi-Select */}
      <div>
        <button
          onClick={() => setNeighExpanded(!neighExpanded)}
          className="mb-2 flex w-full items-center justify-between rounded-lg py-1 text-sm font-medium text-slate-700 hover:bg-slate-50"
        >
          Neighborhoods
          {neighExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>

        <AnimatePresence>
          {neighExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="relative mb-2">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search neighborhood..."
                  value={neighSearch}
                  onChange={(e) => setNeighSearch(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm text-slate-900 outline-none transition-shadow focus:border-teal-500 focus:shadow-[0_0_0_3px_rgba(13,148,136,0.15)]"
                />
              </div>
              <div className="max-h-[200px] overflow-y-auto pr-1">
                {filteredNeigh.map((n, i) => (
                  <motion.div
                    key={n}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                  >
                    <CheckboxItem
                      label={n}
                      checked={neighborhoodsValue.includes(n)}
                      onChange={() =>
                        onNeighborhoodsChange(
                          neighborhoodsValue.includes(n)
                            ? neighborhoodsValue.filter((x) => x !== n)
                            : [...neighborhoodsValue, n]
                        )
                      }
                    />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Availability Section                                               */
/* ------------------------------------------------------------------ */

const waitOptions: { value: FilterState['maxWaitTime']; label: string }[] = [
  { value: 'Any', label: 'Any' },
  { value: '2 weeks', label: 'Within 2 weeks' },
  { value: '1 month', label: 'Within 1 month' },
  { value: '3 months', label: 'Within 3 months' },
]

function AvailabilitySection({
  acceptingNewPatients,
  onAcceptingChange,
  maxWaitTime,
  onMaxWaitChange,
  nextAvailableDate,
  onNextAvailableChange,
}: {
  acceptingNewPatients: boolean
  onAcceptingChange: (v: boolean) => void
  maxWaitTime: FilterState['maxWaitTime']
  onMaxWaitChange: (v: FilterState['maxWaitTime']) => void
  nextAvailableDate: string
  onNextAvailableChange: (v: string) => void
}) {
  return (
    <div className="border-b border-slate-100 py-5 md:border-b-0">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-900">Availability</h4>

      <div className="mb-4 flex items-center justify-between">
        <span className="text-sm text-slate-900">Accepting new patients</span>
        <Toggle checked={acceptingNewPatients} onChange={onAcceptingChange} />
      </div>

      <div className="mb-4">
        <span className="mb-2 block text-sm text-slate-900">Maximum wait time</span>
        <div className="flex flex-wrap gap-2">
          {waitOptions.map((opt) => (
            <button
              key={opt.value}
              onClick={() => onMaxWaitChange(opt.value)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                maxWaitTime === opt.value
                  ? 'bg-teal-600 text-white'
                  : 'border border-slate-200 bg-white text-slate-700 hover:bg-stone-50'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <span className="mb-2 block text-sm text-slate-900">Next appointment</span>
        <div className="relative">
          <input
            type="date"
            value={nextAvailableDate}
            onChange={(e) => onNextAvailableChange(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-3 pr-10 text-sm text-slate-900 outline-none transition-shadow focus:border-teal-500 focus:shadow-[0_0_0_3px_rgba(13,148,136,0.15)]"
            placeholder="Any date"
          />
          <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">
            {nextAvailableDate ? '' : 'Any date'}
          </span>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Language Section                                                   */
/* ------------------------------------------------------------------ */

function LanguageSection({
  value,
  onChange,
}: {
  value: string[]
  onChange: (v: string[]) => void
}) {
  const [search, setSearch] = useState('')
  const [expanded, setExpanded] = useState(true)

  const filtered = useMemo(
    () => languages.filter((l) => l.toLowerCase().includes(search.toLowerCase())),
    [search]
  )

  // Mock speaker counts
  const speakerCount: Record<string, number> = useMemo(() => {
    const counts: Record<string, number> = {}
    languages.forEach((lang) => {
      counts[lang] = doctors.filter((d) => d.languages.includes(lang)).length
    })
    return counts
  }, [])

  return (
    <div className="border-b border-slate-100 py-5 md:border-b-0">
      <button
        onClick={() => setExpanded(!expanded)}
        className="mb-3 flex w-full items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-900"
      >
        Languages
        {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="relative mb-2">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search language..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm text-slate-900 outline-none transition-shadow focus:border-teal-500 focus:shadow-[0_0_0_3px_rgba(13,148,136,0.15)]"
              />
            </div>
            <div className="max-h-[200px] overflow-y-auto pr-1">
              {filtered.map((lang, i) => (
                <motion.div
                  key={lang}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <CheckboxItem
                    label={lang}
                    sublabel={`${speakerCount[lang]} doctors`}
                    checked={value.includes(lang)}
                    onChange={() =>
                      onChange(
                        value.includes(lang) ? value.filter((x) => x !== lang) : [...value, lang]
                      )
                    }
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Accessibility Section                                              */
/* ------------------------------------------------------------------ */

const accessibilityItems = [
  { key: 'wheelchair' as const, label: 'Wheelchair accessible', icon: Accessibility },
  { key: 'eveningWeekend' as const, label: 'Evening/weekend hours', icon: Moon },
  { key: 'parking' as const, label: 'Parking available', icon: ParkingCircle },
  { key: 'transit' as const, label: 'Transit accessible', icon: TrainFront },
  { key: 'ohip' as const, label: 'OHIP accepted', icon: TreePine },
  { key: 'ifhp' as const, label: 'IFHP accepted (refugees)', icon: Globe },
]

type AccessibilityKey = typeof accessibilityItems[number]['key']

function AccessibilitySection({
  filters,
  onChange,
}: {
  filters: Pick<FilterState, AccessibilityKey>
  onChange: (key: AccessibilityKey, value: boolean) => void
}) {
  return (
    <div className="border-b border-slate-100 py-5 md:border-b-0">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-900">
        Accessibility & Amenities
      </h4>
      <div className="space-y-3">
        {accessibilityItems.map((item) => {
          const Icon = item.icon
          const checked = filters[item.key] ?? false
          return (
            <div key={item.key} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Icon size={16} className="text-slate-500" aria-hidden="true" />
                <span className="text-sm text-slate-900">{item.label}</span>
              </div>
              <Toggle checked={checked} onChange={(v) => onChange(item.key, v)} />
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Rating Section                                                   */
/* ------------------------------------------------------------------ */

function RatingSection({
  value,
  onChange,
}: {
  value: number
  onChange: (v: number) => void
}) {
  const [hover, setHover] = useState(0)

  return (
    <div className="border-b border-slate-100 py-5 md:border-b-0">
      <h4 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-900">Minimum Rating</h4>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] }}
        className="flex items-center gap-1"
        onMouseLeave={() => setHover(0)}
      >
        {[1, 2, 3, 4, 5].map((star) => {
          const filled = star <= (hover || value)
          return (
            <button
              key={star}
              onClick={() => onChange(star === value ? 0 : star)}
              onMouseEnter={() => setHover(star)}
              className="p-0.5 transition-transform hover:scale-110"
              aria-label={`${star} stars minimum`}
            >
              <Star
                size={28}
                className={filled ? 'fill-[#F59E0B] text-[#F59E0B]' : 'text-slate-200'}
              />
            </button>
          )
        })}
      </motion.div>
      <p className="mt-1 text-sm text-slate-600">
        {value > 0 ? `${value.toFixed(1)} and above` : 'Any rating'}
      </p>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Filters Page                                                       */
/* ------------------------------------------------------------------ */

export default function Filters() {
  const navigate = useNavigate()
  const { filters, setFilters, resetFilters } = useFilterParams()
  const [localFilters, setLocalFilters] = useState<FilterState>(filters)

  // Sync URL -> local when filters change (nav/back etc)
  useEffect(() => {
    setLocalFilters(filters)
  }, [filters])

  const updateLocal = useCallback(
    (updater: (prev: FilterState) => FilterState) => {
      setLocalFilters((prev) => updater(prev))
    },
    []
  )

  const applyFilters = useCallback(() => {
    setFilters(localFilters)
    navigate('/results')
  }, [localFilters, setFilters, navigate])

  // Live result count preview
  const previewCount = useMemo(() => {
    let res = [...doctors]

    if (localFilters.specialties.length > 0) {
      res = res.filter((d) => localFilters.specialties.includes(d.specialty))
    }

    if (localFilters.neighborhoods.length > 0) {
      res = res.filter((d) => localFilters.neighborhoods.includes(d.neighborhood))
    }

    if (localFilters.languages.length > 0) {
      res = res.filter((d) => localFilters.languages.some((l) => d.languages.includes(l)))
    }

    if (localFilters.acceptingNewPatients) {
      res = res.filter((d) => d.acceptingNewPatients)
    }

    if (localFilters.wheelchair) {
      res = res.filter((d) => d.wheelchair)
    }

    if (localFilters.eveningWeekend) {
      res = res.filter((d) => d.eveningWeekend)
    }

    if (localFilters.ohip) {
      res = res.filter((d) => d.ohip)
    }

    if (localFilters.distanceKm < 50) {
      res = res.filter((d) => d.distanceKm <= localFilters.distanceKm)
    }

    if (localFilters.minRating > 0) {
      res = res.filter((d) => d.rating >= localFilters.minRating)
    }

    switch (localFilters.maxWaitTime) {
      case '2 weeks':
        res = res.filter((d) => d.waitTimeDays <= 14)
        break
      case '1 month':
        res = res.filter((d) => d.waitTimeDays <= 30)
        break
      case '3 months':
        res = res.filter((d) => d.waitTimeDays <= 90)
        break
    }

    return res.length
  }, [localFilters])

  return (
    <div className="min-h-[100dvh] bg-[rgba(15,23,42,0.4)] md:bg-[#FAFAF9]">
      {/* Mobile Bottom Sheet / Desktop Panel */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
        className="mx-auto flex min-h-[100dvh] flex-col bg-white md:min-h-0 md:max-w-[720px] md:rounded-2xl md:border md:border-slate-200 md:shadow-[0_1px_3px_rgba(15,23,42,0.06)]"
      >
        {/* Drag handle (mobile) */}
        <div className="flex h-10 items-center justify-center md:hidden">
          <div className="h-1 w-10 rounded-full bg-slate-300" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-5 pb-4 pt-2 md:border-b-0 md:px-6 md:pt-6">
          <div>
            <h2 className="text-xl font-semibold text-slate-900">Filters</h2>
            <p className="mt-0.5 text-sm text-teal-600">
              {previewCount} result{previewCount !== 1 ? 's' : ''} match your criteria
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                resetFilters()
                setLocalFilters({ ...localFilters, ...filters })
              }}
              className="hidden text-sm font-medium text-teal-600 transition-colors hover:text-teal-700 md:block"
            >
              Reset
            </button>
            <button
              onClick={() => navigate('/results')}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-700 transition-colors hover:bg-slate-100 md:hidden"
              aria-label="Close filters"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-5 pb-4 md:px-6">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={{
              visible: { transition: { staggerChildren: 0.05 } },
            }}
          >
            <motion.div variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
              <SpecialtySection
                value={localFilters.specialties}
                onChange={(v) => updateLocal((prev) => ({ ...prev, specialties: v }))}
              />
            </motion.div>

            <motion.div variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
              <LocationSection
                neighborhoodsValue={localFilters.neighborhoods}
                onNeighborhoodsChange={(v) => updateLocal((prev) => ({ ...prev, neighborhoods: v }))}
                distanceKm={localFilters.distanceKm}
                onDistanceChange={(v) => updateLocal((prev) => ({ ...prev, distanceKm: v }))}
              />
            </motion.div>

            <motion.div variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
              <AvailabilitySection
                acceptingNewPatients={localFilters.acceptingNewPatients}
                onAcceptingChange={(v) => updateLocal((prev) => ({ ...prev, acceptingNewPatients: v }))}
                maxWaitTime={localFilters.maxWaitTime}
                onMaxWaitChange={(v) => updateLocal((prev) => ({ ...prev, maxWaitTime: v }))}
                nextAvailableDate={localFilters.nextAvailableDate}
                onNextAvailableChange={(v) => updateLocal((prev) => ({ ...prev, nextAvailableDate: v }))}
              />
            </motion.div>

            <motion.div variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
              <LanguageSection
                value={localFilters.languages}
                onChange={(v) => updateLocal((prev) => ({ ...prev, languages: v }))}
              />
            </motion.div>

            <motion.div variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
              <AccessibilitySection
                filters={localFilters}
                onChange={(key, value) => updateLocal((prev) => ({ ...prev, [key]: value }))}
              />
            </motion.div>

            <motion.div variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
              <RatingSection
                value={localFilters.minRating}
                onChange={(v) => updateLocal((prev) => ({ ...prev, minRating: v }))}
              />
            </motion.div>
          </motion.div>
        </div>

        {/* Footer (mobile sticky / desktop inline) */}
        <div className="sticky bottom-0 border-t border-slate-200 bg-white px-5 py-4 shadow-[0_-4px_12px_rgba(15,23,42,0.04)] md:static md:px-6">
          <button
            onClick={applyFilters}
            className="mb-2 w-full rounded-xl bg-[#F97316] px-4 py-3.5 text-base font-semibold text-white shadow-[0_1px_2px_rgba(249,115,22,0.2)] transition-transform hover:scale-[1.02] active:scale-[0.98]"
          >
            Show {previewCount} Result{previewCount !== 1 ? 's' : ''}
          </button>
          <button
            onClick={() => {
              setLocalFilters({
                specialties: [],
                neighborhoods: [],
                languages: [],
                acceptingNewPatients: false,
                maxWaitTime: 'Any',
                nextAvailableDate: '',
                distanceKm: 50,
                wheelchair: false,
                eveningWeekend: false,
                parking: false,
                transit: false,
                ohip: false,
                ifhp: false,
                minRating: 0,
                sortBy: 'nearest',
                query: '',
              })
            }}
            className="w-full py-2 text-sm font-medium text-teal-600 transition-colors hover:text-teal-700 md:hidden"
          >
            Reset All Filters
          </button>
        </div>
      </motion.div>
    </div>
  )
}
