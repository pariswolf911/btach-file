import { useState, useEffect, useCallback } from 'react'
import { useNavigate, Link } from 'react-router'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { motion, AnimatePresence } from 'framer-motion'
import { toast, Toaster } from 'sonner'
import { cn } from '@/lib/utils'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  ChevronLeft,
  Phone,
  Mail,
  CalendarDays,
  AlertTriangle,
  ShieldCheck,
  Loader2,
} from 'lucide-react'

const easeDefault = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeSpring = [0.34, 1.56, 0.64, 1] as [number, number, number, number]

const phoneRegex = /^(\+?1\s?)?(\([0-9]{3}\)|[0-9]{3})[\s\-]?[0-9]{3}[\s\-]?[0-9]{4}$/
const ohipRegex = /^\d{4}-\d{3}-\d{3}-[A-Z]{2}$/

const accessibilityOptions = [
  { id: 'wheelchair', label: 'Wheelchair access' },
  { id: 'interpreter', label: 'Interpreter needed' },
  { id: 'hearing', label: 'Hearing assistance' },
  { id: 'vision', label: 'Vision assistance' },
  { id: 'other', label: 'Other' },
]

const languageOptions = [
  'English',
  'French',
  'Mandarin',
  'Cantonese',
  'Hindi',
  'Punjabi',
  'Gujarati',
  'Tamil',
  'Urdu',
  'Arabic',
  'Spanish',
  'Italian',
  'Korean',
  'Tagalog',
  'Other',
]

const formSchema = z.object({
  fullName: z.string().min(2, 'Please enter your full name'),
  dateOfBirth: z.string().min(1, 'Please enter a valid date of birth'),
  phone: z.string().regex(phoneRegex, 'Please enter a valid Canadian phone number'),
  email: z.string().email('Please enter a valid email address'),
  ohip: z.string().optional().refine((val) => !val || ohipRegex.test(val), {
    message: 'Please enter a valid OHIP number',
  }),
  preferredLanguage: z.string().min(1, 'Please select a language'),
  preferredContact: z.enum(['phone', 'email', 'text']),
  reasonForVisit: z
    .string()
    .max(500, 'Please keep your response under 500 characters')
    .optional(),
  transferRecords: z.boolean(),
  previousDoctor: z.string().optional(),
  accessibilityNeeds: z.array(z.string()),
  accessibilityOther: z.string().optional(),
  consent: z.boolean(),
}).refine((data) => data.consent === true, {
  message: 'You must consent to proceed',
  path: ['consent'],
})

type FormData = z.infer<typeof formSchema>

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: easeDefault } },
}

export default function Register() {
  const navigate = useNavigate()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [shakeFields, setShakeFields] = useState<Set<string>>(new Set())
  const [showPrivacyModal, setShowPrivacyModal] = useState(false)
  const [showEmergencyModal, setShowEmergencyModal] = useState(false)

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors },
    trigger,
  } = useForm({
    resolver: zodResolver(formSchema),
    mode: 'onBlur',
    defaultValues: {
      preferredLanguage: 'English',
      preferredContact: undefined,
      transferRecords: false,
      accessibilityNeeds: [],
      consent: false,
      previousDoctor: '',
      accessibilityOther: '',
      reasonForVisit: '',
      ohip: '',
    },
  })

  const transferRecords = watch('transferRecords')
  const accessibilityNeeds = watch('accessibilityNeeds')
  const reasonForVisit = watch('reasonForVisit') || ''
  const consent = watch('consent')

  const hasOtherAccessibility = accessibilityNeeds.includes('other')

  const isFormValid =
    consent &&
    Object.keys(errors).length === 0 &&
    watch('fullName')?.length >= 2 &&
    watch('dateOfBirth') &&
    phoneRegex.test(watch('phone') || '') &&
    z.string().email().safeParse(watch('email') || '').success &&
    watch('preferredContact') !== undefined

  const onSubmit = useCallback(
    async (_values: FormData) => {
      setIsSubmitting(true)
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setIsSubmitting(false)
      toast.success('Request submitted successfully!')
      navigate('/confirm')
    },
    [navigate]
  )

  const onError = useCallback(() => {
    const fieldNames = Object.keys(errors)
    setShakeFields(new Set(fieldNames))
    setTimeout(() => setShakeFields(new Set()), 500)

    const firstErrorField = document.querySelector('[data-error="true"]')
    if (firstErrorField) {
      firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  }, [errors])

  useEffect(() => {
    if (Object.keys(errors).length > 0) {
      onError()
    }
  }, [errors, onError])

  const shakeProps = (fieldName: string) =>
    shakeFields.has(fieldName)
      ? {
          animate: { x: [0, -8, 8, -8, 8, 0] },
          transition: { duration: 0.4 },
        }
      : {}

  return (
    <div className="min-h-[100dvh] bg-stone-50">
      <Toaster />

      {/* Form Header */}
      <header className="border-b border-slate-200 bg-white px-4 py-4">
        <div className="mx-auto max-w-[720px]">
          <Link
            to="/profile"
            className="mb-4 inline-flex items-center gap-1 text-xs font-medium text-slate-700 transition-colors hover:text-teal-600"
          >
            <ChevronLeft size={14} />
            Back to Dr. Sharma
          </Link>

          {/* Step Indicator */}
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="flex flex-col items-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', duration: 0.3, delay: 0.1 }}
                className="flex h-6 w-6 items-center justify-center rounded-full bg-teal-600 text-xs font-medium text-white"
              >
                1
              </motion.div>
              <span className="mt-1 text-xs font-medium text-teal-600">Your Info</span>
            </div>
            <div className="relative top-[-8px] h-px w-10 bg-slate-200" />
            <div className="flex flex-col items-center">
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-300 text-xs font-medium text-white">
                2
              </div>
              <span className="mt-1 text-xs font-medium text-slate-500">Confirm</span>
            </div>
          </div>

          <h1 className="text-xl font-bold leading-tight tracking-tight text-slate-900 md:text-[1.75rem]">
            Request to join Dr. Sharma&apos;s patient roster
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            This form sends your information directly to the clinic. No diagnosis or medical advice
            will be provided.
          </p>
        </div>
      </header>

      {/* Doctor Summary Card */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2, ease: easeDefault }}
        className="mx-auto max-w-[720px] px-4 py-4"
      >
        <div className="rounded-2xl bg-teal-50 p-4">
          <div className="flex items-center gap-3">
            <img
              src="/doctor-avatar-1.jpg"
              alt="Dr. Priya Sharma"
              className="h-12 w-12 rounded-full border-2 border-white object-cover"
            />
            <div className="flex-1 min-w-0">
              <p className="text-base font-semibold text-slate-900">Dr. Priya Sharma</p>
              <p className="text-xs text-slate-500">Scarborough Family Health Centre</p>
              <p className="text-xs text-teal-600">1.2 km · Family Medicine</p>
            </div>
            <Link
              to="/results"
              className="text-xs font-medium text-teal-600 underline underline-offset-2"
            >
              Change
            </Link>
          </div>
        </div>
      </motion.section>

      {/* Patient Info Form */}
      <motion.form
        variants={containerVariants}
        initial="hidden"
        animate="show"
        onSubmit={handleSubmit(onSubmit, onError)}
        className="mx-auto max-w-[720px] px-4 py-2"
        noValidate
      >
        <motion.h2
          variants={itemVariants}
          className="mb-5 text-[1.375rem] font-semibold leading-snug text-slate-900"
        >
          Your Information
        </motion.h2>

        <div className="flex flex-col gap-5">
          {/* Full Name */}
          <motion.div variants={itemVariants} {...shakeProps('fullName')} data-error={!!errors.fullName}>
            <Label htmlFor="fullName" className="mb-1.5 flex items-center gap-1 text-base font-semibold text-slate-900">
              Full Name
              <span className="text-alert-red">*</span>
            </Label>
            <Input
              id="fullName"
              placeholder="e.g., Jennifer Wong"
              {...register('fullName')}
              onBlur={() => trigger('fullName')}
              className={cn(
                'h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15',
                errors.fullName && 'border-alert-red focus:border-alert-red focus:ring-red-500/10'
              )}
            />
            <AnimatePresence>
              {errors.fullName && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.fullName.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Date of Birth */}
          <motion.div variants={itemVariants} {...shakeProps('dateOfBirth')} data-error={!!errors.dateOfBirth}>
            <Label htmlFor="dateOfBirth" className="mb-1.5 flex items-center gap-1 text-base font-semibold text-slate-900">
              Date of Birth
              <span className="text-alert-red">*</span>
            </Label>
            <div className="relative">
              <Input
                id="dateOfBirth"
                type="date"
                {...register('dateOfBirth')}
                onBlur={() => trigger('dateOfBirth')}
                className={cn(
                  'h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15',
                  errors.dateOfBirth && 'border-alert-red focus:border-alert-red focus:ring-red-500/10'
                )}
              />
              <CalendarDays
                size={18}
                className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"
              />
            </div>
            <AnimatePresence>
              {errors.dateOfBirth && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.dateOfBirth.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Phone Number */}
          <motion.div variants={itemVariants} {...shakeProps('phone')} data-error={!!errors.phone}>
            <Label htmlFor="phone" className="mb-1.5 flex items-center gap-1 text-base font-semibold text-slate-900">
              Phone Number
              <span className="text-alert-red">*</span>
            </Label>
            <div className="relative">
              <Phone
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <Input
                id="phone"
                placeholder="(416) 555-0000"
                {...register('phone')}
                onBlur={() => trigger('phone')}
                className={cn(
                  'h-12 rounded-xl border-slate-200 pl-11 pr-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15',
                  errors.phone && 'border-alert-red focus:border-alert-red focus:ring-red-500/10'
                )}
              />
            </div>
            <AnimatePresence>
              {errors.phone && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.phone.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Email */}
          <motion.div variants={itemVariants} {...shakeProps('email')} data-error={!!errors.email}>
            <Label htmlFor="email" className="mb-1.5 flex items-center gap-1 text-base font-semibold text-slate-900">
              Email Address
              <span className="text-alert-red">*</span>
            </Label>
            <div className="relative">
              <Mail
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <Input
                id="email"
                type="email"
                placeholder="you@email.com"
                {...register('email')}
                onBlur={() => trigger('email')}
                className={cn(
                  'h-12 rounded-xl border-slate-200 pl-11 pr-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15',
                  errors.email && 'border-alert-red focus:border-alert-red focus:ring-red-500/10'
                )}
              />
            </div>
            <AnimatePresence>
              {errors.email && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.email.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* OHIP Number */}
          <motion.div variants={itemVariants} {...shakeProps('ohip')} data-error={!!errors.ohip}>
            <Label htmlFor="ohip" className="mb-1.5 flex items-center gap-1 text-base font-semibold text-slate-900">
              OHIP Health Card Number
            </Label>
            <div className="relative">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                className="absolute left-4 top-1/2 -translate-y-1/2 text-teal-600"
              >
                <path
                  d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <Input
                id="ohip"
                placeholder="1234-567-890-XX"
                {...register('ohip')}
                onBlur={() => trigger('ohip')}
                className={cn(
                  'h-12 rounded-xl border-slate-200 pl-11 pr-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15',
                  errors.ohip && 'border-alert-red focus:border-alert-red focus:ring-red-500/10'
                )}
              />
            </div>
            <p className="mt-1 text-xs text-slate-500">Your 10-digit Ontario health card number</p>
            <AnimatePresence>
              {errors.ohip && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.ohip.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Preferred Language */}
          <motion.div variants={itemVariants} {...shakeProps('preferredLanguage')} data-error={!!errors.preferredLanguage}>
            <Label className="mb-1.5 flex items-center gap-1 text-base font-semibold text-slate-900">
              Preferred Language
              <span className="text-alert-red">*</span>
            </Label>
            <Controller
              name="preferredLanguage"
              control={control}
              render={({ field }) => (
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <SelectTrigger
                    className={cn(
                      'h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 focus:ring-[3px] focus:ring-teal-500/15',
                      errors.preferredLanguage && 'border-alert-red focus:ring-red-500/10'
                    )}
                  >
                    <SelectValue placeholder="Select a language" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl border-slate-200 shadow-dropdown">
                    {languageOptions.map((lang) => (
                      <SelectItem key={lang} value={lang} className="text-base">
                        {lang}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
            <AnimatePresence>
              {errors.preferredLanguage && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.preferredLanguage.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Preferred Contact Method */}
          <motion.div variants={itemVariants} {...shakeProps('preferredContact')} data-error={!!errors.preferredContact}>
            <Label className="mb-2 flex items-center gap-1 text-base font-semibold text-slate-900">
              How should the clinic contact you?
              <span className="text-alert-red">*</span>
            </Label>
            <Controller
              name="preferredContact"
              control={control}
              render={({ field }) => (
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="grid grid-cols-3 gap-3"
                >
                  {[
                    { value: 'phone', label: 'Phone call' },
                    { value: 'text', label: 'Text message' },
                    { value: 'email', label: 'Email' },
                  ].map((option) => (
                    <label
                      key={option.value}
                      className={cn(
                        'flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-3 transition-all hover:border-slate-300',
                        field.value === option.value && 'border-teal-600 bg-teal-50'
                      )}
                    >
                      <RadioGroupItem value={option.value} id={option.value} />
                      <span
                        className={cn(
                          'text-sm font-medium',
                          field.value === option.value ? 'text-teal-700' : 'text-slate-700'
                        )}
                      >
                        {option.label}
                      </span>
                    </label>
                  ))}
                </RadioGroup>
              )}
            />
            <AnimatePresence>
              {errors.preferredContact && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.preferredContact.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Reason for Visit */}
          <motion.div variants={itemVariants} {...shakeProps('reasonForVisit')} data-error={!!errors.reasonForVisit}>
            <Label htmlFor="reasonForVisit" className="mb-1.5 text-base font-semibold text-slate-900">
              Why are you looking for a new family doctor?
            </Label>
            <Textarea
              id="reasonForVisit"
              rows={4}
              placeholder="e.g., I just moved to the area and need a primary care physician..."
              {...register('reasonForVisit')}
              onBlur={() => trigger('reasonForVisit')}
              className={cn(
                'rounded-xl border-slate-200 px-4 py-3 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15',
                errors.reasonForVisit && 'border-alert-red focus:border-alert-red focus:ring-red-500/10'
              )}
            />
            <div className="mt-1 flex items-center justify-between">
              <p className="text-xs text-slate-500">
                This helps the clinic understand your needs. Be brief — no medical diagnosis will be made.
              </p>
              <span className="text-xs text-slate-400">{reasonForVisit.length}/500</span>
            </div>
            <AnimatePresence>
              {errors.reasonForVisit && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-1 text-xs text-alert-red"
                >
                  {errors.reasonForVisit.message}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Transfer Records Toggle */}
          <motion.div variants={itemVariants}>
            <Label className="mb-2 text-base font-semibold text-slate-900">
              Do you need medical records transferred?
            </Label>
            <Controller
              name="transferRecords"
              control={control}
              render={({ field }) => (
                <div className="flex items-center gap-3">
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                  <span className="text-sm text-slate-700">
                    {field.value
                      ? 'Yes — clinic will contact your previous doctor'
                      : 'No'}
                  </span>
                </div>
              )}
            />
            <AnimatePresence>
              {transferRecords && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3, ease: easeDefault }}
                  className="overflow-hidden"
                >
                  <div className="pt-3">
                    <Label htmlFor="previousDoctor" className="mb-1.5 text-base font-semibold text-slate-900">
                      Previous Doctor/Clinic Name
                    </Label>
                    <Input
                      id="previousDoctor"
                      placeholder="Dr. Smith / Downtown Clinic"
                      {...register('previousDoctor')}
                      className="h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Accessibility Needs */}
          <motion.div variants={itemVariants} {...shakeProps('accessibilityNeeds')} data-error={!!errors.accessibilityNeeds}>
            <Label className="mb-2 text-base font-semibold text-slate-900">
              Do you have any accessibility needs?
            </Label>
            <div className="flex flex-col gap-2">
              {accessibilityOptions.map((option) => (
                <Controller
                  key={option.id}
                  name="accessibilityNeeds"
                  control={control}
                  render={({ field }) => (
                    <label className="flex cursor-pointer items-center gap-2.5">
                      <Checkbox
                        checked={field.value?.includes(option.id)}
                        onCheckedChange={(checked) => {
                          const updated = checked
                            ? [...(field.value || []), option.id]
                            : (field.value || []).filter((id) => id !== option.id)
                          field.onChange(updated)
                        }}
                      />
                      <span className="text-sm text-slate-700">{option.label}</span>
                    </label>
                  )}
                />
              ))}
            </div>
            <AnimatePresence>
              {hasOtherAccessibility && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3, ease: easeDefault }}
                  className="overflow-hidden"
                >
                  <div className="pt-3">
                    <Label htmlFor="accessibilityOther" className="mb-1.5 text-base font-semibold text-slate-900">
                      Please specify
                    </Label>
                    <Input
                      id="accessibilityOther"
                      placeholder="Describe your accessibility need..."
                      {...register('accessibilityOther')}
                      className="h-12 rounded-xl border-slate-200 px-4 text-base text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:ring-[3px] focus:ring-teal-500/15"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Consent & Submit */}
        <motion.div
          variants={itemVariants}
          className="mt-8 rounded-t-2xl bg-white px-4 py-6 pb-8 -mx-4"
        >
          <div className="mx-auto max-w-[720px] px-4">
            {/* Consent Checkbox */}
            <Controller
              name="consent"
              control={control}
              render={({ field }) => (
                <label className="flex cursor-pointer items-start gap-3">
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    className="mt-0.5"
                  />
                  <span className="text-sm leading-relaxed text-slate-700">
                    I consent to sharing this information with the clinic for the purpose of patient
                    registration. I understand that CareMap does not provide medical advice or diagnosis.{" "}
                    <button
                      type="button"
                      onClick={() => setShowPrivacyModal(true)}
                      className="font-medium text-teal-600 underline underline-offset-2"
                    >
                      Privacy Policy
                    </button>
                  </span>
                </label>
              )}
            />
            <AnimatePresence>
              {errors.consent && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-2 text-xs text-alert-red"
                >
                  {errors.consent.message}
                </motion.p>
              )}
            </AnimatePresence>

            {/* Emergency Notice */}
            <button
              type="button"
              onClick={() => setShowEmergencyModal(true)}
              className="mt-4 flex w-full items-center gap-2 rounded-xl bg-alert-red-light px-4 py-3 text-left transition-colors hover:bg-red-100"
            >
              <AlertTriangle size={16} className="shrink-0 text-alert-red" />
              <span className="text-sm text-alert-red">
                If you are experiencing a medical emergency, call 911 immediately. This form is not for
                urgent care.
              </span>
            </button>

            {/* Submit Button */}
            <motion.button
              type="submit"
              disabled={!isFormValid || isSubmitting}
              animate={isFormValid && !isSubmitting ? { scale: [1, 1.02, 1] } : {}}
              transition={isFormValid && !isSubmitting ? { duration: 2, repeat: Infinity } : {}}
              className={cn(
                'mt-6 flex h-14 w-full items-center justify-center gap-2 rounded-xl text-base font-semibold text-white shadow-[0_1px_2px_rgba(249,115,22,0.2)] transition-all',
                isFormValid && !isSubmitting
                  ? 'bg-coral-500 hover:bg-coral-600 active:scale-[0.98]'
                  : 'bg-slate-300 cursor-not-allowed'
              )}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Sending...
                </>
              ) : (
                'Submit Request'
              )}
            </motion.button>

            {/* Trust Note */}
            <div className="mt-4 flex items-center justify-center gap-1.5">
              <ShieldCheck size={14} className="text-teal-600" />
              <span className="text-xs text-slate-500">
                Your data is stored in Canada and handled per PHIPA standards.
              </span>
            </div>
          </div>
        </motion.div>
      </motion.form>

      {/* Privacy Policy Modal */}
      <AnimatePresence>
        {showPrivacyModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[90] flex items-center justify-center bg-slate-900/60 px-4 backdrop-blur-sm"
            onClick={() => setShowPrivacyModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.3, ease: easeSpring }}
              className="max-h-[80vh] w-full max-w-md overflow-y-auto rounded-2xl bg-white p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="mb-3 text-lg font-semibold text-slate-900">Privacy Policy</h3>
              <p className="mb-4 text-sm leading-relaxed text-slate-600">
                CareMap Toronto collects your personal information solely for the purpose of facilitating
                patient registration with healthcare providers. Your data is encrypted, stored in Canada,
                and handled in compliance with Ontario&apos;s Personal Health Information Protection Act (PHIPA).
              </p>
              <p className="mb-4 text-sm leading-relaxed text-slate-600">
                We do not share your information with third parties beyond the clinic you select. You may
                request deletion of your data at any time by contacting us.
              </p>
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="w-full rounded-xl bg-teal-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-700"
              >
                I Understand
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Emergency Modal */}
      <AnimatePresence>
        {showEmergencyModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 px-4 backdrop-blur-sm"
            onClick={() => setShowEmergencyModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.3, ease: easeSpring }}
              className="w-full max-w-[420px] rounded-[20px] border-2 border-alert-red bg-alert-red-light p-8 text-center shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="animate-pulse-border mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full">
                <AlertTriangle size={48} className="text-alert-red" />
              </div>
              <h2 className="mb-3 text-[1.375rem] font-semibold text-alert-red">
                This sounds like an emergency
              </h2>
              <p className="mb-6 text-sm leading-relaxed text-slate-700">
                If you or someone nearby is experiencing severe symptoms, please call 911 or visit the
                nearest emergency room immediately.
              </p>
              <a
                href="tel:911"
                className="mb-3 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-alert-red text-base font-semibold text-white transition-colors hover:bg-red-700"
              >
                <Phone size={18} />
                Call 911
              </a>
              <button
                type="button"
                onClick={() => {
                  setShowEmergencyModal(false)
                  toast.info('Finding nearest emergency room...')
                }}
                className="mb-3 w-full rounded-xl border border-slate-200 bg-white py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50"
              >
                Find Nearest ER
              </button>
              <button
                type="button"
                onClick={() => setShowEmergencyModal(false)}
                className="text-sm font-medium text-slate-500 underline underline-offset-2 transition-colors hover:text-slate-700"
              >
                I understand — continue searching
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
