import { useState, useEffect, useMemo } from 'react'
import { Link, useNavigate } from 'react-router'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ChevronLeft,
  List,
  MapPin,
  SlidersHorizontal,
  X,
  Star,
  Building2,
  Clock,
  CheckCircle2,
  ShieldCheck,
  Globe,
  TreePine,
  AlertTriangle,
  Phone,
  Cross,
  ChevronDown,
  Check,
  Slash,
} from 'lucide-react'
import type { Doctor } from '@/data/mockDoctors'
import { doctors } from '@/data/mockDoctors'
import { useFilterParams, containsEmergencyKeyword } from '@/data/filters'
import type { FilterState } from '@/data/filters'

/* ------------------------------------------------------------------ */
/*  Sort Dropdown                                                      */
/* ------------------------------------------------------------------ */

const sortOptions: { value: FilterState['sortBy']; label: string }[] = [
  { value: 'nearest', label: 'Nearest First' },
  { value: 'shortest_wait', label: 'Shortest Wait' },
  { value: 'highest_rated', label: 'Highest Rated' },
  { value: 'accepting', label: 'Accepting Patients' },
]

function SortDropdown({ value, onChange }: { value: FilterState['sortBy']; onChange: (v: FilterState['sortBy']) => void }) {
  const [open, setOpen] = useState(false)
  const ref = useState<HTMLDivElement | null>(null)

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref[0] && !ref[0].contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [ref])

  const selectedLabel = sortOptions.find((o) => o.value === value)?.label ?? 'Sort by'

  return (
    <div className="relative" ref={(node) => { ref[0] = node }}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1 rounded-lg px-3 py-2 text-xs font-medium text-teal-600 transition-colors hover:bg-teal-50"
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        Sort: {selectedLabel}
        <ChevronDown size={14} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
            className="absolute right-0 top-full z-50 mt-1 min-w-[180px] rounded-xl border border-slate-200 bg-white p-1 shadow-[0_4px_16px_rgba(15,23,42,0.08)]"
            role="listbox"
          >
            {sortOptions.map((opt) => (
              <button
                key={opt.value}
                role="option"
                aria-selected={opt.value === value}
                onClick={() => {
                  onChange(opt.value)
                  setOpen(false)
                }}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                  opt.value === value ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {opt.label}
                {opt.value === value && <Check size={14} className="text-teal-600" />}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Emergency Overlay                                                */
/* ------------------------------------------------------------------ */

function EmergencyOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-[rgba(15,23,42,0.6)] backdrop-blur-sm px-4"
          aria-live="assertive"
          role="alertdialog"
          aria-modal="true"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.25, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] }}
            className="w-full max-w-[420px] animate-pulse-border rounded-[20px] border-2 border-[#DC2626] bg-[#FEF2F2] p-8 text-center"
          >
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#DC2626]/10">
              <AlertTriangle size={28} className="text-[#DC2626]" aria-hidden="true" />
            </div>
            <h2 className="mb-3 text-xl font-semibold text-[#DC2626]">This sounds like an emergency</h2>
            <p className="mb-6 text-sm leading-relaxed text-slate-700">
              If you or someone nearby is experiencing severe symptoms, please call 911 or visit the nearest emergency room immediately.
            </p>
            <a
              href="tel:911"
              className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#DC2626] px-4 py-3.5 text-base font-semibold text-white transition-transform hover:scale-[1.02] active:scale-[0.98]"
            >
              <Phone size={18} />
              Call 911
            </a>
            <button
              onClick={onClose}
              className="mb-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50"
            >
              Find Nearest ER
            </button>
            <button
              onClick={onClose}
              className="text-sm font-medium text-teal-600 transition-colors hover:text-teal-700"
            >
              I understand — continue searching
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/* ------------------------------------------------------------------ */
/*  Skeleton Card                                                      */
/* ------------------------------------------------------------------ */

function SkeletonCard() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-white p-5 shadow-[0_1px_3px_rgba(15,23,42,0.06),0_1px_2px_rgba(15,23,42,0.04)]">
      <div className="flex gap-4">
        <div className="h-14 w-14 flex-shrink-0 animate-shimmer rounded-full bg-slate-200" />
        <div className="flex-1 space-y-2">
          <div className="h-5 w-3/5 animate-shimmer rounded bg-slate-200" />
          <div className="h-4 w-2/5 animate-shimmer rounded bg-slate-200" />
          <div className="h-4 w-1/3 animate-shimmer rounded bg-slate-200" />
        </div>
      </div>
      <div className="mt-4 space-y-2">
        <div className="h-4 w-4/5 animate-shimmer rounded bg-slate-200" />
        <div className="h-4 w-3/5 animate-shimmer rounded bg-slate-200" />
      </div>
      <div className="mt-4 flex gap-2">
        <div className="h-6 w-20 animate-shimmer rounded-full bg-slate-200" />
        <div className="h-6 w-16 animate-shimmer rounded-full bg-slate-200" />
      </div>
      <div className="mt-4 h-10 w-full animate-shimmer rounded-xl bg-slate-200" />
      <style>{`
        .animate-shimmer {
          background: linear-gradient(90deg, #e2e8f0 25%, #f1f5f9 50%, #e2e8f0 75%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite linear;
        }
      `}</style>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Doctor Card                                                      */
/* ------------------------------------------------------------------ */

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

function DoctorCard({ doctor, index }: { doctor: Doctor; index: number }) {
  const navigate = useNavigate()

  const availabilityColor =
    doctor.nextAvailable === 'Today'
      ? 'text-[#16A34A]'
      : doctor.waitTimeDays < 14
        ? 'text-slate-700'
        : 'text-[#D97706]'

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      exit={{ opacity: 0, y: -10 }}
      transition={{
        duration: 0.4,
        delay: index * 0.08,
        ease: [0.4, 0, 0.2, 1] as [number, number, number, number],
      }}
      className="group relative cursor-pointer rounded-2xl bg-white p-5 shadow-[0_1px_3px_rgba(15,23,42,0.06),0_1px_2px_rgba(15,23,42,0.04)] transition-all hover:-translate-y-0.5 hover:border hover:border-teal-100 hover:shadow-[0_4px_12px_rgba(15,23,42,0.08)] active:scale-[0.98]"
      onClick={() => navigate(`/profile/${doctor.id}`)}
      role="link"
      aria-label={`${doctor.name}, ${doctor.specialty}`}
    >
      {/* Mobile & Desktop unified layout using flex */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:gap-5">
        {/* Avatar */}
        <div className="flex-shrink-0">
          <img
            src={doctor.photoUrl}
            alt={`${doctor.name} headshot`}
            className="h-14 w-14 rounded-full border-2 border-teal-50 object-cover md:h-[72px] md:w-[72px]"
            loading="lazy"
          />
        </div>

        {/* Info block */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="text-lg font-semibold text-slate-900">{doctor.name}</h3>
              <p className="text-sm font-medium text-teal-600">{doctor.specialty}</p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Star size={14} className="fill-[#F59E0B] text-[#F59E0B]" aria-hidden="true" />
              <span className="text-base font-semibold text-slate-900">{doctor.rating}</span>
              <span className="text-xs text-slate-500">({doctor.reviewCount})</span>
            </div>
          </div>

          <div className="mt-2 space-y-1">
            <div className="flex items-center gap-1.5 text-sm text-slate-600">
              <Building2 size={14} className="text-slate-400" aria-hidden="true" />
              {doctor.clinicName}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <MapPin size={14} className="text-slate-400" aria-hidden="true" />
              {doctor.distanceKm} km · {doctor.neighborhood}
            </div>
            <div className={`flex items-center gap-1.5 text-xs font-medium ${availabilityColor}`}>
              <Clock size={14} aria-hidden="true" />
              Next available: {doctor.nextAvailable}
            </div>
          </div>

          {/* Badges */}
          <div className="mt-3 flex flex-wrap gap-2">
            {doctor.acceptingNewPatients && (
              <span className="inline-flex items-center gap-1 rounded-md bg-[#16A34A] px-2.5 py-1 text-xs font-medium text-white">
                <CheckCircle2 size={12} aria-hidden="true" />
                Accepting New Patients
              </span>
            )}
            {!doctor.acceptingNewPatients && (
              <span className="inline-flex items-center gap-1 rounded-md bg-slate-200 px-2.5 py-1 text-xs font-medium text-slate-600">
                <Slash size={12} aria-hidden="true" />
                Not Accepting
              </span>
            )}
            {doctor.ohip && (
              <span className="inline-flex items-center gap-1 rounded-md border border-teal-200 bg-teal-50 px-2.5 py-1 text-xs font-medium text-teal-700">
                <TreePine size={12} aria-hidden="true" />
                OHIP
              </span>
            )}
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700">
              <Globe size={12} aria-hidden="true" />
              {doctor.languages.slice(0, 2).join(', ')}
              {doctor.languages.length > 2 && ` +${doctor.languages.length - 2}`}
            </span>
            {doctor.wheelchair && (
              <span className="inline-flex items-center gap-1 rounded-md border border-teal-200 bg-teal-50 px-2.5 py-1 text-xs font-medium text-teal-700">
                <ShieldCheck size={12} aria-hidden="true" />
                Accessible
              </span>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="flex-shrink-0 md:flex md:items-center">
          <button
            onClick={(e) => {
              e.stopPropagation()
              navigate(`/register?doctor=${doctor.id}`)
            }}
            className="w-full rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-teal-50 hover:text-teal-700 hover:border-teal-200 md:w-auto"
          >
            Request Attachment
          </button>
        </div>
      </div>
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/*  Map View                                                         */
/* ------------------------------------------------------------------ */

function MapView({ results, onSelect }: { results: Doctor[]; onSelect: (d: Doctor) => void }) {
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const selected = results.find((d) => d.id === selectedId)

  // Normalize coordinates to percentage positions for the mock map
  const latMin = 43.65
  const latMax = 43.81
  const lngMin = -79.42
  const lngMax = -79.19

  const pinPosition = (doc: Doctor) => ({
    left: `${((doc.coordinates.lng - lngMin) / (lngMax - lngMin)) * 100}%`,
    top: `${((latMax - doc.coordinates.lat) / (latMax - latMin)) * 100}%`,
  })

  return (
    <div className="relative h-[calc(100dvh-120px)] w-full overflow-hidden rounded-2xl bg-white md:h-[600px]">
      <img
        src="/map-toronto.jpg"
        alt="Map of Toronto"
        className="h-full w-full object-cover"
      />

      {results.map((doc, i) => {
        const pos = pinPosition(doc)
        const isSelected = selectedId === doc.id
        return (
          <motion.button
            key={doc.id}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              delay: i * 0.06,
              duration: 0.3,
              ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number],
            }}
            onClick={() => {
              setSelectedId(doc.id)
              onSelect(doc)
            }}
            className={`absolute flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full shadow-lg transition-transform hover:scale-110 ${
              isSelected
                ? 'h-9 w-9 animate-pulse-subtle bg-[#F97316] ring-[3px] ring-[#F97316]'
                : 'h-7 w-7 bg-teal-600'
            }`}
            style={{ left: pos.left, top: pos.top }}
            aria-label={doc.name}
          >
            <Cross size={isSelected ? 16 : 12} className="text-white" aria-hidden="true" />
          </motion.button>
        )
      })}

      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="absolute bottom-4 left-4 right-4 z-10 rounded-2xl bg-white p-4 shadow-[0_4px_16px_rgba(15,23,42,0.12)] md:bottom-auto md:left-auto md:right-4 md:top-4 md:w-80"
          >
            <div className="flex items-center gap-3">
              <img
                src={selected.photoUrl}
                alt=""
                className="h-10 w-10 rounded-full object-cover"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-base font-semibold text-slate-900 truncate">{selected.name}</h4>
                <p className="text-xs font-medium text-teal-600">{selected.specialty}</p>
                <p className="text-xs text-slate-500">{selected.distanceKm} km away</p>
              </div>
              <Link
                to={`/profile/${selected.id}`}
                className="flex-shrink-0 text-sm font-medium text-teal-600 hover:text-teal-700"
              >
                View Profile
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Empty State                                                      */
/* ------------------------------------------------------------------ */

function EmptyState({ onClear }: { onClear: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
      className="flex min-h-[400px] flex-col items-center justify-center px-6 py-12 text-center"
    >
      <img
        src="/empty-state.svg"
        alt="No results found"
        className="mb-6 h-auto w-[200px]"
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = 'none'
        }}
      />
      <h2 className="mb-2 text-xl font-semibold text-slate-900">No doctors match your filters</h2>
      <p className="mb-6 max-w-xs text-base text-slate-600">
        Try removing some filters or broadening your search area.
      </p>
      <button
        onClick={onClear}
        className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-teal-50 hover:text-teal-700 hover:border-teal-200"
      >
        Clear All Filters
      </button>
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/*  Results Page                                                     */
/* ------------------------------------------------------------------ */

export default function Results() {
  const navigate = useNavigate()
  const { filters, setFilters, resetFilters } = useFilterParams()

  const [viewMode, setViewMode] = useState<'list' | 'map'>('list')
  const [loading, setLoading] = useState(true)
  const [showEmergency, setShowEmergency] = useState(false)

  // Simulate loading on mount / filter change
  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 600)
    return () => clearTimeout(t)
  }, [filters])

  // Emergency keyword check
  useEffect(() => {
    if (containsEmergencyKeyword(filters.query)) {
      setShowEmergency(true)
    }
  }, [filters.query])

  // Build active filter chips
  const activeChips = useMemo(() => {
    const chips: { key: string; label: string; onRemove: () => void }[] = []

    filters.specialties.forEach((s) =>
      chips.push({
        key: `spec-${s}`,
        label: s,
        onRemove: () =>
          setFilters((prev) => ({ ...prev, specialties: prev.specialties.filter((x) => x !== s) })),
      })
    )

    filters.neighborhoods.forEach((n) =>
      chips.push({
        key: `neigh-${n}`,
        label: n,
        onRemove: () =>
          setFilters((prev) => ({ ...prev, neighborhoods: prev.neighborhoods.filter((x) => x !== n) })),
      })
    )

    filters.languages.forEach((l) =>
      chips.push({
        key: `lang-${l}`,
        label: l,
        onRemove: () =>
          setFilters((prev) => ({ ...prev, languages: prev.languages.filter((x) => x !== l) })),
      })
    )

    if (filters.acceptingNewPatients) {
      chips.push({
        key: 'accepting',
        label: 'Accepting Patients',
        onRemove: () => setFilters((prev) => ({ ...prev, acceptingNewPatients: false })),
      })
    }

    if (filters.wheelchair) {
      chips.push({
        key: 'wheelchair',
        label: 'Wheelchair',
        onRemove: () => setFilters((prev) => ({ ...prev, wheelchair: false })),
      })
    }

    if (filters.ohip) {
      chips.push({
        key: 'ohip',
        label: 'OHIP',
        onRemove: () => setFilters((prev) => ({ ...prev, ohip: false })),
      })
    }

    if (filters.eveningWeekend) {
      chips.push({
        key: 'evening',
        label: 'Evening/Weekend',
        onRemove: () => setFilters((prev) => ({ ...prev, eveningWeekend: false })),
      })
    }

    if (filters.parking) {
      chips.push({
        key: 'parking',
        label: 'Parking',
        onRemove: () => setFilters((prev) => ({ ...prev, parking: false })),
      })
    }

    if (filters.transit) {
      chips.push({
        key: 'transit',
        label: 'Transit',
        onRemove: () => setFilters((prev) => ({ ...prev, transit: false })),
      })
    }

    if (filters.ifhp) {
      chips.push({
        key: 'ifhp',
        label: 'IFHP',
        onRemove: () => setFilters((prev) => ({ ...prev, ifhp: false })),
      })
    }

    if (filters.minRating > 0) {
      chips.push({
        key: 'rating',
        label: `${filters.minRating}+ Stars`,
        onRemove: () => setFilters((prev) => ({ ...prev, minRating: 0 })),
      })
    }

    return chips
  }, [filters, setFilters])

  // Filter & sort results
  const filtered = useMemo(() => {
    let res = [...doctors]

    if (filters.query.trim()) {
      const q = filters.query.toLowerCase()
      res = res.filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          d.specialty.toLowerCase().includes(q) ||
          d.neighborhood.toLowerCase().includes(q) ||
          d.clinicName.toLowerCase().includes(q) ||
          d.languages.some((l) => l.toLowerCase().includes(q))
      )
    }

    if (filters.specialties.length > 0) {
      res = res.filter((d) => filters.specialties.includes(d.specialty))
    }

    if (filters.neighborhoods.length > 0) {
      res = res.filter((d) => filters.neighborhoods.includes(d.neighborhood))
    }

    if (filters.languages.length > 0) {
      res = res.filter((d) => filters.languages.some((l) => d.languages.includes(l)))
    }

    if (filters.acceptingNewPatients) {
      res = res.filter((d) => d.acceptingNewPatients)
    }

    if (filters.wheelchair) {
      res = res.filter((d) => d.wheelchair)
    }

    if (filters.eveningWeekend) {
      res = res.filter((d) => d.eveningWeekend)
    }

    if (filters.ohip) {
      res = res.filter((d) => d.ohip)
    }

    if (filters.parking) {
      // Parking is on clinic, not doctor — skip for now or cross-reference
    }

    if (filters.transit) {
      // Transit is on clinic — skip
    }

    if (filters.ifhp) {
      // No doctor field for ifhp — skip
    }

    if (filters.distanceKm < 50) {
      res = res.filter((d) => d.distanceKm <= filters.distanceKm)
    }

    if (filters.minRating > 0) {
      res = res.filter((d) => d.rating >= filters.minRating)
    }

    switch (filters.maxWaitTime) {
      case '2 weeks':
        res = res.filter((d) => d.waitTimeDays <= 14)
        break
      case '1 month':
        res = res.filter((d) => d.waitTimeDays <= 30)
        break
      case '3 months':
        res = res.filter((d) => d.waitTimeDays <= 90)
        break
    }

    switch (filters.sortBy) {
      case 'nearest':
        res.sort((a, b) => a.distanceKm - b.distanceKm)
        break
      case 'shortest_wait':
        res.sort((a, b) => a.waitTimeDays - b.waitTimeDays)
        break
      case 'highest_rated':
        res.sort((a, b) => b.rating - a.rating)
        break
      case 'accepting':
        res.sort((a, b) => Number(b.acceptingNewPatients) - Number(a.acceptingNewPatients))
        break
    }

    return res
  }, [filters])

  const queryText = useMemo(() => {
    if (filters.query) return `${filters.query} in Toronto`
    const parts: string[] = []
    if (filters.specialties.length === 1) parts.push(filters.specialties[0])
    else if (filters.specialties.length > 1) parts.push('selected specialties')
    else parts.push('Doctors')
    if (filters.neighborhoods.length === 1) parts.push(`in ${filters.neighborhoods[0]}`)
    else if (filters.neighborhoods.length > 1) parts.push('in selected areas')
    if (filters.acceptingNewPatients) parts.push('accepting new patients')
    return parts.join(' ')
  }, [filters])

  return (
    <div className="min-h-[100dvh] bg-[#FAFAF9]">
      {/* Results Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="sticky top-0 z-40 border-b border-slate-200 bg-white px-4 py-4 md:px-6"
      >
        <div className="mx-auto max-w-[720px]">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-1 rounded-lg px-3 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100"
            >
              <ChevronLeft size={20} />
              Back
            </button>

            <div className="flex items-center gap-2">
              {/* View Toggle */}
              <div className="flex items-center rounded-lg bg-slate-100 p-1">
                <button
                  onClick={() => setViewMode('list')}
                  className={`rounded-md p-1.5 transition-all ${
                    viewMode === 'list' ? 'bg-teal-50 text-teal-600 shadow-sm' : 'text-slate-400'
                  }`}
                  aria-label="List view"
                >
                  <List size={18} />
                </button>
                <button
                  onClick={() => setViewMode('map')}
                  className={`rounded-md p-1.5 transition-all ${
                    viewMode === 'map' ? 'bg-teal-50 text-teal-600 shadow-sm' : 'text-slate-400'
                  }`}
                  aria-label="Map view"
                >
                  <MapPin size={18} />
                </button>
              </div>

              <SortDropdown
                value={filters.sortBy}
                onChange={(sortBy) => setFilters((prev) => ({ ...prev, sortBy }))}
              />
            </div>
          </div>

          <div className="mt-3">
            <h1 className="text-lg font-semibold text-slate-900 md:text-xl">{queryText}</h1>
            <p className="mt-0.5 text-xs text-slate-500">
              Showing {filtered.length} result{filtered.length !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
      </motion.div>

      {/* Filter Chips Bar */}
      {activeChips.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
          className="sticky top-[72px] z-[35] border-b border-slate-100 bg-[#FAFAF9] px-4 py-3 md:top-[80px] md:px-6"
        >
          <div className="mx-auto flex max-w-[720px] items-center gap-2">
            <div className="flex flex-1 gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
              {activeChips.map((chip, i) => (
                <motion.button
                  key={chip.key}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: i * 0.06, duration: 0.2 }}
                  onClick={chip.onRemove}
                  className="inline-flex flex-shrink-0 items-center gap-1.5 rounded-full bg-teal-600 px-4 py-2 text-sm font-medium text-white transition-transform hover:scale-105 active:scale-95"
                >
                  {chip.label}
                  <X size={12} aria-hidden="true" />
                </motion.button>
              ))}

              <button
                onClick={() => navigate('/filters')}
                className="inline-flex flex-shrink-0 items-center gap-1.5 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:border-slate-300 hover:bg-stone-50"
              >
                <SlidersHorizontal size={14} />
                More Filters
              </button>
            </div>

            {activeChips.length > 3 && (
              <span className="flex-shrink-0 text-xs text-slate-500">
                {activeChips.length} filters applied
              </span>
            )}

            <button
              onClick={resetFilters}
              className="flex-shrink-0 text-xs font-medium text-teal-600 hover:text-teal-700"
            >
              Clear All
            </button>
          </div>
        </motion.div>
      )}

      {/* Content */}
      <div className="mx-auto max-w-[720px] px-4 py-4 md:px-6">
        {loading ? (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.2 }}
              >
                <SkeletonCard />
              </motion.div>
            ))}
          </div>
        ) : viewMode === 'map' ? (
          <MapView results={filtered} onSelect={() => {}} />
        ) : filtered.length === 0 ? (
          <EmptyState onClear={resetFilters} />
        ) : (
          <motion.div
            className="space-y-3"
            initial="hidden"
            animate="visible"
            variants={{
              visible: { transition: { staggerChildren: 0.08 } },
            }}
          >
            <AnimatePresence>
              {filtered.map((doctor, i) => (
                <DoctorCard key={doctor.id} doctor={doctor} index={i} />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      {/* Emergency Overlay */}
      <EmergencyOverlay open={showEmergency} onClose={() => setShowEmergency(false)} />
    </div>
  )
}
