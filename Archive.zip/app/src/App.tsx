import { Routes, Route } from 'react-router'
import Layout from './components/Layout'
import Home from './pages/Home'
import Results from './pages/Results'
import Filters from './pages/Filters'
import Profile from './pages/Profile'
import Register from './pages/Register'
import Confirm from './pages/Confirm'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/results" element={<Results />} />
        <Route path="/filters" element={<Filters />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/register" element={<Register />} />
        <Route path="/confirm" element={<Confirm />} />
      </Route>
    </Routes>
  )
}
