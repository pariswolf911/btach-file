# CareMap Toronto — Research Findings

## Source Document
CareMap Toronto: AI Healthcare Navigation Platform - Master Strategy & PRD

## Key Product Details
- **Mission**: Solve the healthcare access crisis in the Greater Toronto Area by providing an AI-driven "North Star" for patient navigation.
- **Value Proposition**: Unlike static directories, CareMap uses agentic AI to verify clinic availability and guide users through the fragmented Ontario health grid without offering medical diagnoses.
- **Regulatory**: PHIPA compliant, data residency Canada-Central, non-diagnostic AI with guardrails, emergency logic for 911/ER redirection, AIDA 2026 explainable AI.

## Scenario #7: The "Unattached Patient"
- Real-time list of GPs (General Practitioners / Family Doctors) accepting new patients today
- Target: Unattached patients in Toronto looking for a family doctor

## V1 MVP Features
- AI Search
- Map Integration
- Language Filters
- Public Registry Sync

## Validation Scenarios (Full List)
1. The Newcomer: Mandarin-speaking GP in North York
2. Midnight Dental: Emergency clinic open past 8PM
3. Cultural Fit: Italian-speaking specialist in Little Italy
4. Student Access: Mental health near UofT
5. After-Hours Parent: Pediatric Urgent Care <1hr wait at 7PM
6. Refugee Support: Clinics accepting IFHP coverage
7. The "Unattached": GPs accepting new patients today
8. Accessibility: Geriatric specialist with wheelchair access in Etobicoke
9. Travel Prep: Rapid yellow fever vaccine clinic
10. Safe Space: Gender-Affirming Care clinics
11. Commuter Care: Optometrist near Union Station
12. Med Inventory: Pharmacy stock checking (V3)
13. Queue Jumper: Shorter walk-in waits in Scarborough
14. Post-Op: ACL-specialized physio
15. Hybrid Health: Naturopaths collaborating with primary MDs
16. Fasting Lab: LifeLabs/Dynacare open at 6AM
17. Commuter MD: Specialist near 400-series highway with parking
18. Social Care: Dental clinics accepting Ontario Works/ODSP
19. Executive Health: High-end clinics for annual physicals
20. Critical Triage: "Chest Pain" trigger -> Emergency 911 Overlay

## Required Mock Data Fields
- Doctor name
- Specialty (Family Medicine, Dentistry, Cardiology, etc.)
- Location (neighborhood, address, coordinates)
- Languages spoken
- Accepting new patients (yes/no)
- Wait time estimate
- Rating (stars/reviews)
- Clinic name
- Phone number
- OHIP acceptance
- Wheelchair accessible
- Evening/weekend hours
- Distance from user

## AI Assistant Behavior
- Simulate simple conversational responses
- User describes symptoms/needs → AI suggests doctor type → Show results
- Emergency trigger logic: keywords like "chest pain", "can't breathe", "severe bleeding" → immediate 911/ER alert overlay
- No medical diagnosis provided
- Friendly, reassuring, professional tone

## Target Design Style
- Minimal, Apple-like, clean, trustworthy healthcare interface
- Mobile-first design
- Low-saturation palette, warm tones, ample whitespace
- Clean hierarchy, accessible typography
- Trust signals (verified badges, ratings, clear labels)
