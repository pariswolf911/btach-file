# CareMap Toronto — MVP Prototype Build Plan

## Overview
Build a clickable, mobile-first web app prototype for CareMap Toronto — a healthcare navigation platform. Focus on Scenario #7: "Unattached Patient" seeking a family doctor accepting new patients in Toronto.

## Stage 1 — Skill Loading & Design Blueprint
- Load `vibecoding-webapp-swarm` skill
- Define design system, color palette, typography
- Define screen inventory and component hierarchy
- Define mock data schema and AI assistant behavior
- Output: design.md, page hierarchy, user journey flow

## Stage 2 — Build Phase
- React + TypeScript + Tailwind CSS
- shadcn/ui components
- Mock data layer (no backend)
- 6 screens with full interactivity:
  1. Homepage (search + AI assistant)
  2. Results page (doctor list)
  3. Filters panel
  4. Doctor profile page
  5. Registration/request form
  6. Confirmation screen
- Emergency trigger logic
- Mobile-first responsive design

## Stage 3 — Review & Deploy
- Test all user flows
- Deploy as static site
- Deliver final artifact
